import * as functions from 'firebase-functions'
import * as admin from 'firebase-admin'
import * as nodemailer from 'nodemailer'
import * as path from 'path'

const mailTransport = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: functions.config().gmail.email,
        pass: functions.config().gmail.password,
    },
});

// // Start writing Firebase Functions
// // https://firebase.google.com/docs/functions/typescript
//
// export const helloWorld = functions.https.onRequest((request, response) => {
//  response.send("Hello from Firebase!")
// })

admin.initializeApp(functions.config().firebase)

const createUser = async (email, password, name, company) => {
    return admin.auth().createUser({
        email: email,
        password: password,
        displayName: name,
    })
        .then((userRecord) => {
            const employee = company === null
            return admin.database().ref('users').child(userRecord.uid).set({ email, name, employee, company })
        })
}

const updateUser = async (uid, email, password, name, company) => {
    const selectedUser = await admin.auth().getUser(uid)
    if (selectedUser) {
        if (email && email !== selectedUser.email) await admin.auth().updateUser(selectedUser.uid, { email })
        if (password) await admin.auth().updateUser(selectedUser.uid, { password })
        const employee = company === null
        return admin.database().ref('users').child(selectedUser.uid).set({ email, name, employee, company })
    } else {
        return new Promise((resolve, reject) => { reject({ error: "User not found" }) })
    }
}

const deleteUser = (uid) => {
    return admin.auth().deleteUser(uid)
        .then(() => { return admin.database().ref('users').child(uid).remove() })
}

export const client = functions.https.onRequest(async (request, response) => {
    const uid = request.query.uid
    const email = request.body.email
    const password = request.body.password
    const name = request.body.name
    const company = request.body.company

    response.setHeader('Access-Control-Allow-Origin', "*")
    response.setHeader("Access-Control-Allow-Credentials", "true");
    response.setHeader('Access-Control-Allow-Methods', "POST, PATCH, DELETE")
    response.setHeader("Access-Control-Allow-Headers", "Access-Control-Allow-Origin, Access-Control-Allow-Headers, Origin,Accept, X-Requested-With, Content-Type, Access-Control-Request-Method, Access-Control-Request-Headers");

    switch (request.method) {
        case "POST":
            createUser(email, password, name, company)
                .then(() => response.sendStatus(201))
                .catch((error) => { response.status(400).send(error) })
            break
        case "PATCH":
            updateUser(uid, email, password, name, company)
                .then(() => response.sendStatus(200))
                .catch((error) => { response.status(400).send(error) })
            break
        case "DELETE":
            deleteUser(uid)
                .then(() => { return response.sendStatus(200) })
                .catch((error) => { response.status(400).send(error) })
            break
        default:
            response.send("client")
            break
    }
})

export const user = functions.https.onRequest(async (request, response) => {
    const uid = request.query.uid
    const email = request.body.email
    const password = request.body.password
    const name = request.body.name

    response.setHeader('Access-Control-Allow-Origin', "*")
    response.setHeader("Access-Control-Allow-Credentials", "true");
    response.setHeader('Access-Control-Allow-Methods', "POST, PATCH, DELETE")
    response.setHeader("Access-Control-Allow-Headers", "Access-Control-Allow-Origin, Access-Control-Allow-Headers, Origin,Accept, X-Requested-With, Content-Type, Access-Control-Request-Method, Access-Control-Request-Headers");

    switch (request.method) {
        case "POST":
            createUser(email, password, name, null)
                .then(() => response.sendStatus(201))
                .catch((error) => { response.status(400).send(error) })
            break
        case "PATCH":
            updateUser(uid, email, password, name, null)
                .then(() => response.sendStatus(200))
                .catch((error) => { response.status(400).send(error) })
            break
        case "DELETE":
            deleteUser(uid)
                .then(() => { return response.sendStatus(200) })
                .catch((error) => { response.status(400).send(error) })
            break
        default:
            response.send("client")
            break
    }
})

export const recoverPassword = functions.https.onCall(async (data, context) => {
    try {
        const userFound = await admin.auth().getUserByEmail(data.email)
        if (userFound) {
            const userDetails = await admin.database().ref('users').child(userFound.uid).once('value')
            if (userDetails && userDetails.val() && userDetails.val().company) {
                const company = await admin.database().ref('clients').child(userDetails.val().company).once('value')
                const mailOptions = {
                    from: '"Gestão Laudos EE" <noreply@firebase.com>',
                    to: 'ensaioseletricosrj@gmail.com',
                    // to: 'ana.coimbra.gomes@gmail.com',
                    subject: 'Pedido de recuperação de senha',
                    html: 'O usuário <b>' + userDetails.val().name +
                        '</b> precisa de recuperar a senha do email ' + userDetails.val().email +
                        ' do cliente <b>' + company.val().name + '</b><br/><p>Enviar email para ' + data.contact + '.'
                };

                return mailTransport.sendMail(mailOptions)
                    .then(() => {
                        console.log('Email was sent')
                        return { error: false, message: 'Email was sent' }
                    })
                    .catch((error) => {
                        console.error('There was an error while sending the email:', error)
                        return error
                    });
            } else {
                return { error: true, message: 'no user found for this email' }
            }
        } else {
            return { error: true, message: 'no user found for this email' }
        }
    } catch (error) {
        return error
    }
})

export const metadata = functions.storage.object().onFinalize(async object => {
    const filePath = object.name;
    const folders = filePath.split('/')
    const contentType = object.contentType;
    const fileName = path.basename(filePath);

    console.log(contentType, fileName, folders.join('/'))

    if (folders.length > 1 && folders[0] === 'procedimentos') {
        await admin.database().ref('proceedings')
            .update({ updated: new Date().getTime() })
        await admin.database().ref('proceedings')
            .child(folders[1])
            .push()
            .set({ path: folders.splice(2).join('/') })
    }
})