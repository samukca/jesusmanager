import React, {Component} from 'react';
import {auth} from '../../firebase';

class SidebarHeader extends Component {

  constructor(props) {
    super(props);

    this.state = {
      user: null,
      loading: true
    }
  }

  componentWillMount() {
    auth.onAuthStateChanged((user) => {
      if (user) {
        this.setState({ user, loading: false });
      } else {
        this.setState({ user: null, loading: false })
      }
    });
  }

  render() {
    return (
      <div className="sidebar-header">
        { !this.state.loading && this.state.user != null && <p className="lead">{this.state.user.displayName}</p> }
      </div>
    )
  }
}

export default SidebarHeader;
