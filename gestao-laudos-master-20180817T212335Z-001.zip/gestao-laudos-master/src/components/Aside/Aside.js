import React, { Component } from 'react';


class Aside extends Component {
  render() {
    return (
      <aside className="aside-menu">
        {/*Aside Menu*/}
      </aside>
    )
  }
}

export default Aside;
