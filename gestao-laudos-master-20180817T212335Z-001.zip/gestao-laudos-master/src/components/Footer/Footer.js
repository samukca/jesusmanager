import React, {Component} from 'react';

class Footer extends Component {
  render() {
    return (
      <footer className="app-footer">
        <span>Ensaios Elétricos Ltda. &copy; 2017</span>
        <span className="ml-auto">Desenvolvido por Ana Coimbra</span>
      </footer>
    )
  }
}

export default Footer;
