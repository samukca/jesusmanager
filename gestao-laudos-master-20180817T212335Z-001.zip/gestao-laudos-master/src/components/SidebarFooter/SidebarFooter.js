import React, {Component} from 'react';
import {auth} from '../../firebase';
import {NavItem, NavLink, Nav} from 'reactstrap';
import { Redirect, Route } from 'react-router-dom';
import Raven from 'raven-js';

class SidebarFooter extends Component {

  constructor(props) {
    super(props);

    this.state = {
      redirect: false
    }
  }

  onSignOut() {
    auth.signOut()
      .then(() => {
        this.setState({
          redirect: true
        })
      }).catch((error) => {
        Raven.captureException(e)
      });
  }

  render() {
    return (
      <div className="sidebar-footer">
        {
          (this.state.redirect === true) && 
            <Route render={(props) => (<Redirect to={{pathname: '/login'}} />)} />
        } 
        <NavLink href="#" onClick={this.onSignOut.bind(this)}>Sair</NavLink>
      </div>
    )
  }
}

export default SidebarFooter;
