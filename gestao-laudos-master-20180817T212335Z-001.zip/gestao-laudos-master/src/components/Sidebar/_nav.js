export default {
  items: [
    {
      name: 'Gerar novo laudo',
      url: '/home',
      icon: 'icon-doc'
    },
    {
      name: 'Cadastros',
      url: '/entities',
      icon: 'icon-layers',
      children: [
        {
          name: 'Clientes',
          url: '/entities/clients',
          icon: 'icon-people'
        },
        {
          name: 'Usuários',
          url: '/entities/users',
          icon: 'icon-user'
        },
        {
          name: 'Equipamentos',
          url: '/entities/equipments',
          icon: 'icon-grid'
        },
        {
          name: 'Grupos/Categorias',
          url: '/entities/groups',
          icon: 'icon-drawer'
        },
        {
          name: 'Instrumentos de medição',
          url: '/entities/tools',
          icon: 'icon-calculator'
        },
        {
          name: 'Normas',
          url: '/entities/standards',
          icon: 'icon-vector'
        },
        {
          name: 'Ensaios',
          url: '/entities/tests',
          icon: 'icon-chemistry'
        },
        {
          name: 'Técnicos',
          url: '/entities/responsables',
          icon: 'icon-eyeglass'
        }
      ]
    },
    {
      name: 'Relatórios',
      url: '/reports',
      icon: 'icon-speedometer',
      children: [
        {
          name: 'Laudos',
          url: '/reports/report',
          icon: 'icon-docs'
        },
        {
          name: 'Consolidado',
          url: '/reports/consolidation',
          icon: 'icon-screen-tablet'
        }
      ]
    },
    {
      name: 'Configurações',
      url: '/settings',
      icon: 'icon-settings'
    }
  ]
};
