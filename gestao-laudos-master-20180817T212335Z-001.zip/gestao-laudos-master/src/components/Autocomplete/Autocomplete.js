import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import { Input, Col, ListGroup, ListGroupItem, Row } from 'reactstrap';
import index from 'react-notifications';

class Autocomplete extends Component {

  constructor(props) {
    super(props)

    this.state = {
      list: this._loadList(props.defaultList),
      field: this.props.field,
      currentValue: props.defaultValue,
      highlightedValue: props.defaultValue,
      showItems: false,
      query: ''
    }
  }

  componentWillReceiveProps(props) {
    this.setState({
      list: this._loadList(props.defaultList),
      currentValue: props.defaultValue,
      highlightedValue: props.defaultValue,
      showItems: false
    })
  }

  setValue(value) {
    this.setState({
      query: value
    })
  }

  _loadList(listToLoad) {
    if (!listToLoad || listToLoad.length === 0) {
      listToLoad = []
    }

    var newList = listToLoad;
    return newList;
  }

  clear() {
    this.setState({
      query: ''
    })
  }

  render() {
    return <div>
      <Input type="text"
        id={this.props.id}
        placeholder={this.props.placeholder}
        autoComplete="off"
        ref='input' value={this.state.query}
        onChange={this._onChange.bind(this)} onFocus={this._onFocus.bind(this)} onBlur={this._onBlur.bind(this)} //onClick={this._onInputClick.bind(this)}
      />
      {this.state.showItems ?
        <ListGroup className="autocomplete-dropdown">
          {
            this._currentMatches().slice(0, this.props.maxItemsShown).map(item =>
              <AutocompleteItem highlighted={item.id === this.state.highlightedValue}
                key={item.id} item={item} field={this.state.field}
                onItemClick={this._onItemClick.bind(this)} />
            )
          }
        </ListGroup>
        : null}
    </div>;
  }

  _currentMatches() {
    try {
      return (this.state.list)
        .filter(function (item) {
          return this.accentFold(item[this.state.field]).toLowerCase().indexOf(this._input().toLowerCase()) > -1;
        }.bind(this));
    } catch (e) {
      return this.state.list
    }
  }
  _highlightedIndex() {
    if (this._currentMatches()) {
      return (this._currentMatches())
        .findIndex(function (item) {
          return item.id === this.state.highlightedValue;
        }, this);
    }
  }
  _updateHighlightedValue() {
    var newValue;
    if (this._highlightedIndex() < 0) {
      newValue = this.state.list && this.state.list.length > 0 ? this.state.list[0].id : undefined;
    } else {
      newValue = this.state.list[this._.highlightedIndex()];
    }
    this.setState({ highlightedValue: newValue });
  }
  componentDidMount() {
    this._setInputFromValue();

    document.onkeydown = function (e) {
      switch (e.keyCode) {
        case 13: // enter
          this._setFromHighlighted();
          break;
        case 9: // tab
          this._setInputFromValue();
          // this._setFromHighlighted();
          break;
        case 27: // escape

          break;
        case 38: // up
          var hIndex = this._highlightedIndex();
          if (hIndex > 0) {
            this.setState({
              highlightedValue: this._currentMatches()[hIndex - 1].id,
              currentValue: this._currentMatches()[hIndex - 1]
            });
          }
          break;
        case 40: // down
          var hIndex = this._highlightedIndex();
          if (hIndex < this._currentMatches().length - 1) {
            this.setState({
              highlightedValue: this._currentMatches()[hIndex + 1].id,
              currentValue: this._currentMatches()[hIndex + 1]
            });
          }
          break;
      }
    }.bind(this);
  }

  componentWillUnmount() {
    this.setState({
      list: [],
      field: '',
      currentValue: '',
      highlightedValue: '',
      showItems: false,
      query: ''
    })
  }

  _setInputFromValue() {
    if (!this._isMounted) {
      return;
    }

    this.setState({
      query: this.state.currentValue[this.state.field]
    }).bind(this)
  }
  _setValueFromInput(event) {
    if (!this._isMounted) {
      return;
    }

    var inputText = this.state.query;
    var foundItem =
      this.state.list
        .find(function (item) {
          return item['name'].indexOf(inputText) > -1;
        });

    if (typeof foundItem !== 'undefined') {
      this.setState({
        currentValue: foundItem, highlightedValue: foundItem
      });
    } else {
      this.props.onNoMatch(this.state);
      if (this.props.limitToList) {
        this.setState({
          currentValue: this.props.defaultValue,
          highlightedValue: this.props.defaultValue.value
        });
      }
    }
  }
  _setFromHighlighted() {
    this.setState({
      query: this.state.currentValue[this.state.field]
    }, function () {
      this._setInputFromValue()
      this._setValueFromInput()
      this.props.onSelectItem(this.state.currentValue)
    }.bind(this))

  }
  _input() {
    return this.state.query;
  }
  _onChange(event) {
    this.setState({
      query: event.target.value
    });
    this._setValueFromInput();
  }
  _onFocus() {
    this.setState({ showItems: true });
  }
  _onBlur() {
    this.setState({ showItems: false });
  }
  _onItemClick(item) {
    this.setState({
      currentValue: item,
      query: item[this.state.field]
    }, function () {
      this._setInputFromValue();
      this.props.onSelectItem(item);
    }.bind(this));
  }

  accentFold(inStr) {
    return inStr.replace(/([àáâãäå])|([ç])|([èéêë])|([ìíîï])|([ñ])|([òóôõöø])|([ß])|([ùúûü])|([ÿ])|([æ])/g, function (str, a, c, e, i, n, o, s, u, y, ae) { if (a) return 'a'; else if (c) return 'c'; else if (e) return 'e'; else if (i) return 'i'; else if (n) return 'n'; else if (o) return 'o'; else if (s) return 's'; else if (u) return 'u'; else if (y) return 'y'; else if (ae) return 'ae'; });
  }
}

class AutocompleteItem extends Component {
  constructor(props) {
    super(props);

    this.state = { hover: false };
  }

  componentDidMount() {
    // document.onkeydown = function (e) {
    //   switch (e.keyCode) {
    //     case 13: // enter
    //       this.props.onItemClick(this.props.item);
    //       e.preventDefault();
    //       break;
    //   }
    // }.bind(this);
  }

  render() {
    return <ListGroupItem action
      className={this.props.highlighted ? 'text-info' : 'text-muted'}
      style={{ cursor: 'pointer' }}
      onClick={this._onClick.bind(this)}
      onMouseDown={this._onClick.bind(this)}>{this.props.item[this.props.field]}</ListGroupItem>;
  }
  _onClick() {
    this.props.onItemClick(this.props.item);
  }
}

export default Autocomplete;

Autocomplete.defaultProps = {
  defaultValue: {},
  limitToList: true,
  maxItemsShown: 5,
  sourceUrl: null,
  id: 'input',
  placeholder: 'Procurar...',
  defaultList: [
    { value: 1, label: 'Equipamento 1' },
    { value: 2, label: 'Equipamento 2' },
    { value: 3, label: 'Equipamento 3' },
    { value: 4, label: 'Equipamento 4' },
    { value: 5, label: 'Equipamento 5' }
  ],
  alsoSearchValues: false,
  loadUrlOnce: true,
  selectAllTextOnClick: true,
  onNoMatch: function () { },
  onSelectItem: function (item) { }
};

AutocompleteItem.defaultProps = {
  item: {
    value: null, label: null
  },
  onItemClick: function () { }, onItemMouseOver: function () { }, onItemMouseLeave: function () { }
}