const routes = {
  '/': 'Home',
  '/home': 'Novo laudo',
  '/entities': 'Cadastros',
  '/entities/clients': 'Clientes',
  '/entities/users': 'Usuários',
  '/entities/tools': 'Instrumentos',
  '/entities/standards': 'Normas',
  '/entities/equipments': 'Equipamentos',
  '/entities/groups': 'Grupos',
  '/entities/tests': "Ensaios",
  '/entities/reponsables': 'Técnicos',
  '/reports': 'Relatórios',
  '/reports/report': 'Laudos',
  '/reports/consolidation': 'Consolidade',
  '/settings': 'Configurações',
  '/client': 'Cliente'
};
export default routes;
