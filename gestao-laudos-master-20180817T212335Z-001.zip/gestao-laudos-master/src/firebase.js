import firebase from "firebase";

var config = {
  apiKey: "AIzaSyClVo7fXOn7SGYSz1JhlEUSrqf7LXQBDio",
  authDomain: "gestao-laudos.firebaseapp.com",
  databaseURL: "https://gestao-laudos.firebaseio.com",
  projectId: "gestao-laudos",
  storageBucket: "gs://gestao-laudos.appspot.com",
  messagingSenderId: "293546573021"
};

var authConfig = {
  apiKey: "AIzaSyClVo7fXOn7SGYSz1JhlEUSrqf7LXQBDio",
  authDomain: "gestao-laudos.firebaseapp.com",
  projectId: "gestao-laudos",
  messagingSenderId: "293546573021"
};

firebase.initializeApp(config);
export default firebase;

export const storage = firebase.storage();
export const database = firebase.database();
export const auth = firebase.auth();

export const secondary = firebase.initializeApp(authConfig, 'Secondary');
export const secondaryAuth = secondary.auth();