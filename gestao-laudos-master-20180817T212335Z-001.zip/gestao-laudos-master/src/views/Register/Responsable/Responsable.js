import React, { Component } from 'react';
import {
  Row,
  Col,
  Button,
  ButtonDropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
  Card,
  CardHeader,
  CardFooter,
  CardBody,
  Form,
  FormGroup,
  FormText,
  Label,
  Input,
  InputGroup,
  InputGroupAddon,
  InputGroupButton,
  ListGroup,
  ListGroupItem,
  Modal,
  ModalBody,
  ModalFooter,
  ModalHeader
} from 'reactstrap';
import InputMask from 'react-input-mask';
import { database } from '../../../firebase';
import {NotificationManager} from 'react-notifications';
import {BootstrapTable, TableHeaderColumn} from 'react-bootstrap-table';

function deleteTool(item) {
  if (confirm('Tem certeza que deseja deletar o técnico ' + item.name + ' ?')) {
    database.ref('responsables/' + item.id).remove();
  }
}

class Responsable extends Component {

  constructor(props) {
    super(props)

    this.state = {
      responsable: {},
      responsables: [],
      modal: false
    }

    this.toggle = this.toggle.bind(this);
  }

  componentWillMount() {
    database.ref('responsables').on('value', snapshot => {
      var responsables = [];
      snapshot.forEach(childSnapshot => {
        var responsable = childSnapshot.val();
        responsable.id = childSnapshot.key;
        responsables.push(responsable);
      })

      responsables.sort((a,b) => {return (a.name > b.name) ? 1 : ((b.name > a.name) ? -1 : 0)})

      this.setState({
        responsables
      })
    })
  }

  toggle() {
    this.setState(prevstate => ({
      modal: !prevstate.modal
    }));
  }

  createCustomSearchField(props) {
    return (
      <SearchField
        defaultValue={ props.defaultSearch }
        placeholder={ 'Pesquisar' }/>
    );
  }

  handleUserInput(event) {
    const name = event.target.name;
    const value = event.target.value.toUpperCase();
    let responsable = this.state.responsable

    responsable[name] = value;

    this.setState({
      responsable
    })
  }

  handleSubmit() {
    let responsable = this.state.responsable
    var key = database.ref().child('responsables').push().key;

    database.ref('responsables/' + key).set(responsable)
      .then(snapshot => {
        NotificationManager.success('Técnico salvo com sucesso!');
        window.scrollTo(0, 0)
        this.form.reset();
        this.toggle();
      });
  }

  onAfterSaveCell(row, cellName, cellValue) {
    let tool = { name: row.name.toUpperCase(), register: row.register.toUpperCase(), occupation: row.occupation.toUpperCase()}
    database.ref('responsables/' + row.id).update(tool);
  }

  buttonFormatter(cell, row){
    return (
      <Button onClick={() => deleteTool(row)}><i className="fa fa-trash" aria-hidden="true"></i></Button>
    );
  }

  render() {
    const options = { 
      noDataText: 'Não existem dados para esta pesquisa', 
      searchField: this.createCustomSearchField,
    } 

    const cellEditProp = {
      mode: 'dbclick',
      afterSaveCell: this.onAfterSaveCell  // a hook for after saving cell
    };

    return (
      <div>
        <Row>
          <Col sm={{size: 10, offset: 1}}>
            <Card>
              <CardHeader>
                Técnicos
              </CardHeader>
              <CardBody>
                <BootstrapTable version='4' data={this.state.responsables} search={true} cellEdit={ cellEditProp } hover pagination options={options}>
                  <TableHeaderColumn dataField='id' isKey hidden searchable={ false } >ID</TableHeaderColumn>
                  <TableHeaderColumn dataField='name' dataSort={ true }>Nome</TableHeaderColumn>
                  <TableHeaderColumn dataField='register' dataSort={ true }>Registro</TableHeaderColumn>
                  <TableHeaderColumn dataField='occupation' dataSort={ true }>Cargo</TableHeaderColumn>
                  <TableHeaderColumn dataField="button" width="60" editable={false} dataFormat={this.buttonFormatter}></TableHeaderColumn>
                </BootstrapTable>
              </CardBody>
              <CardFooter>
                <Button color="primary" className="float-right" onClick={this.toggle}><i className="fa fa-plus" aria-hidden="true"></i> Adicionar</Button>
              </CardFooter>
            </Card>
          </Col>
        </Row>
        
        <Modal isOpen={this.state.modal} toggle={this.toggle}>
          <ModalHeader toggle={this.toggle}>Adicionar Técnico</ModalHeader>
          <ModalBody>
            <form ref={(el) => this.form = el}>
              <Row>
                <Col xs="12" sm="6">
                  <FormGroup>
                    <Label htmlFor="name">Nome</Label>
                    <Input type="text" id="name" name="name" placeholder="Nome" onChange={this.handleUserInput.bind(this)} />
                  </FormGroup>
                </Col>
                <Col xs="12" sm="6">
                  <FormGroup>
                    <Label htmlFor="register">Registro</Label>
                    <Input type="text" id="register" className="form-control" name="register"  placeholder="12345" onChange={this.handleUserInput.bind(this)} />
                  </FormGroup>
                </Col>
              </Row>
              <Row>
                <Col xs="12">
                  <FormGroup>
                    <Label htmlFor="occupation">Cargo</Label>
                    <Input type="text" id="occupation" name="occupation" placeholder="Cargo" onChange={this.handleUserInput.bind(this)} />
                  </FormGroup>
                </Col>
              </Row>
            </form>
          </ModalBody>
          <ModalFooter>
            <Button color="primary" onClick={this.handleSubmit.bind(this)}>Salvar</Button>
            <Button color="secondary" onClick={this.toggle}>Cancelar</Button>
          </ModalFooter>
        </Modal> 
      </div>
    )
  }
}

export default Responsable;