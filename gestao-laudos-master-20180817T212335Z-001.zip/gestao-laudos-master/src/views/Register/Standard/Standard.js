import React, { Component } from 'react';
import {
  Row,
  Col,
  Button,
  ButtonDropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
  Card,
  CardHeader,
  CardFooter,
  CardBody,
  Form,
  FormGroup,
  FormText,
  Label,
  Input,
  InputGroup,
  InputGroupAddon,
  InputGroupButton,
  ListGroup,
  ListGroupItem,
  Modal,
  ModalBody,
  ModalFooter,
  ModalHeader
} from 'reactstrap';
import {database} from '../../../firebase';
import {NotificationManager} from 'react-notifications';
import {BootstrapTable, TableHeaderColumn} from 'react-bootstrap-table';

function deleteTool(item) {
  if (confirm('Tem certeza que deseja deletar a norma ' + item.name + ' ?')) {
    database.ref('standards/' + item.id).remove();
  }
}

class Standard extends Component {

  constructor(props) {
    super(props);

    this.state = {
      name: '',
      standards: [],
      modal: false
    }

    this.toggle = this.toggle.bind(this);
  }

  componentWillMount() {
    database.ref('standards').on('value', snapshot => {
      var standards = [];
      snapshot.forEach(childSnapshot => {
        var standard = {};
        standard.name = childSnapshot.val();
        standard.id = childSnapshot.key;
        standards.push(standard);
      })
      standards.sort((a,b) => {return (a.name > b.name) ? 1 : ((b.name > a.name) ? -1 : 0)})

      this.setState({
        standards
      })
    })
  }

  toggle() {
    this.setState(prevstate => ({
      modal: !prevstate.modal
    }));
  }

  onChangeName(event) {
    this.setState({
      name: event.target.value.toUpperCase()
    })
  }

  onSubmit() {
    let standard = this.state.name;
    database.ref('standards').push().set(standard)
      .then(snapshot => {
        NotificationManager.success('Norma salva com sucesso!');
        window.scrollTo(0, 0)
        this.form.reset();
        this.toggle();
      });
  }

  onAfterSaveCell(row, cellName, cellValue) {
    let standard = row.name.toUpperCase()
    database.ref('standards/' + row.id).set(standard);
  }

  buttonFormatter(cell, row){
    return (
      <Button onClick={() => deleteTool(row)}><i className="fa fa-trash" aria-hidden="true"></i></Button>
    );
  }

  createCustomSearchField(props) {
    return (
      <SearchField
        defaultValue={ props.defaultSearch }
        placeholder={ 'Pesquisar' }/>
    );
  }

  render() {
    const options = { 
      noDataText: 'Não existem dados para esta pesquisa', 
      searchField: this.createCustomSearchField,
    } 

    const cellEditProp = {
      mode: 'dbclick',
      afterSaveCell: this.onAfterSaveCell  // a hook for after saving cell
    };

    return (
      <div>
        <Row>
          <Col sm={{size: 10, offset: 1}}>
            <Card>
              <CardHeader>
                Normas
              </CardHeader>
              <CardBody>
                <BootstrapTable version='4' data={this.state.standards} search={true} cellEdit={ cellEditProp } hover pagination options={options}>
                  <TableHeaderColumn dataField='id' isKey hidden searchable={ false } >ID</TableHeaderColumn>
                  <TableHeaderColumn dataField='name' dataSort={ true }>Norma</TableHeaderColumn>
                  <TableHeaderColumn dataField="button" width="60" editable={false} dataFormat={this.buttonFormatter}></TableHeaderColumn>
                </BootstrapTable>
              </CardBody>
              <CardFooter>
                <Button color="primary" onClick={this.toggle} className="float-right"><i className="fa fa-plus" aria-hidden="true"></i> Adicionar</Button>
              </CardFooter>
            </Card>
          </Col>
        </Row>
        
        <Modal isOpen={this.state.modal} toggle={this.toggle}>
          <ModalHeader toggle={this.toggle}>Adicionar Norma</ModalHeader>
          <ModalBody>
            <form ref={(el) => this.form = el}>
              <Row>
                <Col xs="12">
                  <FormGroup>
                    <Label htmlFor="name">Nome da norma</Label>
                    <Input type="text" id="name" name="name" onChange={this.onChangeName.bind(this)} placeholder="NR2309" />
                  </FormGroup>
                </Col>
              </Row>
            </form>
          </ModalBody>
          <ModalFooter>
            <Button color="primary" onClick={this.onSubmit.bind(this)}>Salvar</Button>
            <Button color="secondary" onClick={this.toggle}>Cancelar</Button>
          </ModalFooter>
        </Modal>  
      </div>
    )
  }
}

export default Standard;