import React, { Component } from 'react';
import {
  Row,
  Col,
  Button,
  ButtonDropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
  Card,
  CardHeader,
  CardFooter,
  CardBody,
  Form,
  FormGroup,
  FormText,
  Label,
  Input,
  InputGroup,
  InputGroupAddon,
  InputGroupButton,
  ListGroup,
  ListGroupItem,
  Modal,
  ModalBody,
  ModalFooter,
  ModalHeader
} from 'reactstrap';
import {database} from '../../../firebase';
import {NotificationManager} from 'react-notifications';
import {BootstrapTable, TableHeaderColumn} from 'react-bootstrap-table';

function deleteTool(item) {
  if (confirm('Tem certeza que deseja deletar o instrumento Nº ' + item.serial + ' ?')) {
    database.ref('tools/' + item.id).remove();
  }
}

class Tool extends Component {

  constructor(props) {
    super(props);

    this.state = {
      tool:{},
      tools: [],
      modal: false,
      selectedField: {},
      fields: []
    }

    this.handleInput = this.handleInput.bind(this);
    this.toggle = this.toggle.bind(this);
  }

  componentWillMount() {
    database.ref('tools').on('value', snapshot => {
      var tools = [];
      snapshot.forEach(childSnapshot => {
        var tool = childSnapshot.val();
        tool.id = childSnapshot.key;
        tools.push(tool);
      })
      tools.sort((a,b) => {return (a.name > b.name) ? 1 : ((b.name > a.name) ? -1 : 0)})

      this.setState({
        tools
      })
    })
  }

  toggle() {
    this.setState(prevstate => ({
      modal: !prevstate.modal
    }));
  }

  onChangeField(event) {
    var name = event.target.name;
    var value = event.target.value.toUpperCase();

    let selectedField = this.state.selectedField
    selectedField[name] = value;

    this.setState({
      selectedField
    })
  }

  onAddField() {
    let field = this.state.selectedField;
    field.field = field.field ? field.field.replace(".","").toUpperCase() : ""

    this.setState({
      fields: [...this.state.fields, field],
      selectedField: {}
    }, () => this.fields.reset())
  }

  onRemoveField(field) {
    var fields = this.state.fields.filter(function(val) { return val.field !== field.field })
    this.setState({
      fields
    })
  }

  dragStart(e){
    e.dataTransfer.setData("text/html", e.target);
    e.dataTransfer.effectAllowed = "move";
    // Firefox requires dataTransfer data to be set
    this.setState({ draggedItemIndex: e.target.id })
  }

  dragOver(e) {
    e.preventDefault();
    e.dataTransfer.dropEffect = "move"
  }

  onDrop(e) {
    e.preventDefault()
    const droppedItemId = e.currentTarget.id
    const movedItem = this.state.fields[this.state.draggedItemIndex];
    const remainingItems = this.state.fields.filter((item, index) => index != this.state.draggedItemIndex);

    const reorderedItems = [
      ...remainingItems.slice(0, droppedItemId),
      movedItem,
      ...remainingItems.slice(droppedItemId)
  ];

    this.setState({
      fields: reorderedItems
    })
    this.setState({ draggedItemIndex: null })
  }

  createCustomSearchField(props) {
    return (
      <SearchField
        defaultValue={ props.defaultSearch }
        placeholder={ 'Pesquisar' }/>
    );
  }

  createCustomClearButton(onClick) {
    return (
      <ClearSearchButton
        btnText='Limpar'
        btnContextual='btn-warning'
        onClick={onClick}/>
    );
  }

  handleInput(event) {
    let name = event.target.name;
    let value = event.target.value.toUpperCase();
    let tool = this.state.tool;

    tool[name] = value;

    this.setState({
      tool
    })
  }

  handleSubmit() {
    let tool = this.state.tool;
    tool.fields = this.state.fields;

    if (this.state.isEditing) {
      database.ref('tools').child(tool.id).set(tool)
        .then(snapshot => {
          NotificationManager.success('Instrumento salvo com sucesso!');
          window.scrollTo(0, 0)
          this.form.reset();
          this.toggle();
        });
    } else {
      database.ref('tools').push().set(tool)
        .then(snapshot => {
          NotificationManager.success('Instrumento salvo com sucesso!');
          window.scrollTo(0, 0)
          this.form.reset();
          this.toggle();
        });
    }
  }

  buttonFormatter(cell, row){
    return (
      <Button onClick={() => deleteTool(row)}><i className="fa fa-trash" aria-hidden="true"></i></Button>
    );
  }

  editTool() {
    if (this.state.tool) {
      this.setState({
        fields: this.state.tool.fields || []
      }, this.toggle())
    }
  }

  addTool() {
    this.setState({
      tool: {},
      fields: [],
      isEditing: false
    }, this.toggle())
  }

  render() {
    const options = { 
      noDataText: 'Não existem dados para esta pesquisa', 
      searchField: this.createCustomSearchField,
      onRowDoubleClick: row => {
        this.setState({
          tool: row,
          isEditing: true
        }, () => {this.editTool()})
      }
    } 

    return (
      <div>
        <Row>
          <Col sm={{size: 10, offset: 1}}>
            <Card>
              <CardHeader>
                Instrumentos de medição
              </CardHeader>
              <CardBody>
                <BootstrapTable version='4' data={this.state.tools} search={true} hover pagination options={options}>
                  <TableHeaderColumn dataField='id' isKey hidden searchable={ false } >ID</TableHeaderColumn>
                  <TableHeaderColumn dataField='serial' dataSort={ true }>Nº Série</TableHeaderColumn>
                  <TableHeaderColumn dataField='name' dataSort={ true }>Razão social</TableHeaderColumn>
                  <TableHeaderColumn dataField='brand' dataSort={ true }>Marca</TableHeaderColumn>
                  <TableHeaderColumn dataField='model' dataSort={ true } >Modelo</TableHeaderColumn>
                  <TableHeaderColumn dataField='callibration' dataSort={ true } >Calibração</TableHeaderColumn>
                  <TableHeaderColumn dataField="button" width="60" editable={false} dataFormat={this.buttonFormatter}></TableHeaderColumn>
                </BootstrapTable>
              </CardBody>
              <CardFooter>
                <Button color="primary" onClick={this.addTool.bind(this)} className="float-right"><i className="fa fa-plus" aria-hidden="true"></i> Adicionar</Button>
              </CardFooter>
            </Card>
          </Col>
        </Row>

        <Modal isOpen={this.state.modal} toggle={this.toggle}>
          <ModalHeader toggle={this.toggle}>Adicionar instrumento de medição</ModalHeader>
          <ModalBody>
            <form ref={(el) => this.form = el}>
              <Row>
                <Col xs="12" sm="8">
                  <FormGroup>
                    <Label htmlFor="name">Nome do instrumento</Label>
                    <Input type="text" id="name" name="name" value={this.state.tool.name} onChange={this.handleInput} placeholder="Medidor de tensão" />
                  </FormGroup>
                </Col>
                <Col xs="12" sm="4">
                  <FormGroup>
                    <Label htmlFor="brand">Marca</Label>
                    <Input type="text" id="brand" name="brand" value={this.state.tool.brand} onChange={this.handleInput} placeholder="Marca" />
                  </FormGroup>
                </Col>
              </Row>
              <Row>
                <Col xs="12" sm="4">
                  <FormGroup>
                    <Label htmlFor="model">Modelo</Label>
                    <Input type="text" id="model" name="model" value={this.state.tool.model} onChange={this.handleInput} placeholder="Modelo do equipamento" />
                  </FormGroup>
                </Col>
                <Col xs="12" sm="4">
                  <FormGroup>
                    <Label htmlFor="serial">Nº de Série</Label>
                    <Input type="text" id="serial" name="serial" value={this.state.tool.serial} onChange={this.handleInput} placeholder="12345" />
                  </FormGroup>
                </Col>
                <Col xs="12" sm="4">
                  <FormGroup>
                    <Label htmlFor="callibration">Calibração</Label>
                    <Input type="text" id="callibration" name="callibration" value={this.state.tool.callibration} onChange={this.handleInput} placeholder="Fev/2017" />
                  </FormGroup>
                </Col>
              </Row>
              <form ref={el => this.fields = el}>
              <Row>
                <Col xs="12" sm="6">
                  <FormGroup>
                    <Label htmlFor="field">Nome do campo</Label>
                    <Input type="text" id="field" name="field" onChange={this.onChangeField.bind(this)} placeholder="Placa" />
                  </FormGroup>
                </Col>
                <Col xs="12" sm="4">
                  <FormGroup>
                    <Label htmlFor="type">Tipo do campo</Label>
                    <Input type="select" id="type" name="type" onChange={this.onChangeField.bind(this)} placeholder="Tipo" >
                      <option value="invalid">Selecione</option>
                      <option value="text">Texto</option>
                      <option value="number">Número</option>
                    </Input>
                  </FormGroup>
                </Col>
                <Col xs="12" sm="2">
                  <Row><Label>&nbsp;</Label></Row>
                  <Button color="secondary" onClick={this.onAddField.bind(this)}><i className="fa fa-plus" aria-hidden="true"></i></Button>
                </Col>
              </Row>
              </form>
              <Row>
                <Col xs="12">
                  <ListGroup>
                      { this.state.fields.map((field, i) => 
                      field &&
                        <ListGroupItem key={i} data-id={i} 
                          draggable='true'
                          id={i}
                          onDragOver={this.dragOver.bind(this)}
                          onDrop={this.onDrop.bind(this)}
                          onDragStart={this.dragStart.bind(this)}>
                            {field.field}
                            <span xs="1" style={{cursor: 'pointer'}} className="float-right" 
                              onClick={this.onRemoveField.bind(this, field)}>
                              <i className="fa fa-times" aria-hidden="true"></i></span>
                        </ListGroupItem>)
                      }              
                  </ListGroup>
                </Col>
              </Row>
            </form>
          </ModalBody>
          <ModalFooter>
            <Button color="primary" onClick={this.handleSubmit.bind(this)}>Salvar</Button>
            <Button color="secondary" onClick={this.toggle}>Cancelar</Button>
          </ModalFooter>
        </Modal>  
      </div>
    )
  }
}

export default Tool;