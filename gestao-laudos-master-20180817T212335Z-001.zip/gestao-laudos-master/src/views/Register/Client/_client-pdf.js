import jsPDF from 'jspdf';
import { autoTableHtmlToJson, autoTable } from 'jspdf-autotable';

var footer = "Este documento foi emitido a partir do sistema de gestão da empresa 08.618.923/0001-13 e sua veracidade poderá ser consultada no site https://laudostecnicosee.com.br/"

export function savePdf(list, fields) {
  var doc = new jsPDF('p', 'mm', 'a4', true);

  var infoHeader = [
    "Razão Social",
    "CNPJ",
    "Limite"
  ]

  var next = undefined;

  doc.setFontStyle('bold');
  doc.text("Clientes", 16, 10);

  var pageContent = function (data) {

    // FOOTER
    doc.setFontType('normal')
    doc.setFontSize(7);
    doc.text(footer, data.settings.margin.left, doc.internal.pageSize.height - 10);
  };

  (list || []).sort((a, b) => {
    var nameA = a.name.toLowerCase();
    var nameB = b.name.toLowerCase();
    if (nameA < nameB) return -1;
    if (nameA > nameB) return 1;
    return 0;
  }).forEach(item => {

    var infoRows = [];
    var line = [];
    line.push(item.name);
    line.push(item.cnpj);
    line.push(item.limit);
    infoRows.push(line);

    doc.autoTable(infoHeader, infoRows, {
      styles: { overflow: 'linebreak', cellPadding: 2.5, fontSize: 10, lineWidth: 0.1 },
      startY: next ? next.finalY + 5 : 17,
      theme: 'plain',
      showHeader: 'firstPage',
      addPageContent: pageContent,
      columnStyles: {
        1: { columnWidth: 50 },
        2: { columnWidth: 20 }
      },
    });

    next = doc.autoTable.previous;

    if (fields.responsable) {
      var responsableHeader = [
        "Nome do Representante",
        "Telefone",
        "Email"
      ]

      if (item.responsable) {
        var responsableRows = [];
        line = [];
        line.push(item.responsable.name);
        line.push(item.responsable.phone);
        line.push(item.responsable.email);
        responsableRows.push(line);

        doc.autoTable(responsableHeader, responsableRows, {
          styles: { overflow: 'linebreak', cellPadding: 2.5, fontSize: 10, lineWidth: 0.1 },
          theme: 'plain',
          showHeader: 'firstPage',
          startY: next.finalY
        });

        next = doc.autoTable.previous;
      } else if (item.responsables) {
        var responsableRows = [];

        item.responsables.forEach(responsable => {
          line = [];
          line.push(responsable.name);
          line.push(responsable.phone);
          line.push(responsable.email);
          responsableRows.push(line);
        })


        doc.autoTable(responsableHeader, responsableRows, {
          styles: { overflow: 'linebreak', cellPadding: 2.5, fontSize: 10, lineWidth: 0.1 },
          theme: 'plain',
          showHeader: 'firstPage',
          startY: next.finalY
        });

        next = doc.autoTable.previous;
      }
    }

    if (fields.address) {
      var address1Header = [
        "Rua",
        "Nº",
        "Complemento"
      ]

      var address1Rows = [];
      line = [];
      line.push(item.address.street);
      line.push(item.address.number);
      line.push(item.address.complement);
      address1Rows.push(line);

      doc.autoTable(address1Header, address1Rows, {
        styles: { overflow: 'linebreak', cellPadding: 2.5, fontSize: 10, lineWidth: 0.1 },
        theme: 'plain',
        startY: next.finalY,
        showHeader: 'firstPage',
        columnStyles: {
          1: { columnWidth: 20 },
        }
      });

      next = doc.autoTable.previous;

      var address2Header = [
        "Bairro",
        "CEP",
        "Cidade",
        "Estado"
      ]

      var address2Rows = [];
      line = [];
      line.push(item.address.neighborhood);
      line.push(item.address.cep);
      line.push(item.address.city);
      line.push(item.address.state);
      address2Rows.push(line);

      doc.autoTable(address2Header, address2Rows, {
        styles: { overflow: 'linebreak', cellPadding: 2.5, fontSize: 10, lineWidth: 0.1 },
        theme: 'plain',
        showHeader: 'firstPage',
        startY: next.finalY
      });

      next = doc.autoTable.previous;
    }

    if (item.units && fields.unit) {
      doc.autoTable([], [], {
        startY: next.finalY,
        addPageContent: (data) => {
          doc.rect(data.settings.margin.left, next.finalY, data.table.width, 7, 'S');
          doc.setFontStyle('bold');
          doc.setFontSize(10);
          doc.text("Unidades", data.settings.margin.left + 2, next.finalY + 4.5);
        }
      })

      next = doc.autoTable.previous;

      var y = 7;

      item.units.forEach(unit => {
        var unitHeader = [
          "Nome",
          "Limite"
        ]

        var unitRows = [];
        line = [];
        line.push(unit.name);
        line.push(unit.limit);
        unitRows.push(line);

        doc.autoTable(unitHeader, unitRows, {
          styles: { overflow: 'linebreak', cellPadding: 2.5, fontSize: 10, lineWidth: 0.1 },
          theme: 'plain',
          startY: next.finalY + y,
          showHeader: 'firstPage',
          columnStyles: {
            1: { columnWidth: 20 },
          }
        });

        next = doc.autoTable.previous;
        y = 0;

        var address1Header = [
          "Rua",
          "Nº",
          "Complemento"
        ]

        var address1Rows = [];
        line = [];
        line.push(unit.address.street);
        line.push(unit.address.number);
        line.push(unit.address.complement);
        address1Rows.push(line);

        doc.autoTable(address1Header, address1Rows, {
          styles: { overflow: 'linebreak', cellPadding: 2.5, fontSize: 10, lineWidth: 0.1 },
          theme: 'plain',
          startY: next.finalY,
          showHeader: 'firstPage',
          columnStyles: {
            1: { columnWidth: 20 },
          }
        });

        next = doc.autoTable.previous;

        var address2Header = [
          "Bairro",
          "CEP",
          "Cidade",
          "Estado"
        ]

        var address2Rows = [];
        line = [];
        line.push(unit.address.neighborhood);
        line.push(unit.address.cep);
        line.push(unit.address.city);
        line.push(unit.address.state);
        address2Rows.push(line);

        doc.autoTable(address2Header, address2Rows, {
          styles: { overflow: 'linebreak', cellPadding: 2.5, fontSize: 10, lineWidth: 0.1 },
          theme: 'plain',
          showHeader: 'firstPage',
          startY: next.finalY
        });

        next = doc.autoTable.previous;
      })
    }

    if (item.departments && fields.department) {
      doc.autoTable([], [], {
        startY: next.finalY,
        addPageContent: (data) => {
          doc.rect(data.settings.margin.left, next.finalY, data.table.width, 7, 'S');
          doc.setFontStyle('bold');
          doc.setFontSize(10);
          doc.text("Departamentos", data.settings.margin.left + 2, next.finalY + 4.5);
        }
      })

      next = doc.autoTable.previous;

      var departmentsHeader = [
        "Nome",
        "Limite"
      ]

      var departmentsRows = [];

      item.departments.forEach(unit => {
        line = [];
        line.push(unit.name);
        line.push(unit.limit);
        departmentsRows.push(line);
      });

      doc.autoTable(departmentsHeader, departmentsRows, {
        styles: { overflow: 'linebreak', cellPadding: 2.5, fontSize: 10, lineWidth: 0.1 },
        theme: 'plain',
        startY: next.finalY + 7,
        showHeader: 'firstPage',
        columnStyles: {
          1: { columnWidth: 20 },
        }
      });

      next = doc.autoTable.previous;

    }

  })

  var blob = doc.output("blob");
  window.open(URL.createObjectURL(blob));
}