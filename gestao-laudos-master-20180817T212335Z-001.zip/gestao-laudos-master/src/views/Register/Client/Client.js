import React, { Component } from 'react';
import {
  Row,
  Col,
  Button,
  ButtonDropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
  Card,
  CardHeader,
  CardFooter,
  CardBody,
  Form,
  FormGroup,
  FormText,
  Label,
  Input,
  InputGroup,
  InputGroupAddon,
  InputGroupButton,
  ListGroup,
  ListGroupItem,
  Modal,
  ModalBody,
  ModalFooter,
  ModalHeader
} from 'reactstrap';
import InputMask from 'react-input-mask';
import { database, secondaryAuth } from '../../../firebase';
import { NotificationManager } from 'react-notifications';
import { BootstrapTable, TableHeaderColumn } from 'react-bootstrap-table';
import * as pdf from './_client-pdf';
import cep from 'cep-promise';

function ValidaCep(cep) {
  var exp = /\d{2}\d{3}\-\d{3}/;
  return (exp.test(cep.value))
}

function validarCNPJ(cnpj) {

  cnpj = cnpj.replace(/[^\d]+/g, '');

  if (cnpj == '') return false;

  if (cnpj.length != 14)
    return false;

  // Elimina CNPJs invalidos conhecidos
  if (cnpj == "00000000000000" ||
    cnpj == "11111111111111" ||
    cnpj == "22222222222222" ||
    cnpj == "33333333333333" ||
    cnpj == "44444444444444" ||
    cnpj == "55555555555555" ||
    cnpj == "66666666666666" ||
    cnpj == "77777777777777" ||
    cnpj == "88888888888888" ||
    cnpj == "99999999999999")
    return false;

  // Valida DVs
  var tamanho = cnpj.length - 2
  var numeros = cnpj.substring(0, tamanho);
  var digitos = cnpj.substring(tamanho);
  var soma = 0;
  var pos = tamanho - 7;
  for (var i = tamanho; i >= 1; i--) {
    soma += numeros.charAt(tamanho - i) * pos--;
    if (pos < 2)
      pos = 9;
  }
  resultado = soma % 11 < 2 ? 0 : 11 - soma % 11;
  if (resultado != digitos.charAt(0))
    return false;

  tamanho = tamanho + 1;
  numeros = cnpj.substring(0, tamanho);
  soma = 0;
  pos = tamanho - 7;
  for (i = tamanho; i >= 1; i--) {
    soma += numeros.charAt(tamanho - i) * pos--;
    if (pos < 2)
      pos = 9;
  }
  var resultado = soma % 11 < 2 ? 0 : 11 - soma % 11;
  if (resultado != digitos.charAt(1))
    return false;

  return true;

}

const responsableFormatter = (cell, row) => (
  cell ? <span>{cell.name}<br />{cell.phone}</span>
    : row.responsables ? <span>{row.responsables[0].name}<br />{row.responsables[0].phone}</span> : '');

function deleteTool(item) {
  if (confirm('Tem certeza que deseja deletar o cliente ' + item.name + ' ?')) {
    database.ref('clients/' + item.id).remove();
  }
}

class Client extends Component {

  constructor(props) {
    super(props)

    this.state = {
      clients: [],
      hasBranchs: false,
      hasUnits: false,
      branches: [],
      units: [],
      selectedBranch: {},
      selectedUnit: {},
      users: [],
      clientModal: false,
      reportModal: false,
      address: {},
      fields: {},
      responsables: [],
      registeredCnpj: false
    }

    this.toggle = this.toggle.bind(this);
    this.toggleClient = this.toggleClient.bind(this);
    this.editClient = this.editClient.bind(this);
    this.toggleReport = this.toggleReport.bind(this);
  }

  componentWillMount() {
    database.ref('clients').on('value', snapshot => {
      var clients = [];
      snapshot.forEach(childSnapshot => {
        var client = childSnapshot.val();
        client.id = childSnapshot.key;
        clients.push(client);
      });

      clients.sort((a, b) => { return (a.name > b.name) ? 1 : ((b.name > a.name) ? -1 : 0) })

      this.setState({
        clients
      })
    })

    database.ref('users').on('value', snapshot => {
      var users = [];
      snapshot.forEach(childSnapshot => {
        var user = childSnapshot.val();
        user.id = childSnapshot.key;
        if (!user.employee) users.push(user);
      })

      users.sort((a, b) => { return (a.name > b.name) ? 1 : ((b.name > a.name) ? -1 : 0) })

      this.setState({
        users
      })
    })
  }

  createCustomSearchField(props) {
    return (
      <SearchField
        defaultValue={props.defaultSearch}
        placeholder={'Pesquisar'} />
    );
  }

  createCustomClearButton(onClick) {
    return (
      <ClearSearchButton
        btnText='Limpar'
        btnContextual='btn-warning'
        onClick={onClick} />
    );
  }

  toggle() {
    this.setState(prevstate => ({
      modal: !prevstate.modal
    }));
  }

  toggleClient() {
    this.setState(prevState => ({
      clientModal: !prevState.clientModal
    }))
  }

  toggleReport() {
    this.setState(prevState => ({
      reportModal: !prevState.reportModal,
      fields: {}
    }))
  }

  onChangeBranch(event) {
    this.setState({
      hasBranchs: event.target.checked
    })
  }

  onChangeUnit(event) {
    this.setState({
      hasUnits: event.target.checked
    })
  }

  onChangeAddBranchName(event) {
    var name = event.target.value.toUpperCase()

    this.setState(prevState => ({
      selectedBranch: { name, limit: prevState.selectedBranch.limit || 0 }
    }))
  }

  onChangeAddBranchLimit(event) {
    var limit = event.target.value;
    if (limit.length === 0) limit = undefined;

    this.setState(prevState => ({
      selectedBranch: { name: prevState.selectedBranch.name, limit }
    }))
  }

  onAddBranch() {
    if (this.state.selectedBranch != null &&
      this.state.selectedBranch.name != null &&
      this.state.selectedBranch.name.length > 0) {
      this.setState(prevState => ({
        branches: [...prevState.branches, prevState.selectedBranch]
      }))
    }
  }

  onRemoveBranch(branch) {
    this.setState(prevState => ({
      branches: prevState.branches.filter(function (val) { return val.name !== branch.name })
    }))
  }

  onChangeAddUnitName(event) {
    var name = event.target.value.toUpperCase();
    this.setState(prevState => ({
      selectedUnit: { name, address: prevState.selectedUnit.address, limit: prevState.selectedUnit.limit }
    }))
  }

  onChangeAddress(event) {
    var name = event.target.name;
    var value = event.target.value.toUpperCase();
    let address = this.state.address;

    address[name] = value;

    this.setState(prevState => ({
      address
    }))
  }

  onBlurCep(event) {
    cep(event.target.value)
      .then(result => {
        let address = this.state.address || {};
        address.street = result.street.toUpperCase();
        address.neighborhood = result.neighborhood.toUpperCase();
        address.city = result.city.toUpperCase();
        address.state = result.state.toUpperCase();
        this.setState({
          address
        })
      })
      .catch(error => {
        NotificationManager.error('Não foi possível buscar informações do CEP digitado.')
      })
  }

  onBlurUnitCep(event) {
    cep(event.target.value)
      .then(result => {
        let selectedUnit = this.state.selectedUnit;
        let address = selectedUnit.address || {};
        address.street = result.street.toUpperCase();
        address.neighborhood = result.neighborhood.toUpperCase();
        address.city = result.city.toUpperCase();
        address.state = result.state.toUpperCase();
        selectedUnit.address = address;
        this.setState({
          selectedUnit
        })
      })
      .catch(error => {
        NotificationManager.error('Não foi possível buscar informações do CEP digitado.')
      })
  }

  onChangeAddUnitAddress(event) {
    var name = event.target.name;
    var value = event.target.value.toUpperCase();
    let selectedUnit = this.state.selectedUnit;
    let address = selectedUnit.address || {};

    address[name] = value;
    address.address_string = (address.street ? address.street : "") + (", " + address.number || "") + " " + (address.complement || "") +
      (" - " + address.neighborhood || "") + (" / " + address.city || "") + (" - " + address.state || "")

    selectedUnit.address = address;

    this.setState(prevState => ({
      selectedUnit
    }))
  }

  onChangeAddUnitLimit(event) {
    var limit = event.target.value;
    this.setState(prevState => ({
      selectedUnit: { name: prevState.selectedUnit.name, address: prevState.selectedUnit.address, limit }
    }))
  }

  onAddUnit() {
    if (this.state.selectedUnit != null &&
      this.state.selectedUnit.name != null &&
      this.state.selectedUnit.name.length > 0) {

      this.setState(prevState => ({
        units: [...prevState.units, prevState.selectedUnit]
      }))
    }
  }

  onRemoveUnit(unit) {
    this.setState(prevState => ({
      units: prevState.units.filter(function (val) { return val.name !== unit.name })
    }))
  }

  handleUserInput(event) {
    const name = event.target.name;
    const value = event.target.value.toUpperCase();

    this.setState({
      [name]: value
    })
  }

  onBlurCnpj(event) {
    const cnpj = event.target.value;
    const found = this.state.clients.find(client => { return client.cnpj === cnpj });
    if (found) {
      event.preventDefault();
      this.setState({ registeredCnpj: true })
      NotificationManager.error('CNPJ já cadastrado!')
    } else this.setState({ registeredCnpj: false })
  }

  handleSubmit() {
    if (this.state.registeredCnpj) {
      NotificationManager.error('CNPJ já cadastrado!')
    } else {
      let name = this.state.name;
      let cnpj = this.state.cnpj;
      let responsables = this.state.responsables;
      let limit = this.state.limit && this.state.limit.length > 0 ? Number.parseInt(this.state.limit) : null;
      let address = this.state.address;
      let departments = this.state.hasBranchs ? this.state.branches : null;
      let units = this.state.hasUnits ? this.state.units : null;

      address.address_string = (address.street ? address.street : "") + (address.number ? ", " + address.number : "") + (address.complement ? " " + address.complement : "") +
        (address.neighborhood ? " - " + address.neighborhood : "") + (address.city ? " / " + address.city : "") + (address.state ? " - " + address.state : "")

      var client = { name, cnpj, responsables, limit, address, departments, units };
      if (validarCNPJ(cnpj)) {
        if (!this.state.isEditing) {
          var key = database.ref().child('clients').push().key;

          database.ref('clients/' + key).set(client)
            .then(snapshot => {
              NotificationManager.success('Cliente salvo com sucesso!');
              this.form.reset();
              window.scrollTo(0, 0)
              this.toggle();
            });
        } else {
          database.ref('clients/' + this.state.id).update(client)
            .then(snapshot => {
              NotificationManager.success('Cliente atualizado com sucesso!');
              this.form.reset();
              window.scrollTo(0, 0)
              this.toggle();
            });
        }
      } else {
        NotificationManager.warning('CNPJ inválido!');
      }
    }
  }

  editClient(item) {
    this.toggle();

    this.setState({
      name: item.name,
      cnpj: item.cnpj,
      responsables: item.responsables || [],
      responsableName: item.responsable ? item.responsable.name : '',
      responsablePhone: item.responsable ? item.responsable.phone : '',
      responsableEmail: item.responsable ? item.responsable.email : '',
      limit: item.limit,
      address: item.address || {},
      hasBranchs: item.departments != null,
      branches: item.departments || [],
      hasUnits: item.units != null,
      units: item.units || [],
      id: item.id,
      isEditing: true
    })
  }

  addClient() {
    this.toggle();

    this.setState({
      name: '',
      cnpj: '',
      responsableName: '',
      responsablePhone: '',
      responsableEmail: '',
      limit: '',
      address: {},
      hasBranchs: false,
      branches: [],
      hasUnits: false,
      units: [],
      isEditing: false,
      responsables: []
    })
  }

  addUser() {
    this.toggleClient();
  }

  companyFormatter(cell, row) {
    var found = this.state.clients.find(item => item.id == cell);
    return (
      <span>{found ? found.name : ''}</span>
    )
  }

  buttonFormatter(cell, row) {
    return (
      <div>
        <Button onClick={() => deleteTool(row)}><i className="fa fa-trash" aria-hidden="true"></i></Button>
      </div>
    );
  }

  showPdf() {
    pdf.savePdf(this.state.clients, this.state.fields);
    window.scrollTo(0, 0)
    this.toggleReport();
  }

  onFieldChecked(event) {
    var name = event.target.name;
    var checked = event.target.checked;
    let fields = this.state.fields;

    fields[name] = checked;

    this.setState({
      fields
    })
  }

  addResponsable() {
    let responsable = { name: this.state.responsableName, phone: this.state.responsablePhone, email: this.state.responsableEmail };
    let responsables = this.state.responsables;
    responsables.push(responsable);

    this.setState({
      responsables,
      responsableName: '',
      responsablePhone: '',
      responsableEmail: ''
    })
  }

  removeResponsable(item) {
    let responsables = this.state.responsables.filter(i => i.name != item.name);

    this.setState({
      responsables
    })
  }

  render() {
    const options = {
      noDataText: 'Não existem dados para esta pesquisa',
      searchField: this.createCustomSearchField,
      onRowDoubleClick: this.editClient
    }

    return (
      <div>
        <Row>
          <Col sm={{ size: 10, offset: 1 }}>
            <Card>
              <CardHeader>
                Clientes
                <Button color="primary" className="float-right" onClick={this.toggleReport}><i className="fa fa-th-list" aria-hidden="true"></i> Relatório</Button>
              </CardHeader>
              <CardBody>
                <BootstrapTable version='4' data={this.state.clients} search={true} hover pagination options={options}>
                  <TableHeaderColumn dataField='id' isKey searchable={false} hidden>Código</TableHeaderColumn>
                  <TableHeaderColumn dataField='name' dataSort={true}>Razão social</TableHeaderColumn>
                  <TableHeaderColumn dataField='cnpj' dataSort={true}>CNPJ</TableHeaderColumn>
                  <TableHeaderColumn dataField={'responsable'} dataFormat={responsableFormatter} dataSort={true} >Representante</TableHeaderColumn>
                  <TableHeaderColumn dataField="button" width="60" editable={false} dataFormat={this.buttonFormatter}></TableHeaderColumn>
                </BootstrapTable>
              </CardBody>
              <CardFooter>
                <Button color="primary" className="float-right" onClick={this.addClient.bind(this)}><i className="fa fa-plus" aria-hidden="true"></i> Adicionar</Button>
              </CardFooter>
            </Card>
          </Col>
        </Row>

        <Modal isOpen={this.state.modal} toggle={this.toggle}>
          <ModalHeader toggle={this.toggle}>Adicionar cliente</ModalHeader>
          <ModalBody>
            <form ref={(el) => this.form = el}>
              <Row>
                <Col xs="12" sm="6">
                  <FormGroup>
                    <Label htmlFor="name">Razão social</Label>
                    <Input type="text" id="name" value={this.state.name} name="name" placeholder="Razão social" onChange={this.handleUserInput.bind(this)} />
                  </FormGroup>
                </Col>
                <Col xs="12" sm="6">
                  <FormGroup>
                    <Label htmlFor="cnpj">CNPJ</Label>
                    <InputMask type="text" id="cnpj" onBlur={this.onBlurCnpj.bind(this)} value={this.state.cnpj} className="form-control" name="cnpj" mask="99.999.999/9999-99" maskChar=" " placeholder="00.000.000/0000-00" onChange={this.handleUserInput.bind(this)} />
                  </FormGroup>
                </Col>
              </Row>
              <Row>
                <Col>
                  <h5>Representantes</h5>
                </Col>
              </Row>
              <Row>
                <Col xs="12" md="8" >
                  <FormGroup>
                    <Label htmlFor="responsable-name">Nome</Label>
                    <Input type="text" id="responsable-name" value={this.state.responsableName} name="responsableName" placeholder="Representante" onChange={this.handleUserInput.bind(this)} />
                  </FormGroup>
                </Col>
                <Col xs="12" md="4">
                  <FormGroup>
                    <Label htmlFor="responsablePhone">Telefone</Label>
                    <InputMask type="phone" id="phone" value={this.state.responsablePhone} className="form-control" name="responsablePhone" mask="(99) 99999-9999" maskChar=" " placeholder="(00) 00000-0000" onChange={this.handleUserInput.bind(this)} />
                  </FormGroup>
                </Col>
              </Row>
              <Row>
                <Col xs="12" md="8">
                  <FormGroup>
                    <Label htmlFor="responsableEmail">Email</Label>
                    <Input type="email" id="email" value={this.state.responsableEmail} className="form-control" name="responsableEmail" placeholder="email@dominio.com" onChange={this.handleUserInput.bind(this)} />
                  </FormGroup>
                </Col>
                <Col xs="12" md="4">
                  <Row><Label>&nbsp;</Label></Row>
                  <Button color="secondary" onClick={this.addResponsable.bind(this)} >Adicionar</Button>
                </Col>
              </Row>
              <Row>
                <Col xs="12">
                  <ListGroup>
                    {
                      this.state.responsables.map((item, i) =>
                        <ListGroupItem key={i} style={{ height: 90 }}>
                          <p style={{ display: 'inline-block' }}>{item.name}<br />{item.phone}<br />{item.email}</p>
                          <p className="float-left" style={{ cursor: 'pointer', verticalAlign: 'top' }}
                            className="float-right" onClick={this.removeResponsable.bind(this, item)}>
                            <i className="fa fa-times" aria-hidden="true"></i>
                          </p>
                        </ListGroupItem>
                      )
                    }
                  </ListGroup>
                </Col>
              </Row>
              <br />
              <Row>
                <Col xs="12" md="6">
                  <FormGroup>
                    <Label htmlFor="limit">Limite total</Label>
                    <Input type="number" id="limit" name="limit" value={this.state.limit} placeholder="1000" onChange={this.handleUserInput.bind(this)} />
                  </FormGroup>
                </Col>
                <Col xs="12" sm="6">
                  <Label for="limit">&nbsp;</Label>
                  <FormGroup check>
                    <Label check>
                      <Input type="checkbox" checked={this.state.hasBranchs} onChange={this.onChangeBranch.bind(this)} name="limit-by-deptartment" />
                      Definir limite por departamento
                    </Label>
                  </FormGroup>
                </Col>
              </Row>
              <Row>
                <Col xs="12">
                  <Label for="limit">&nbsp;</Label>
                  <FormGroup check inline>
                    <Label check>
                      <Input type="checkbox" checked={this.state.hasUnits} onChange={this.onChangeUnit.bind(this)} name="has-braches" />
                      Esta empresa possui mais de uma filial
                    </Label>
                  </FormGroup>
                </Col>
              </Row>
              <h5>Endereço</h5>
              <Row>
                <Col xs="4">
                  <FormGroup>
                    <Label htmlFor="cep">CEP</Label>
                    <InputMask type="text" id="cep" name="cep" className="form-control" value={this.state.address.cep} placeholder="CEP" mask="99999-999" maskChar=" " placeholder="00000-000" onBlur={this.onBlurCep.bind(this)} onChange={this.onChangeAddress.bind(this)} />
                  </FormGroup>
                </Col>
                <Col xs="3">
                  <FormGroup>
                    <Label htmlFor="number">Número</Label>
                    <Input type="text" id="number" value={this.state.address.number} name="number" placeholder="Nº" onChange={this.onChangeAddress.bind(this)} />
                  </FormGroup>
                </Col>
                <Col xs="5">
                  <FormGroup>
                    <Label htmlFor="complement">Complemento</Label>
                    <Input type="text" id="complement" value={this.state.address.complement} name="complement" placeholder="Complemento (opcional)" onChange={this.onChangeAddress.bind(this)} />
                  </FormGroup>
                </Col>
              </Row>
              <Row>
                <Col xs="6">
                  <FormGroup>
                    <Label htmlFor="street">Rua</Label>
                    <Input type="text" id="street" value={this.state.address.street} name="street" placeholder="Rua" onChange={this.onChangeAddress.bind(this)} />
                  </FormGroup>
                </Col>
                <Col xs="6">
                  <FormGroup>
                    <Label htmlFor="neighborhood">Bairro</Label>
                    <Input type="text" id="neighborhood" value={this.state.address.neighborhood} name="neighborhood" placeholder="Bairro" onChange={this.onChangeAddress.bind(this)} />
                  </FormGroup>
                </Col>
              </Row>
              <Row>
                <Col xs="8">
                  <FormGroup>
                    <Label htmlFor="city">Cidade</Label>
                    <Input type="text" id="city" value={this.state.address.city} name="city" placeholder="Cidade" onChange={this.onChangeAddress.bind(this)} />
                  </FormGroup>
                </Col>
                <Col xs="4">
                  <FormGroup>
                    <Label htmlFor="state">Estado</Label>
                    <Input type="text" id="state" value={this.state.address.state} name="state" placeholder="Estado" onChange={this.onChangeAddress.bind(this)} />
                  </FormGroup>
                </Col>
              </Row>
              <Row>
                <Col xs="12">
                  <FormGroup>
                    <Label htmlFor="area">Área</Label>
                    <Input type="text" id="area" value={this.state.address.area} name="area" placeholder="Área" onChange={this.onChangeAddress.bind(this)} />
                  </FormGroup>
                </Col>
              </Row>
              {this.state.hasBranchs && <div>
                <Row>
                  <Col xs="11"><h5 style={{ fontWeight: 'normal' }}>Departamentos</h5></Col>
                </Row>
                <hr />
                <Row>
                  <Col xs="12" md="7">
                    <FormGroup>
                      <Label htmlFor="department-name">Departamento</Label>
                      <Input type="text" id="department-name" value={this.state.selectedBranch.name} onChange={this.onChangeAddBranchName.bind(this)} placeholder="Departamento de vendas" />
                    </FormGroup>
                  </Col>
                  <Col xs="12" md="3">
                    <FormGroup>
                      <Label htmlFor="limit-per-dept">Limite</Label>
                      <Input type="number" id="limit-per-dept" onChange={this.onChangeAddBranchLimit.bind(this)} placeholder="50" />
                    </FormGroup>
                  </Col>
                  <Col xs="12" md="1">
                    <Label>&nbsp;</Label>
                    <Button color="secondary" onClick={this.onAddBranch.bind(this)}><i className="fa fa-plus" aria-hidden="true"></i></Button>
                  </Col>
                </Row>
                <Row >
                  <Col xs="12">
                    <ListGroup>
                      {this.state.branches.map((branch) =>
                        <ListGroupItem key={branch.name}>
                          {branch.name} {branch.limit && branch.limit.length > 0 ? 'pode fazer até ' + branch.limit + ' laudo(s)' : 'sem limite de laudos'}
                          <span xs="1" style={{ cursor: 'pointer' }} className="float-right"
                            onClick={this.onRemoveBranch.bind(this, branch)}>
                            <i className="fa fa-times" aria-hidden="true"></i></span>
                        </ListGroupItem>)}
                    </ListGroup>
                  </Col>
                </Row>
              </div>
              }
              {this.state.hasUnits &&
                <div>
                  <Row style={{ marginTop: 10 }}>
                    <Col xs="11"><h5 style={{ fontWeight: 'normal' }}>Unidades</h5></Col>
                  </Row>
                  <hr />
                  <Row>
                    <Col xs="12">
                      <FormGroup>
                        <Label htmlFor="unit-name">Nome da unidade</Label>
                        <Input type="text" id="unit-name" onChange={this.onChangeAddUnitName.bind(this)} placeholder="Unidade Copacabana" />
                      </FormGroup>
                    </Col>
                  </Row>
                  <h5>Endereço</h5>
                  <Row>
                    <Col xs="4">
                      <FormGroup>
                        <Label htmlFor="cep">CEP</Label>
                        <InputMask type="text" id="cep" name="cep" className="form-control" placeholder="CEP" mask="99999-999" maskChar=" " placeholder="00000-000" onBlur={this.onBlurUnitCep.bind(this)} onChange={this.onChangeAddUnitAddress.bind(this)} />
                      </FormGroup>
                    </Col>
                    <Col xs="3">
                      <FormGroup>
                        <Label htmlFor="number">Número</Label>
                        <Input type="text" id="number" name="number" placeholder="Nº" onChange={this.onChangeAddUnitAddress.bind(this)} />
                      </FormGroup>
                    </Col>
                    <Col xs="5">
                      <FormGroup>
                        <Label htmlFor="complement">Complemento</Label>
                        <Input type="text" id="complement" name="complement" placeholder="Complemento (opcional)" onChange={this.onChangeAddUnitAddress.bind(this)} />
                      </FormGroup>
                    </Col>
                  </Row>
                  <Row>
                    <Col xs="6">
                      <FormGroup>
                        <Label htmlFor="street">Rua</Label>
                        <Input type="text" id="street" name="street" value={(this.state.selectedUnit.address || {}).street} placeholder="Rua" onChange={this.onChangeAddUnitAddress.bind(this)} />
                      </FormGroup>
                    </Col>
                    <Col xs="6">
                      <FormGroup>
                        <Label htmlFor="neighborhood">Bairro</Label>
                        <Input type="text" id="neighborhood" name="neighborhood" value={(this.state.selectedUnit.address || {}).neighborhood} placeholder="Bairro" onChange={this.onChangeAddUnitAddress.bind(this)} />
                      </FormGroup>
                    </Col>
                  </Row>
                  <Row>
                    <Col xs="8">
                      <FormGroup>
                        <Label htmlFor="city">Cidade</Label>
                        <Input type="text" id="city" name="city" placeholder="Cidade" value={(this.state.selectedUnit.address || {}).city} onChange={this.onChangeAddUnitAddress.bind(this)} />
                      </FormGroup>
                    </Col>
                    <Col xs="4">
                      <FormGroup>
                        <Label htmlFor="state">Estado</Label>
                        <Input type="text" id="state" name="state" placeholder="Estado" value={(this.state.selectedUnit.address || {}).state} onChange={this.onChangeAddUnitAddress.bind(this)} />
                      </FormGroup>
                    </Col>
                  </Row>
                  <Row>
                    <Col xs="12" md="3">
                      <FormGroup>
                        <Label htmlFor="limit-per-unit">Limite</Label>
                        <Input type="number" id="limit-per-unit" onChange={this.onChangeAddUnitLimit.bind(this)} placeholder="50" />
                      </FormGroup>
                    </Col>
                    <Col xs="12" md="1">
                      <Label>&nbsp;</Label>
                      <Button color="secondary" onClick={this.onAddUnit.bind(this)}><i className="fa fa-plus" aria-hidden="true"></i></Button>
                    </Col>
                  </Row>
                  <Row>
                    <Col xs="12">
                      <ListGroup>
                        {this.state.units.map(unit =>
                          <ListGroupItem key={unit.name}>
                            Unidade <b>{unit.name}</b> {unit.limit && unit.limit.length > 0 ? 'pode fazer até ' + unit.limit + ' laudo(s)' : 'sem limites de laudo'}
                            <span xs="1" style={{ cursor: 'pointer' }} className="float-right"
                              onClick={this.onRemoveUnit.bind(this, unit)}>
                              <i className="fa fa-times" aria-hidden="true"></i></span>
                          </ListGroupItem>)
                        }
                      </ListGroup>
                    </Col>
                  </Row>
                </div>
              }
            </form>
          </ModalBody>
          <ModalFooter>
            <Button color="primary" onClick={this.handleSubmit.bind(this)}>Salvar</Button>
            <Button color="secondary" onClick={this.toggle}>Cancelar</Button>
          </ModalFooter>
        </Modal>

        <Modal isOpen={this.state.reportModal} toggle={this.toggleReport}>
          <ModalBody>
            <h3>Escolha os campos que deseja para o relatório: </h3>
            <FormGroup check>
              <Label check>
                <Input type="checkbox" name="responsable" onChange={this.onFieldChecked.bind(this)} />
                Representante
              </Label>
            </FormGroup>
            <FormGroup check>
              <Label check>
                <Input type="checkbox" name="address" onChange={this.onFieldChecked.bind(this)} />
                Endereço
              </Label>
            </FormGroup>
            <FormGroup check>
              <Label check>
                <Input type="checkbox" name="unit" onChange={this.onFieldChecked.bind(this)} />
                Unidades
              </Label>
            </FormGroup>
            <FormGroup check>
              <Label check>
                <Input type="checkbox" name="department" onChange={this.onFieldChecked.bind(this)} />
                Departamentos
              </Label>
            </FormGroup>
          </ModalBody>
          <ModalFooter>
            <Button color="secondary" onClick={this.showPdf.bind(this)}>Visualizar</Button>
            <Button color="secondary" onClick={this.toggleReport}>Cancelar</Button>
          </ModalFooter>
        </Modal>
      </div>
    )
  }
}

export default Client;