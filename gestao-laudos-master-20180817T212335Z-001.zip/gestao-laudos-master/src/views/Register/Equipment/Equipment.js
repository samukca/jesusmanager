import React, { Component } from 'react';
import {
  Row,
  Col,
  Button,
  ButtonDropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
  Card,
  CardHeader,
  CardFooter,
  CardBody,
  Form,
  FormGroup,
  FormText,
  Label,
  Progress,
  Input,
  InputGroup,
  InputGroupAddon,
  InputGroupButton,
  ListGroup,
  ListGroupItem,
  Modal,
  ModalBody,
  ModalFooter,
  ModalHeader
} from 'reactstrap';
import Dropzone from 'react-dropzone';
import { NotificationManager } from 'react-notifications';
import Category from './Category';
import { database, storage } from '../../../firebase';
import { BootstrapTable, TableHeaderColumn } from 'react-bootstrap-table';
import { Link, Switch, Route, Redirect } from 'react-router-dom';
import * as pdf from './_equipment-pdf';

function deleteTool(item) {
  if (confirm('Tem certeza que deseja deletar o equipamento ' + item.name + ' ?')) {
    database.ref('equipments/' + item.id).remove();
  }
}

class Equipment extends Component {

  constructor(props) {
    super(props);

    this.state = {
      groups: [],
      categories: [],
      inputs: [],
      groupModal: false,
      categoryModal: false,
      files: [],
      dropzoneActive: false,
      selectedGroup: null,
      selectedCategory: null,
      newGroup: {},
      newCategory: {},
      equipment: {},
      progress: 0,
      uploadRunning: false,
      isFinished: false,
      modal: false,
      equipments: [],
      catList: []
    };

    this.toggleGroup = this.toggleGroup.bind(this);
    this.toggleCategory = this.toggleCategory.bind(this);

    this.toggle = this.toggle.bind(this);
  }

  componentWillMount() {
    database.ref('equipments').on('value', snapshot => {
      var equipments = [];
      snapshot.forEach(childSnapshot => {
        var equipment = childSnapshot.val();
        equipment.id = childSnapshot.key;
        equipments.push(equipment);
      });
      equipments.sort((a, b) => { return (a.name > b.name) ? 1 : ((b.name > a.name) ? -1 : 0) })

      this.setState({
        equipments
      })
    })

    this.updateGroups()
    this.getCategoriesFromGroupId()
  }

  createCustomSearchField(props) {
    return (
      <SearchField
        defaultValue={props.defaultSearch}
        placeholder={'Pesquisar'} />
    );
  }

  toggle() {
    this.setState(prevstate => ({
      modal: !prevstate.modal
    }));
  }

  onSelectGroup(event) {
    let selectedGroupId = event.target.value;
    this.setState({
      categories: [],
      inputs: [],
      selectedCategory: 'invalid',
      selectedGroup: selectedGroupId
    }, () => this.getCategories())
  }

  onChangeNewGroup(event) {
    let newGroup = this.state.newGroup;
    newGroup.name = event.target.value.toUpperCase();

    this.setState({
      newGroup
    })
  }

  saveGroup() {
    let group = this.state.newGroup;
    database.ref('groups').push().set(group);
    this.setState({
      newGroup: {},
      groupModal: false,
      groups: []
    }, () => this.updateGroups())
  }

  updateGroups() {
    database.ref('groups')
      .once('value', (snapshot) => {
        var groups = []
        snapshot.forEach(child => {
          var id = child.key;
          var group = child.val();
          group.id = id;
          groups.push(group)
        })

        groups.sort((a, b) => { return (a.name > b.name) ? 1 : ((b.name > a.name) ? -1 : 0) })
        this.setState({
          groups
        })
      });
  }

  toggleGroup() {
    this.setState({
      groupModal: !this.state.groupModal
    });
  }

  toggleCategory() {
    this.setState({
      categoryModal: !this.state.categoryModal
    });
  }

  onDragEnter() {
    this.setState({
      dropzoneActive: true
    });
  }

  onDragLeave() {
    this.setState({
      dropzoneActive: false
    });
  }

  onDrop(accepted) {
    var files = this.state.files;
    accepted.forEach(img => {
      files.push(img);
    })
    this.setState({
      files,
      dropzoneActive: false
    }, () => console.log(this.state.equipment));
  }

  removeImage(image) {
    if (confirm('Deseja mesmo excluir essa imagem?')) {
      if (this.state.isEditing) {
        let equipment = this.state.equipment;
        var pictures = (this.state.equipment.pictures || []).filter(item => image != item);
        equipment.pictures = pictures;
        this.setState({
          equipment,
          files: pictures
        })
      } else {
        let files = this.state.files;
        let filter = files.filter(item => image.name != item.name);
        this.setState({
          files: filter
        })
      }

    }
  }

  onCategoryChange(category) {
    this.setState({
      newCategory: category
    })
  }

  onCreateCategory() {
    let category = this.state.newCategory;
    window.scrollTo(0, 0)
    database.ref('groups').child(this.state.selectedGroup).child('categories').push().set(category);
    this.setState({
      newCategory: {},
      categoryModal: false,
      categories: []
    }, () => this.getCategories())
  }

  getCategoriesFromGroupId() {
    database.ref('groups')
      .on('value', (sn) => {
        var categories = [];
        sn.forEach(c => {
          c.child('categories').forEach(child => {
            var id = child.key;
            var category = child.val();
            category.id = id;
            categories.push(category);
          })
        })

        categories.sort((a, b) => { return (a.name > b.name) ? 1 : ((b.name > a.name) ? -1 : 0) })

        this.setState(prevState => ({
          catList: categories
        }))
      })
  }

  getCategories(hasSelected) {
    database.ref('groups').child(this.state.selectedGroup).child('categories')
      .once('value', (snapshot) => {
        var categories = []
        snapshot.forEach(child => {
          var id = child.key;
          var category = child.val();
          category.id = id;
          if (hasSelected && id == this.state.selectedCategory) {
            this.setState({
              selectedCategory: category,
              inputs: category.fields || []
            })
          }
          categories.push(category)
        })

        categories.sort((a, b) => { return (a.name > b.name) ? 1 : ((b.name > a.name) ? -1 : 0) })

        this.setState({
          categories
        })
      })
  }

  onSelectCategory(event) {
    let selected = this.state.categories.find(cat => cat.id == event.target.value);
    this.setState({
      selectedCategory: selected,
      inputs: selected.fields || []
    })
  }

  onInputChange(event) {
    let name = event.target.name.replace("/", "-");
    let value = event.target.value.toUpperCase();
    let equipment = this.state.equipment;

    equipment[name] = value;
    this.setState({
      equipment
    })
  }

  onInputGroupChange(event, group) {
    let name = event.target.name.toUpperCase();
    let value = event.target.value.toUpperCase();
    let equipment = this.state.equipment;

    equipment[group] = { [name]: value };
    this.setState({
      equipment
    })
  }

  onHandleSubmit() {
    if (this.state.files.length > 0 && !this.arrayEquals(this.state.files, this.state.equipment.pictures)) {
      this.uploadImages();
    } else {
      this.saveEquipment();
    }
  }

  arrayEquals(a, b) {
    if (a == null || b == null) return false;
    if (a.length != b.length) return false;

    for (var i = 0; i < a.length; ++i) {
      if (a[i] !== b[i]) return false;
    }

    return true;
  }

  uploadImages() {
    var ref = storage.ref();
    var metadata = {
      contentType: 'image/jpeg'
    };
    this.state.files.map(file => {
      if (typeof (file) != 'string') {
        var uploadTask = ref.child('equipments/' + this.state.equipment.name + "/" + file.name).put(file, metadata);
        uploadTask.on('state_changed',
          (snapshot) => {
            var progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
            console.log('Upload is ' + progress + '% done');
            this.setState({
              isFinished: false,
              uploadRunning: true
            })
            this.setState({
              progress
            })
            switch (snapshot.state) {
              case 'paused': // or 'paused'
                console.log('Upload is paused');
                break;
              case 'running': // or 'running'
                console.log('Upload is running');
                break;
            }
          }, function (error) {
            switch (error.code) {
              case 'storage/unauthorized':
                NotificationManager.error('Você não está autorizado a fazer essa operação.')
                break;
              case 'storage/canceled':
                NotificationManager.error('O usuário cancelou o upload.')
                break;
              case 'storage/unknown':
                NotificationManager.error('Ocorreu um erro desconhecido ao fazer upload das imagens.')
                break;
            }
          }, () => {
            var downloadURL = uploadTask.snapshot.downloadURL;
            let equipment = this.state.equipment;
            equipment.pictures = equipment.pictures ? [...equipment.pictures, downloadURL] : [downloadURL];
            this.setState({
              isFinished: true,
              uploadRunning: false,
              equipment
            }, () => this.saveEquipment())
          })
      } else {
        this.saveEquipment()
      }
    })
  }

  saveEquipment() {
    let equipment = this.state.equipment;
    let canSave = equipment.pictures == null || (equipment.pictures != null && equipment.pictures.length == this.state.files.length);
    if (canSave) {
      equipment.group = this.state.selectedGroup;
      equipment.category = this.state.selectedCategory.id;
      if (equipment.group && equipment.category) {
        if (!this.state.isEditing) {
          database.ref('equipments').push().set(equipment)
            .then(snapshot => {
              window.scrollTo(0, 0)
              NotificationManager.success('Equipamento salvo com sucesso!');
              this.toggle();
              this.form.reset();
            });
        } else {
          database.ref('equipments/' + equipment.id).update(equipment)
            .then(snapshot => {
              window.scrollTo(0, 0)
              NotificationManager.success('Equipamento salvo com sucesso!');
              this.toggle();
              this.form.reset();
            })
        }
      } else {
        NotificationManager.warning('Selecione um grupo e uma categoria!')
      }
    }
  }

  editEquipment(row) {
    // this.toggle();

    this.setState({
      equipment: row,
      selectedCategory: row.category,
      selectedGroup: row.group
    })
  }

  addEquipment() {
    this.toggle()

    this.setState({
      equipment: {},
      selectedCategory: undefined,
      selectedGroup: undefined,
      categories: [],
      inputs: [],
      files: [],
      isEditing: false
    })
  }

  buttonFormatter(cell, row) {
    return (
      <div>
        <Button onClick={() => deleteTool(row)}><i className="fa fa-trash" aria-hidden="true"></i></Button>
      </div>
    );
  }

  groupFormatter(cell, row) {
    var group = this.state.groups.find(item => item.id == cell)
    return (
      <div>
        {group ? group.name : ''}
      </div>
    )
  }

  sortByGroup(a, b, order) {
    var first = this.state.groups.find(item => item.id == a.group)
    var second = this.state.groups.find(item => item.id == b.group)
    if (order == 'desc') {
      if (first.name > second.name) return -1;
      else if (first.name < second.name) return 1;
      else return 0;
    } else {
      if (first.name > second.name) return 1;
      else if (first.name < second.name) return -1;
      else return 0;
    }
  }

  categoryFormatter(cell, row) {
    var category = this.state.catList.find(item => item.id == cell);

    return (
      <div>
        {category ? category.name : ''}
      </div>
    )
  }

  sortByCategory(a, b, order) {
    var first = this.state.catList.find(item => item.id == a.category)
    var second = this.state.catList.find(item => item.id == b.category)
    if (order == 'desc') {
      if (first.name > second.name) return -1;
      else if (first.name < second.name) return 1;
      else return 0;
    } else {
      if (first.name > second.name) return 1;
      else if (first.name < second.name) return -1;
      else return 0;
    }
  }

  showPdf() {
    pdf.savePdf(this.state.equipments, this.state.groups, this.state.catList);
    window.scrollTo(0, 0)
  }

  render() {
    const selectRowProp = {
      mode: 'checkbox',
      bgColor: 'gray', // you should give a bgcolor, otherwise, you can't regonize which row has been selected
      hideSelectColumn: true,  // enable hide selection column.
      clickToSelect: true  // you should enable clickToSelect, otherwise, you can't select column.
    };

    const options = {
      noDataText: 'Não existem dados para esta pesquisa',
      searchField: this.createCustomSearchField,
      onRowDoubleClick: row => {
        this.setState({
          equipment: row,
          categories: [],
          selectedCategory: row.category,
          selectedGroup: row.group,
          files: row.pictures ? row.pictures.slice() : [],
          isEditing: true
        }, () => { this.getCategories(true); this.toggle() })
      }
    }

    return (
      <div>
        <Row>
          <Col sm="12">
            <Card>
              <CardHeader>
                Equipamentos
                <Button color="primary" className="float-right" onClick={this.showPdf.bind(this)}><i className="fa fa-th-list" aria-hidden="true"></i> Relatório</Button>
              </CardHeader>
              <CardBody>
                <BootstrapTable version='4' data={this.state.equipments} search={true} hover pagination options={options}>
                  <TableHeaderColumn dataField='id' isKey hidden searchable={false} >ID</TableHeaderColumn>
                  <TableHeaderColumn dataField='name' dataSort={true}>Nome</TableHeaderColumn>
                  <TableHeaderColumn dataField='group' width="200" sortFunc={this.sortByGroup.bind(this)} dataSort={true} dataFormat={this.groupFormatter.bind(this)}>Grupo</TableHeaderColumn>
                  <TableHeaderColumn dataField='category' width="200" sortFunc={this.sortByCategory.bind(this)} dataSort={true} dataFormat={this.categoryFormatter.bind(this)} >Categoria</TableHeaderColumn>
                  <TableHeaderColumn dataField="button" width="60" editable={false} dataFormat={this.buttonFormatter}></TableHeaderColumn>
                </BootstrapTable>
              </CardBody>
              <CardFooter>
                <Link to={'/entities/groups'} ><Button color="primary" className="float-left"><i className="fa fa-th-large" aria-hidden="true"></i> Grupos</Button></Link>
                <Button color="primary" className="float-right" onClick={this.addEquipment.bind(this)}><i className="fa fa-plus" aria-hidden="true"></i> Adicionar</Button>
              </CardFooter>
            </Card>
          </Col>
        </Row>

        <Modal isOpen={this.state.modal} toggle={this.toggle}>
          <ModalHeader toggle={this.toggle}>Adicionar equipamento</ModalHeader>
          <ModalBody>
            <form ref={(el) => this.form = el}>
              <Row>
                <Col xs="12" sm="6">
                  <FormGroup>
                    <Label htmlFor="group">Grupo</Label>
                    <Input type="select" value={this.state.selectedGroup} id="group" name="group" placeholder="Grupo" onChange={this.onSelectGroup.bind(this)} defaultValue="invalid" >
                      <option value="invalid" disabled>Selecione</option>
                      {this.state.groups.map(group => <option key={group.id} value={group.id}>{group.name}</option>)}
                    </Input>
                    <FormText color="primary">
                      <a onClick={this.toggleGroup} style={{ cursor: 'pointer' }}>Criar novo grupo</a>
                    </FormText>
                  </FormGroup>
                </Col>
                <Col xs="12" sm="6">
                  <FormGroup>
                    <Label htmlFor="category">Categoria</Label>
                    <Input type="select" value={this.state.selectedCategory != null && this.state.selectedCategory.id || this.state.selectedCategory} id="category" onChange={this.onSelectCategory.bind(this)} name="category" placeholder="Categoria" defaultValue="invalid" >
                      <option value="invalid" disabled>Selecione</option>
                      {this.state.categories.map(category => <option key={category.id} value={category.id}>{category.name}</option>)}
                    </Input>
                    {this.state.selectedGroup &&
                      <FormText color="primary">
                        <a onClick={this.toggleCategory} style={{ cursor: 'pointer' }}>Criar nova categoria</a>
                      </FormText>
                    }
                  </FormGroup>
                </Col>
              </Row>
              <Row>
                <Col xs="12">
                  <FormGroup>
                    <Label for="name">Nome</Label>
                    <Input type="text" value={this.state.equipment.name} name="name" id="name" onChange={this.onInputChange.bind(this)} />
                  </FormGroup>
                </Col>
              </Row>
              <Row>
                <Col xs="12">
                  <FormGroup>
                    <Label for="observarções">Observações</Label>
                    <Input type="textarea" value={this.state.equipment.observações} name="observações" id="observações" onChange={this.onInputChange.bind(this)} />
                  </FormGroup>
                </Col>
              </Row>
              <Row>
                <Col xs="12">
                  {this.state.inputs.filter(i => !i.changeOnReport).map(input =>
                    !input.differGroup
                      ? <FormGroup key={input.name}><Label>{input.name}</Label> <Input type={input.type} value={this.state.equipment[input.name]} name={input.name} onChange={this.onInputChange.bind(this)} /></FormGroup>
                      : this.state.selectedCategory.groups.map(group =>
                        <FormGroup key={input.name + '/' + group}><Label>{input.name} - {group}</Label><Input type={input.type} value={this.state.equipment[group][input.name]} name={input.name} onChange={event => this.onInputGroupChange(event, group)} /></FormGroup>
                      )
                  )
                  }
                </Col>
              </Row>
              <Row>
                <Col xs="12" sm="6" >
                  <Label>Fotos do equipamento</Label>
                  <Dropzone onDrop={this.onDrop.bind(this)}
                    accept="image/jpeg"
                    style={{ position: "relative" }}
                    onDragEnter={this.onDragEnter.bind(this)}
                    onDragLeave={this.onDragLeave.bind(this)}>
                    {this.state.dropzoneActive && <div className="dropzone-container-active"></div>}
                    <div className="dropzone-container" style={{ cursor: 'pointer' }}>
                      <p>Arraste os arquivos aqui ou clique para selecioná-los. *Apenas .jpg</p>
                    </div>
                  </Dropzone>
                </Col>
                <Col xs="12" sm="6">
                  <p className="text-muted">Clique duas vezes na imagem para apagar</p>
                  <ul className="preview">
                    {
                      this.state.files.map(f => <li className="preview-item" key={f.name || f}><img onDoubleClick={() => this.removeImage(f)} src={f.preview || f} /></li>)
                    }
                  </ul>
                  {this.state.uploadRunning && <div><div>{this.state.isFinished ? 'Upload finalizado!' : 'Fazendo upload das imagens'}</div><Progress value={this.state.progress} /></div>}
                </Col>
              </Row>
            </form>
          </ModalBody>
          <ModalFooter>
            <Button color="primary" onClick={this.onHandleSubmit.bind(this)}>Salvar</Button>
            <Button color="secondary" onClick={this.toggle}>Cancelar</Button>
          </ModalFooter>
        </Modal>

        {/* Group Modal */}
        <Modal isOpen={this.state.groupModal} toggle={this.toggleGroup} className={this.props.className}>
          <ModalHeader toggle={this.toggleGroup}>Adicionar grupo</ModalHeader>
          <ModalBody>
            <Row>
              <Col xs="12">
                <FormGroup>
                  <Label htmlFor="name">Nome do grupo</Label>
                  <Input type="text" id="name" name="name" placeholder="Veículos" onChange={this.onChangeNewGroup.bind(this)} />
                </FormGroup>
              </Col>
            </Row>
          </ModalBody>
          <ModalFooter>
            <Button color="primary" onClick={this.saveGroup.bind(this)}>Salvar</Button>
            <Button color="secondary" onClick={this.toggleGroup}>Cancelar</Button>
          </ModalFooter>
        </Modal>

        {/* Category Modal */}
        <Modal isOpen={this.state.categoryModal} toggle={this.toggleCategory}>
          <ModalHeader toggle={this.toggleCategory}>Adicionar categoria</ModalHeader>
          <ModalBody>
            <Category selectedGroup={this.state.selectedGroup} categoryChange={this.onCategoryChange.bind(this)} />
          </ModalBody>
          <ModalFooter>
            <Button color="primary" onClick={this.onCreateCategory.bind(this)}>Salvar</Button>
            <Button color="secondary" onClick={this.toggleCategory}>Cancelar</Button>
          </ModalFooter>
        </Modal>
      </div>
    )
  }
}

export default Equipment;