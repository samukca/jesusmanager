import React, { Component } from 'react';
import {
  Row,
  Col,
  Button,
  ButtonDropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
  Card,
  CardHeader,
  CardFooter,
  CardBody,
  Form,
  FormGroup,
  FormText,
  Label,
  Input,
  InputGroup,
  InputGroupAddon,
  InputGroupButton,
  ListGroup,
  ListGroupItem,
  Modal,
  ModalBody,
  ModalFooter,
  ModalHeader
} from 'reactstrap';
import Dropzone from 'react-dropzone';
import { database } from '../../../firebase';
import Reorder, {
  reorder,
  reorderImmutable,
  reorderFromTo,
  reorderFromToImmutable
} from 'react-reorder';

var placeholder = document.createElement("li");
placeholder.className = "list-group-item placeholder list-group-item-warning";
placeholder.innerHTML = "Soltar aqui";

class Category extends Component {

  constructor(props) {
    super(props);
    this.state = {
      group: '',
      category: {},
      isGroup: false,
      groupCount: 2,
      groups: [],
      selectedField: {},
      fields: []
    };
  }

  componentWillMount() {
    if (this.props.selectedCategory) {
      this.setState({
        category: this.props.selectedCategory,
        isGroup: this.props.selectedCategory.isGroup,
        groups: this.props.selectedCategory.groups || [],
        fields: this.props.selectedCategory.fields || [],
        groupCount: this.props.selectedCategory.groups ? this.props.selectedCategory.groups.length : 2
      })
    }

    database.ref('groups').child(this.props.selectedGroup)
      .once('value', snapshot => {
        this.setState({
          group: snapshot.val().name
        })
      })
  }

  onChangeIsGroup(event) {
    this.setState({
      isGroup: event.target.checked
    }, () => this.onHandleChange())
  }

  onChangeGroupCount(event) {
    var count = event.target.value != 'undefined' ? parseInt(event.target.value) : 0;
    this.setState({
      groupCount: count
    })
  }

  onChangeGroupName(event, index) {
    var groups = this.state.groups;
    groups[index] = event.target.value.toUpperCase();
    this.setState({
      groups
    }, () => this.onHandleChange())
  }

  onChangeFieldName(event) {
    var name = event.target.value.toUpperCase();
    this.setState(prevState => ({
      selectedField: {name, type: prevState.selectedField.type, differGroup: prevState.selectedField.differGroup}
    }))
  }

  onChangeFieldType(event) {
    var type = event.target.value;
    this.setState(prevState => ({
      selectedField: {name: prevState.selectedField.name, type, differGroup: prevState.selectedField.differGroup}
    }))
  }

  onChangeFieldDifferGroup(event) {
    var differ = event.target.checked;
    this.setState(prevState => ({
      selectedField: {name: prevState.selectedField.name, type: prevState.selectedField.type, differGroup: differ}
    }))
  }

  onChangeFieldChangeOnReport(event) {
    var change = event.target.checked;
    let selectedField = this.state.selectedField;
    selectedField.changeOnReport = change;

    this.setState({
      selectedField
    })
  }

  onAddField() {
    let field = this.state.selectedField;
    field.name = field.name ? field.name.replace(".","").toUpperCase() : ""
    field.differGroup = this.state.selectedField.differGroup ? true : false;
    field.changeOnReport = true;

    if (this.state.selectedFieldIndex == undefined) {
      this.setState({
        fields: [...this.state.fields, field],
        selectedField: {},
        selectedFieldIndex: undefined
      }, () => this.onHandleChange())
    } else {
      var fields = this.state.fields;
      fields[this.state.selectedFieldIndex] = field;
      this.setState({
        fields,
        selectedField: {},
        selectedFieldIndex: undefined
      }, () => this.onHandleChange())
    }
  }

  onRemoveField(field) {
    var fields = this.state.fields.filter(function(val) { return val.name !== field.name })
    this.setState({
      fields
    }, () => this.onHandleChange())
  }

  onEditField(field, index) {
    var selectedField = this.state.fields[index]
    this.setState({
      selectedFieldIndex: index,
      selectedField
    })
  }

  onChangeName(event) {
    var name = event.target.value.toUpperCase();
    var category = this.state.category;
    category.name = name;
    this.setState({
      category
    }, () => this.onHandleChange())
  }

  onHandleChange() {
    var category = this.state.category;
    category.isGroup = this.state.isGroup;
    category.groups = this.state.isGroup ? this.state.groups : null;
    category.fields = this.state.fields;

    this.form.reset()

    this.props.categoryChange(category);
  }

  dragStart(e){
    e.dataTransfer.setData("text/html", e.target);
    e.dataTransfer.effectAllowed = "move";
    // Firefox requires dataTransfer data to be set
    this.setState({ draggedItemIndex: e.target.id })
  }

  dragOver(e) {
    e.preventDefault();
    e.dataTransfer.dropEffect = "move"
  }

  onDrop(e) {
    e.preventDefault()
    const droppedItemId = e.currentTarget.id
    const movedItem = this.state.fields[this.state.draggedItemIndex];
    const remainingItems = this.state.fields.filter((item, index) => index != this.state.draggedItemIndex);

    const reorderedItems = [
      ...remainingItems.slice(0, droppedItemId),
      movedItem,
      ...remainingItems.slice(droppedItemId)
  ];

    this.setState({
      fields: reorderedItems,
      draggedItemIndex: null
    }, () => this.onHandleChange())
  }

  render() {
    return (
      <div>
        <h5>{this.state.group}</h5>
        <hr />
        <Row>
          <Col xs="12">
            <FormGroup>
              <Label htmlFor="name">Nome da categoria</Label>
              <Input type="text" id="name" value={this.state.category.name} name="name" placeholder="Caminhão" onChange={this.onChangeName.bind(this)} />
            </FormGroup>
          </Col>
        </Row>
        <Row>
          <Col xs="12">
            <FormGroup>
              <Label check>
                <Input type="checkbox" id="hasGroup" name="hasGroup" checked={this.state.isGroup} onChange={this.onChangeIsGroup.bind(this)} placeholder="Caminhão" />
                Esta categoria se encontra em pares ou conjuntos
              </Label>
            </FormGroup>
          </Col>
        </Row>
        { this.state.isGroup && <div>
          <Row>
            <Col xs="12">
              <FormGroup row>
                <Label htmlFor="qtd" sm="5">Tamanho do conjunto:</Label>
                <Col sm="7">
                  <Input type="number" id="qtd" onChange={this.onChangeGroupCount.bind(this)} name="qtd" placeholder="2" value={this.state.groupCount} />
                </Col>
              </FormGroup>
            </Col>
          </Row>
          <hr/>
          { this.state.groupCount > 0 &&
            Array(this.state.groupCount).fill(1).map((x, i) =>
            <Row key={i}>  
              <Col xs="12">
                <FormGroup>
                  <Label htmlFor="group-name">Nome do conjunto {i + 1}</Label>
                  <Input type="text" id="group-name" name="group-name" onChange={(event) => this.onChangeGroupName(event, i)} value={this.state.groups && this.state.groups[i]} />
                </FormGroup>
              </Col>
            </Row>)
          }
          </div>
        }
        <form ref={el => this.form = el}>
        <Row>
          <Col xs="12" sm="6">
            <FormGroup>
              <Label htmlFor="field">Nome do campo</Label>
              <Input type="text" id="field" name="field" value={this.state.selectedField.name} onChange={this.onChangeFieldName.bind(this)} placeholder="Placa" />
            </FormGroup>
          </Col>
          <Col xs="12" sm="4">
            <FormGroup>
              <Label htmlFor="field-type">Tipo do campo</Label>
              <Input type="select" id="field-type" name="field-type" value={this.state.selectedField.type ? this.state.selectedField.type.toLowerCase() : "invalid"} onChange={this.onChangeFieldType.bind(this)} placeholder="Tipo" >
                <option value="invalid">Selecione</option>
                <option value="text">Texto</option>
                <option value="number">Número</option>
              </Input>
            </FormGroup>
          </Col>
          <Col xs="12" sm="2">
            <Row><Label>&nbsp;</Label></Row>
            <Button color="secondary" onClick={this.onAddField.bind(this)}><i className="fa fa-plus" aria-hidden="true"></i></Button>
          </Col>
        </Row>
        { this.state.isGroup &&
          <Row>
            <Col xs="12">
              <FormGroup>
                <Label check>
                  <Input type="checkbox" id="difGroup" name="difGroup" onChange={this.onChangeFieldDifferGroup.bind(this)} checked={this.state.selectedField.differGroup || false} />
                  Este campo possui diferentes valores entre os grupos
                </Label>
              </FormGroup>
            </Col>
          </Row>
        }
        </form>
        <Row>
          <Col xs="12">
            <ListGroup>
                { this.state.fields.map((field, i) => 
                field &&
                  <ListGroupItem key={i} data-id={i} 
                    draggable='true'
                    id={i}
                    onDragOver={this.dragOver.bind(this)}
                    onDrop={this.onDrop.bind(this)}
                    onDragStart={this.dragStart.bind(this)}>
                      {field.name}
                      <span xs="1" style={{cursor: 'pointer'}} className="float-right" 
                        onClick={this.onRemoveField.bind(this, field)}>
                        <i className="fa fa-times" aria-hidden="true"></i></span>
                      <span xs="1" style={{cursor: 'pointer', marginRight: 10 }} className="float-right" 
                        onClick={this.onEditField.bind(this, field, i)}>
                        <i className="fa fa-pencil" aria-hidden="true"></i></span>
                  </ListGroupItem>)
                }              
            </ListGroup>
          </Col>
        </Row>
      </div>
    )
  }
}

export default Category;