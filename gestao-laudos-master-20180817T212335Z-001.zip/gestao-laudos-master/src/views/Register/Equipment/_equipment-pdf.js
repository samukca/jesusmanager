import jsPDF from 'jspdf';
import { autoTableHtmlToJson, autoTable } from 'jspdf-autotable';
import { NotificationManager } from 'react-notifications';
import Raven from 'raven-js';

var footer = "Este documento foi emitido a partir do sistema de gestão da empresa 08.618.923/0001-13 e sua veracidade poderá ser consultada no site https://laudostecnicosee.com.br/"

export function savePdf(list, groups, categories) {
  var doc = new jsPDF({ orientation: 'landscape' });

  NotificationManager.warning('Aguarde enquanto o PDF é gerado.');

  var images = [];
  var imgData = [];
  var shownImages = [];

  var infoHeader = [
    "Nome",
    "Grupo",
    "Categoria",
    ""
  ]
  var infoRows = [];

  doc.setFontStyle('bold');
  doc.text("Equipamentos", 16, 10);

  (list || []).sort((a, b) => {
    var nameA = a.name.toLowerCase();
    var nameB = b.name.toLowerCase();
    if (nameA < nameB) return -1;
    if (nameA > nameB) return 1;
    return 0;
  }).forEach((item, index) => {
    var line = [];
    line.push(item.name);
    let group = groups.find(i => i.id == item.group);
    let category = categories.find(i => i.id == item.category);
    line.push(group ? group.name : '');
    line.push(category ? category.name : '');
    infoRows.push(line);
    images[index] = item.pictures;
  })

  Promise.all(images.map(inner => {
    return inner ? Promise.all(inner.map(img => { if (typeof img == "string" && !img.includes('.png')) return imgToBase64(img) })) : new Promise(resolve => { resolve(undefined) })
  })
  ).then(base => {
    imgData = base;

    var pageContent = function (data) {

      // FOOTER
      doc.setFontSize(7);
      doc.text(footer, data.settings.margin.left, doc.internal.pageSize.height - 10);
  };

    doc.autoTable(infoHeader, infoRows, {
      styles: { overflow: 'linebreak', cellPadding: 8, fontSize: 10, lineWidth: 0.1 },
      margin: { top: 10 },
      startY: 17,
      addPageContent: pageContent,
      columnStyles: {
        3: { columnWidth: 100 },
      },
      theme: 'plain',
      drawCell: function (cell, opts) {
        if (opts.column.dataKey === 3) {
          var base = imgData[opts.row.index]
          if (base) {
            var x = cell.textPos.x - 5;
            var y = cell.textPos.y - 7;
            base.forEach(img => {
              if (img) {
                doc.addImage(img, 'JPEG', x, y, 30, 20, undefined, 'FAST');
                x += 32;
              }
            })
          }
        }
      }
    });

    var blob = doc.output("blob");
    window.open(URL.createObjectURL(blob));
  })
    .catch(error => {
      Raven.captureException(e)
      NotificationManager.error('Aconteceu um erro ao gerar o PDF, tente novamente');
    })
}

function imgToBase64(url) {
  if (!window.FileReader) {
    return;
  }
  return new Promise(function (resolve, reject) {
    var xhr = new XMLHttpRequest();
    xhr.responseType = 'blob';
    xhr.open('GET', url, true);
    xhr.withCredentials = false;
    xhr.onload = function () {
      var reader = new FileReader();
      reader.onloadend = function () {
        resolve(reader.result.replace('text/xml', 'image/jpeg'));
      };
      reader.onerror = function () {
        reject({
          status: this.status,
          statusText: xhr.statusText
        })
      }
      reader.readAsDataURL(xhr.response);
    };
    xhr.send();
  })
}