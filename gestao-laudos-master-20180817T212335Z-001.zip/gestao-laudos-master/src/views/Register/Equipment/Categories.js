import React, { Component } from 'react';
import {
  Row,
  Col,
  Button,
  ButtonDropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
  Card,
  CardHeader,
  CardFooter,
  CardBody,
  Form,
  FormGroup,
  FormText,
  Label,
  Progress,
  Input,
  InputGroup,
  InputGroupAddon,
  InputGroupButton,
  ListGroup,
  ListGroupItem,
  Modal,
  ModalBody,
  ModalFooter,
  ModalHeader
} from 'reactstrap';
import Dropzone from 'react-dropzone';
import {NotificationManager} from 'react-notifications';
import Category from './Category';
import {database, storage} from '../../../firebase';
import {BootstrapTable, TableHeaderColumn} from 'react-bootstrap-table';

function deleteTool(item) {
  if (confirm('Tem certeza que deseja deletar o grupo ' + item.name + ' (Esta ação vai deletar todas as categorias deste grupo também)?')) {
    database.ref('groups/' + item.id).remove();
  }
}

function deleteCategory(item) {
  if (confirm('Tem certeza que deseja deletar a categoria ' + item.name + '?')) {
    database.ref('groups/' + item.parentId + "/categories/" + item.id).remove();
  }
}

class Categories extends Component {

  constructor(props) {
    super(props);

    this.state = { 
      groups: [],
      categories: [],
      inputs: [],
      groupModal: false,
      categoryModal: false,
      files: [],
      selectedGroup: undefined,
      selectedCategory: undefined,
      newGroup: {},
      newCategory: {},
      equipment: {},
      progress: 0,
      modal: false,
      equipments: []
    };

    this.toggleGroup = this.toggleGroup.bind(this);
    this.toggleCategory = this.toggleCategory.bind(this);

    this.toggle = this.toggle.bind(this);
  }

  componentWillMount() {
    window.scrollTo(0, 0)
    database.ref('groups').on('value', snapshot => {
      var groups = [];
      snapshot.forEach(childSnapshot => {
        var group = childSnapshot.val();
        group.id = childSnapshot.key;
        groups.push(group);
      });

      groups.sort((a,b) => {return (a.name > b.name) ? 1 : ((b.name > a.name) ? -1 : 0)})

      this.setState({
        groups
      })
    })
  }

  createCustomSearchField(props) {
    return (
      <SearchField
        defaultValue={ props.defaultSearch }
        placeholder={ 'Pesquisar' }/>
    );
  }

  toggle() {
    this.setState(prevstate => ({
      modal: !prevstate.modal
    }));
  }

  onSelectGroup(event) {
    let selectedGroupId = event.target.value;
    this.setState({
      categories: [],
      selectedCategory: 'invalid',
      selectedGroup: selectedGroupId
    }, () => this.getCategories())
  }

  onChangeNewGroup(event) {
    let newGroup = this.state.isEditing ? this.state.selectedGroup : this.state.newGroup;
    newGroup.name = event.target.value.toUpperCase();

    this.setState({
      newGroup
    })
  }

  saveGroup() {
    let group = this.state.newGroup;
    var key = group.id;
    if(group.id) delete group.id;
    if (this.state.isEditing) {
      database.ref('groups').child(key).update(group);
      this.setState({
        newGroup: {},
        groupModal: false,
        groups: []
      }, () => this.updateGroups())
    } else {
      database.ref('groups').push().set(group);
      this.setState({
        newGroup: {},
        groupModal: false,
        groups: []
      }, () => this.updateGroups())
    }
  }

  updateGroups() {
    database.ref('groups')
      .once('value', (snapshot) => {
        var groups = []
        snapshot.forEach(child => {
          var id = child.key;
          var group = child.val();
          group.id = id;
          groups.push(group)
        })

        groups.sort((a,b) => {return (a.name > b.name) ? 1 : ((b.name > a.name) ? -1 : 0)})
        this.setState({
          groups
        })
    });  
  }

  appendInput() {
    this.setState({ inputs: this.state.inputs.concat([{id: 2, type: 'number', label: 'Another label'}]) });
  }

  toggleGroup() {
    this.setState({
      groupModal: !this.state.groupModal
    });
  }

  toggleCategory() {
    this.setState({
      categoryModal: !this.state.categoryModal
    });
  }

  onCategoryChange(category) {
    this.setState({
      newCategory: category
    })
  }

  onCreateCategory() {
    let category = this.state.newCategory;
    var key = category.id;
    if (category.id) delete category.id
    window.scrollTo(0, 0)
    if (this.state.isCategoryEditing) {
      if (key) {
        database.ref('groups').child(this.state.selectedGroup).child('categories').child(key).update(category);
        this.setState({
          newCategory: {},
          categoryModal: false,
        })
      } 
    } else {
      database.ref('groups').child(this.state.selectedGroup).child('categories').push().set(category);
      this.setState({
        newCategory: {},
        categoryModal: false,
      })
    }
  }

  getCategories(hasSelected) {
    database.ref('groups').child(this.state.selectedGroup).child('categories')
    .on('value', (snapshot) => {
      var categories = [];
      snapshot.forEach(child => {
        var id = child.key;
        var category = child.val();
        category.id = id;
        category.parentId = this.state.selectedGroup;
        if (hasSelected && id == this.state.selectedCategory) {
          this.setState({
            selectedCategory: category,
            inputs: category.fields
          })
        }
        categories.push(category);
      })

      categories.sort((a,b) => {return (a.name > b.name) ? 1 : ((b.name > a.name) ? -1 : 0)})

      this.setState({
        categories
      })
    })
  }

  onSelectCategory(event) {
    let selected = this.state.categories.find(cat => cat.id == event.target.value);
    this.setState({
      selectedCategory: selected,
      inputs: selected.fields
    })
  }

  onInputChange(event) {
    let name = event.target.name.replace("/","-").toUpperCase();
    let value = event.target.value.toUpperCase();
    let equipment = this.state.equipment;

    equipment[name] = value;
    this.setState({
      equipment
    })
  }

  onInputGroupChange(event, group) {
    let name = event.target.name;
    let value = event.target.value.toUpperCase();
    let equipment = this.state.equipment;

    equipment[group]= {[name]: value};
    this.setState({
      equipment
    })
  }

  addGroup() {
    this.setState({
      selectedGroup: undefined,
      isEditing: false
    }, () => this.toggleGroup())
  }

  addCategory() {
    if (this.state.selectedGroup && this.state.selectedGroup.length > 0) {
      this.setState({
        selectedCategory: undefined,
        isCategoryEditing: false
      }, () => this.toggleCategory())
    }
  }

  buttonFormatter(cell, row){
    return (
      <div>
        <Button onClick={() => deleteTool(row)}><i className="fa fa-trash" aria-hidden="true"></i></Button>
      </div>
    );
  }

  categoryButtonFormatter(cell, row){
    return (
      <div>
        <Button onClick={() => deleteCategory(row)}><i className="fa fa-trash" aria-hidden="true"></i></Button>
      </div>
    );
  }

  render() {
    const selectRowProp = {
      mode: 'checkbox',
      bgColor: 'gray', // you should give a bgcolor, otherwise, you can't regonize which row has been selected
      hideSelectColumn: true,  // enable hide selection column.
      clickToSelect: true  // you should enable clickToSelect, otherwise, you can't select column.
    };

    const options = { 
      noDataText: 'Não existem dados para esta pesquisa', 
      searchField: this.createCustomSearchField,
      onRowDoubleClick: row => {
        this.setState({
          selectedGroup: row,
          isEditing: true
        }, () => {this.toggleGroup()})
      }
    }

    const catOptions = { 
      noDataText: 'Não existem dados para esta pesquisa', 
      searchField: this.createCustomSearchField,
      onRowDoubleClick: row => {
        this.setState({
          selectedCategory: row,
          isCategoryEditing: true
        }, () => {this.toggleCategory()})
      }
    }

    return (
      <div>
        <Row>
          <Col sm={{size: 10, offset: 1}}>
            <Card>
              <CardHeader>
                Categorias
              </CardHeader>
              <CardBody>
                <FormGroup>
                  <Label htmlFor="group">Grupo</Label>
                  <Input type="select" value={this.state.isEditing != true ? this.state.selectedGroup : 'invalid'} id="group" name="group" placeholder="Grupo" onChange={this.onSelectGroup.bind(this)} defaultValue="invalid" >
                    <option value="invalid" disabled>Selecione</option>
                    { this.state.groups.map(group => <option key={group.id} value={group.id}>{group.name}</option>) }
                  </Input>
                </FormGroup>
                <BootstrapTable version='4' data={this.state.categories} search={true} hover pagination options={catOptions}>
                  <TableHeaderColumn dataField='id' isKey hidden searchable={ false } >ID</TableHeaderColumn>
                  <TableHeaderColumn dataField='name' dataSort={ true }>Nome</TableHeaderColumn>
                  <TableHeaderColumn dataField="button" width="60" editable={false} dataFormat={this.categoryButtonFormatter}></TableHeaderColumn>
                </BootstrapTable>
              </CardBody>
              <CardFooter>
                <Button color="primary" className="float-right" onClick={this.addCategory.bind(this)}><i className="fa fa-plus" aria-hidden="true"></i> Adicionar</Button>
              </CardFooter>
            </Card>
          </Col>
        </Row>

        <Row>
          <Col sm={{size: 10, offset: 1}}>
            <Card>
              <CardHeader>
                Grupos
              </CardHeader>
              <CardBody>
                <BootstrapTable version='4' data={this.state.groups} search={true} hover pagination options={options}>
                  <TableHeaderColumn dataField='id' isKey hidden searchable={ false } >ID</TableHeaderColumn>
                  <TableHeaderColumn dataField='name' dataSort={ true }>Nome</TableHeaderColumn>
                  <TableHeaderColumn dataField="button" width="60" editable={false} dataFormat={this.buttonFormatter}></TableHeaderColumn>
                </BootstrapTable>
              </CardBody>
              <CardFooter>
                <Button color="primary" className="float-right" onClick={this.addGroup.bind(this)}><i className="fa fa-plus" aria-hidden="true"></i> Adicionar</Button>
              </CardFooter>
            </Card>
          </Col>
        </Row>

        
        {/* Group Modal */}
        <Modal isOpen={this.state.groupModal} toggle={this.toggleGroup} className={this.props.className}>
          <ModalHeader toggle={this.toggleGroup}>Adicionar grupo</ModalHeader>
          <ModalBody>
            <Row>
              <Col xs="12">
                <FormGroup>
                  <Label htmlFor="name">Nome do grupo</Label>
                  <Input type="text" id="name" value={this.state.selectedGroup && this.state.selectedGroup.name || this.state.newGroup.name || ""} name="name" placeholder="Veículos" onChange={this.onChangeNewGroup.bind(this)} />
                </FormGroup>
              </Col>
            </Row>
          </ModalBody>
          <ModalFooter>
            <Button color="primary" onClick={this.saveGroup.bind(this)}>Salvar</Button>
            <Button color="secondary" onClick={this.toggleGroup}>Cancelar</Button>
          </ModalFooter>
        </Modal>     

        {/* Category Modal */}
        <Modal isOpen={this.state.categoryModal} toggle={this.toggleCategory}>
          <ModalHeader toggle={this.toggleCategory}>Adicionar categoria</ModalHeader>
          <ModalBody>
            <Category selectedCategory={this.state.selectedCategory} selectedGroup={this.state.selectedGroup} categoryChange={this.onCategoryChange.bind(this)}/>
          </ModalBody>
          <ModalFooter>
            <Button color="primary" onClick={this.onCreateCategory.bind(this)}>Salvar</Button>
            <Button color="secondary" onClick={this.toggleCategory}>Cancelar</Button>
          </ModalFooter>
        </Modal>   
      </div>
    )
  }
}

export default Categories;