import React, { Component } from 'react';
import { Container, Row, Col, Card, CardBody, FormText, CardFooter, Button, Input, FormFeedback, InputGroup, InputGroupAddon, FormGroup, Label } from 'reactstrap';
import { Redirect, Route } from 'react-router-dom';
import { NotificationManager } from 'react-notifications';
import { secondaryAuth, database } from '../../../firebase.js';
import Autocomplete from '../../../components/Autocomplete/Autocomplete';
import Raven from 'raven-js';

const api_client = "https://us-central1-gestao-laudos.cloudfunctions.net/client"

const FormErrors = ({ formErrors }) =>
  <div className='formErrors'>
    {Object.keys(formErrors).map((fieldName, i) => {
      if (formErrors[fieldName].length > 0) {
        return (
          <p key={i}>{formErrors[fieldName]}</p>
        )
      } else {
        return '';
      }
    })}
  </div>

class RegisterClient extends Component {

  constructor(props) {
    super(props);

    this.state = {
      isEmployee: false,
      name: '',
      email: '',
      password: '',
      errors: { name: '', email: '', password: '', confirmPassword: '', company: '' },
      nameValid: false,
      emailValid: false,
      passwordValid: false,
      companyValid: false,
      typeValid: false,
      formValid: false,
      redirect: false,
      clients: [],
      client: {},
      isEditing: false
    }

  }

  componentWillMount() {
    database.ref('clients').on('value', snapshot => {
      var clients = [];
      snapshot.forEach(childSnapshot => {
        var client = childSnapshot.val();
        client.id = childSnapshot.key;
        clients.push(client);
      });

      clients.sort((a, b) => { return (a.name > b.name) ? 1 : ((b.name > a.name) ? -1 : 0) })

      this.setState({
        clients
      }, () => this.setUser())
    });
  }

  setUser() {
    if (this.props.user) {
      var client = this.state.clients.find(c => c.id == this.props.user.company);

      this.setState({
        name: this.props.user.name,
        email: this.props.user.email,
        client,
        nameValid: true,
        emailValid: true,
        passwordValid: true,
        companyValid: true,
        id: this.props.user.id,
        isEditing: true
      }, () => { this.validateForm(); this.client.setValue(client.name) })
    }
  }

  handleUserInput(event) {
    const name = event.target.name;
    const value = event.target.value;

    this.setState({
      [name]: value
    }, () => { this.validateField(name, value) })
  }

  onSelectClient(item) {
    this.setState({
      client: item
    }, () => this.validateCompany())
  }

  validateCompany() {
    let client = this.state.client;
    let fieldValidationErrors = this.state.errors;

    let companyValid = this.state.companyValid;

    companyValid = client != undefined
    fieldValidationErrors.company = client ? '' : 'Selecione a empresa desse usuário';

    this.setState({
      errors: fieldValidationErrors,
      companyValid
    }, () => this.validateForm())
  }

  validateField(fieldName, value) {
    let fieldValidationErrors = this.state.errors;
    let nameValid = this.state.nameValid;
    let emailValid = this.state.emailValid;
    let companyValid = this.state.companyValid;
    let passwordValid = this.state.passwordValid;

    switch (fieldName) {
      case 'name':
        nameValid = value.length >= 3;
        fieldValidationErrors.name = nameValid ? '' : 'Nome deve ter no mínimo 3 caracteres';
        break;
      case 'email':
        emailValid = value.match(/^([\w.%+-]+)@([\w-]+\.)+([\w]{2,})$/i) ? true : false;
        fieldValidationErrors.email = emailValid ? '' : 'Email inválido';
        break;
      case 'password':
        passwordValid = value.length >= 6;
        fieldValidationErrors.password = passwordValid ? '' : 'A senha deve ter no mínimo 6 caracteres';
        break;
      default:
        break;
    }

    this.setState({
      errors: fieldValidationErrors,
      nameValid,
      emailValid: emailValid,
    }, () => this.validateForm());
  }

  validateForm() {
    this.setState({ formValid: this.state.nameValid && this.state.emailValid && this.state.companyValid });
  }

  handleSubmit() {
    let name = this.state.name;
    let email = this.state.email;
    let password = this.state.password
    // let employee = this.state.isEmployee;
    let company = this.state.client.id;

    let self = this

    if (this.state.formValid) {
      if (!this.state.isEditing) {
        fetch(api_client, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ name, email, password, company })
        })
          .then(response => {
            response.json().then(json => { this.handleError(json.code); })
              .catch(error => { if (response.status === 201) this.props.onSave() })

          })
          .catch(error => { this.handleError(error.errorCode) })
      } else {
        fetch(api_client + "?uid=" + this.state.id, {
          method: 'PATCH',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ name, email, password, company })
        })
          .then(response => {
            response.json().then(json => { this.handleError(json.code); })
              .catch(error => { if (response.status === 200) this.props.onSave() })

          })
          .catch(error => { this.handleError(error.errorCode) })
      }
    }
  }

  generatePassword() {
    var length = 8,
      charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789",
      retVal = "";
    for (var i = 0, n = charset.length; i < length; ++i) {
      retVal += charset.charAt(Math.floor(Math.random() * n));
    }
    return retVal;
  }

  saveUser() {
    let name = this.state.name;
    let email = this.state.email;
    let employee = this.state.isEmployee;
    let company = this.state.client.id;

    var self = this;

    let user = { name, email, employee, company }
    database.ref('users/' + secondaryAuth.currentUser.uid).set(user).then(() => {
      secondaryAuth.signOut();
      self.props.onSave();
    });
  }

  updateProfile() {
    secondaryAuth.currentUser.updateProfile({
      displayName: this.state.name
    }).catch(error => {
      Raven.captureException(error)
      this.handleError(error.code)
    });
  }

  sendVerificationEmail() {
    var self = this;
    secondaryAuth.sendPasswordResetEmail(this.state.email)
      .then(function () {
        NotificationManager.info("Um email foi enviado para confirmação e geração de nova senha.");
        self.props.onSave();
      }, function (error) {
        this.handleError(error.code)
      });
  }

  handleError(errorCode) {
    var message = 'Ocorreu um erro ao registrar o usuário'
    switch (errorCode) {
      case 'auth/invalid-email':
        message = 'O email inserido é inválido.';
        break;
      case 'auth/email-already-in-use':
        message = 'Este email já está cadastrado no sistema.';
        break;
      case 'auth/email-already-exists':
        message = 'Este email já está cadastrado no sistema.';
        break;
      case 'auth/weak-password':
        message = 'Senha muito fraca! A senha deve ter no mínimo 6 caracteres.';
        break;
    }

    NotificationManager.error(message, "Atenção!");
  }

  render() {
    return (
      <div className="align-items-center">
        <Container>
          <Row className="justify-content-center">
            <Col xs="12">
              <h3 className="text-muted">{ this.state.isEditing ? 'Edite uma conta do cliente' : 'Crie uma conta para o seu cliente' }</h3>
              <FormGroup>
                <InputGroup className="mb-3">
                  <InputGroupAddon><i className="icon-user"></i></InputGroupAddon>
                  <Input type="text" valid={this.state.nameValid} placeholder="Nome completo" value={this.state.name} name="name" onChange={this.handleUserInput.bind(this)} />
                </InputGroup>
                <FormFeedback>{this.state.errors.name}</FormFeedback>
              </FormGroup>
              <FormGroup>
                <InputGroup className="mb-3">
                  <InputGroupAddon>@</InputGroupAddon>
                  <Input type="text" placeholder="Email" name="email" valid={this.state.emailValid} value={this.state.email} onChange={this.handleUserInput.bind(this)} />
                </InputGroup>
                <FormFeedback>{this.state.errors.email}</FormFeedback>
              </FormGroup>
              <FormGroup>
                <InputGroup className="mb-3">
                  <InputGroupAddon><i className="icon-lock"></i></InputGroupAddon>
                  <Input type="password" placeholder="Senha" style={{ textTransform: 'none' }} ref={c => { this.password = c }} valid={this.state.passwordValid} value={this.state.password} name="password" onChange={this.handleUserInput.bind(this)} />
                </InputGroup>
                <FormFeedback>{this.state.errors.password}</FormFeedback>
              </FormGroup>
              <FormGroup>
                <Label htmlFor="client">Cliente</Label>
                <Autocomplete id="client" field="name" defaultValue={this.state.client} ref={el => { this.client = el }} placeholder="Cliente" onSelectItem={this.onSelectClient.bind(this)} defaultList={this.state.clients} />
                <FormText color="muted">
                  Comece a digitar e espere pelos resultados
                </FormText>
              </FormGroup>
              <FormErrors formErrors={this.state.errors} />
              <Button color="success" disabled={!this.state.formValid} block onClick={this.handleSubmit.bind(this)}>Criar conta</Button>
            </Col>
          </Row>
        </Container>
      </div>
    );
  }
}

export default RegisterClient;
