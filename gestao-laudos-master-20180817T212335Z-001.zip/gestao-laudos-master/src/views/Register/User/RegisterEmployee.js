import React, { Component } from 'react';
import { Container, Row, Col, Card, CardBody, FormText, CardFooter, Button, Input, FormFeedback, InputGroup, InputGroupAddon, FormGroup, Label } from 'reactstrap';
import { Redirect, Route } from 'react-router-dom';
import { NotificationManager } from 'react-notifications';
import { secondaryAuth, database } from '../../../firebase.js';
import Autocomplete from '../../../components/Autocomplete/Autocomplete';
import Raven from 'raven-js';

const api_user = "https://us-central1-gestao-laudos.cloudfunctions.net/user"

const FormErrors = ({ formErrors }) =>
  <div className='formErrors'>
    {Object.keys(formErrors).map((fieldName, i) => {
      if (formErrors[fieldName].length > 0) {
        return (
          <p key={i}>{formErrors[fieldName]}</p>
        )
      } else {
        return '';
      }
    })}
  </div>

class RegisterEmployee extends Component {

  constructor(props) {
    super(props);

    this.state = {
      isEmployee: true,
      name: '',
      email: '',
      password: '',
      errors: { name: '', email: '', password: '' },
      nameValid: false,
      emailValid: false,
      passwordValid: false,
      typeValid: false,
      formValid: false,
      redirect: false,
      clients: [],
      client: {},
      isEditing: false
    }

  }

  componentWillMount() {
    this.setUser();
  }

  setUser() {
    if (this.props.user) {
      this.setState({
        name: this.props.user.name,
        email: this.props.user.email,
        nameValid: true,
        emailValid: true,
        passwordValid: true,
        id: this.props.user.id,
        isEditing: true
      }, () => { this.validateForm() })
    }
  }

  handleUserInput(event) {
    const name = event.target.name;
    const value = event.target.value;

    this.setState({
      [name]: value
    }, () => { this.validateField(name, value) })
  }

  onSelectClient(item) {
    this.setState({
      client: item
    }, () => this.validateCompany())
  }

  validateCompany() {
    let client = this.state.client;
    let fieldValidationErrors = this.state.errors;

    let companyValid = this.state.companyValid;

    companyValid = client != undefined
    fieldValidationErrors.company = client ? '' : 'Selecione a empresa desse usuário';

    this.setState({
      errors: fieldValidationErrors,
      companyValid
    }, () => this.validateForm())
  }

  validateField(fieldName, value) {
    let fieldValidationErrors = this.state.errors;
    let nameValid = this.state.nameValid;
    let emailValid = this.state.emailValid;
    let passwordValid = this.state.passwordValid;

    switch (fieldName) {
      case 'name':
        nameValid = value.length >= 3;
        fieldValidationErrors.name = nameValid ? '' : 'Nome deve ter no mínimo 3 caracteres';
        break;
      case 'email':
        emailValid = value.match(/^([\w.%+-]+)@([\w-]+\.)+([\w]{2,})$/i) ? true : false;
        fieldValidationErrors.email = emailValid ? '' : 'Email inválido';
        break;
      case 'password':
        passwordValid = value.length >= 6;
        fieldValidationErrors.password = passwordValid ? '' : 'A senha deve ter no mínimo 6 caracteres';
        break;
      default:
        break;
    }

    this.setState({
      errors: fieldValidationErrors,
      nameValid,
      emailValid,
      passwordValid
    }, () => this.validateForm());
  }

  validateForm() {
    this.setState({ formValid: this.state.nameValid && this.state.emailValid && this.state.passwordValid });
  }

  handleSubmit() {
    let email = this.state.email;
    let password = this.state.password;
    let name = this.state.name

    if (this.state.formValid) {
      if (!this.state.isEditing) {
        fetch(api_user, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ name, email, password })
        })
          .then(response => {
            response.json().then(json => { this.handleError(json.code); })
              .catch(error => { if (response.status === 201) this.props.onSave(); })

          })
          .catch(error => { this.handleError(error.errorCode) })
      } else {
        fetch(api_user + "?uid=" + this.state.id, {
          method: 'PATCH',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ name, email, password })
        })
          .then(response => {
            response.json().then(json => { this.handleError(json.code); })
              .catch(error => { if (response.status === 200) this.props.onSave(); })

          })
          .catch(error => { this.handleError(error.errorCode) })
      }
    }
  }

  generatePassword() {
    var length = 8,
      charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789",
      retVal = "";
    for (var i = 0, n = charset.length; i < length; ++i) {
      retVal += charset.charAt(Math.floor(Math.random() * n));
    }
    return retVal;
  }

  saveUser() {
    let name = this.state.name;
    let email = this.state.email;
    let employee = this.state.isEmployee;
    let company = this.state.client.id;

    var self = this;

    let user = { name, email, employee }
    database.ref('users/' + secondaryAuth.currentUser.uid).set(user).then(() => {
      secondaryAuth.signOut();
      self.props.onSave();
    });
  }

  updateProfile() {
    secondaryAuth.currentUser.updateProfile({
      displayName: this.state.name
    }).catch(error => {
      Raven.captureException(error)
      this.handleError(error.code)
    });
  }

  sendVerificationEmail() {
    var self = this;
    secondaryAuth.sendPasswordResetEmail(this.state.email)
      .then(function () {
        NotificationManager.info("Um email foi enviado para confirmação e geração de nova senha.");
        self.props.onSave();
      }, function (error) {
        this.handleError(error.code)
      });
  }

  handleError(errorCode) {
    var message = 'Ocorreu um erro ao registrar o usuário'
    switch (errorCode) {
      case 'auth/invalid-email':
        message = 'O email inserido é inválido.';
        break;
      case 'auth/email-already-in-use':
        message = 'Este email já está cadastrado no sistema.';
        break;
      case 'auth/email-already-exists':
        message = 'Este email já está cadastrado no sistema.';
        break;
      case 'auth/weak-password':
        message = 'Senha muito fraca! A senha deve ter no mínimo 6 caracteres.';
        break;
    }

    NotificationManager.error(message, "Atenção!");
  }

  render() {
    return (
      <div className="align-items-center">
        <Container>
          <Row className="justify-content-center">
            <Col xs="12">
              <h3 className="text-muted">{ this.state.isEditing ? 'Editar conta do funcionário' : 'Crie uma conta para o seu funcionário' }</h3>
              <FormGroup>
                <InputGroup className="mb-3">
                  <InputGroupAddon><i className="icon-user"></i></InputGroupAddon>
                  <Input type="text" valid={this.state.nameValid} placeholder="Nome completo" value={this.state.name} name="name" onChange={this.handleUserInput.bind(this)} />
                </InputGroup>
                <FormFeedback>{this.state.errors.name}</FormFeedback>
              </FormGroup>
              <FormGroup>
                <InputGroup className="mb-3">
                  <InputGroupAddon>@</InputGroupAddon>
                  <Input type="text" placeholder="Email" name="email" valid={this.state.emailValid} value={this.state.email} onChange={this.handleUserInput.bind(this)} />
                </InputGroup>
                <FormFeedback>{this.state.errors.email}</FormFeedback>
              </FormGroup>
              <FormGroup>
                <InputGroup className="mb-3">
                  <InputGroupAddon><i className="icon-lock"></i></InputGroupAddon>
                  <Input type="password" placeholder="Senha" style={{ textTransform: 'none' }} ref={c => { this.password = c }} valid={this.state.passwordValid} value={this.state.password} name="password" onChange={this.handleUserInput.bind(this)} />
                </InputGroup>
                <FormFeedback>{this.state.errors.password}</FormFeedback>
              </FormGroup>
              <FormErrors formErrors={this.state.errors} />
              <Button color="success" disabled={!this.state.formValid} block onClick={this.handleSubmit.bind(this)}>Salvar</Button>
            </Col>
          </Row>
        </Container>
      </div>
    );
  }
}

export default RegisterEmployee;
