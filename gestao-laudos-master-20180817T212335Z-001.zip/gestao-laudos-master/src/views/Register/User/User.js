import React, { Component } from 'react'
import {
  Row,
  Col,
  Button,
  ButtonDropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
  Card,
  CardHeader,
  CardFooter,
  CardBody,
  Form,
  FormGroup,
  FormText,
  Label,
  Input,
  InputGroup,
  InputGroupAddon,
  InputGroupButton,
  ListGroup,
  ListGroupItem,
  Modal,
  ModalBody,
  ModalFooter,
  ModalHeader
} from 'reactstrap'
import InputMask from 'react-input-mask'
import { database, secondaryAuth } from '../../../firebase'
import { NotificationManager } from 'react-notifications'
import { BootstrapTable, TableHeaderColumn } from 'react-bootstrap-table'
import RegisterClient from './RegisterClient'
import RegisterEmployee from './RegisterEmployee'
import cep from 'cep-promise'

const api_client = "https://us-central1-gestao-laudos.cloudfunctions.net/client"

function deleteTool(item) {
  if (confirm('Tem certeza que deseja deletar o usuário ' + item.name + ' ?')) {
    fetch(api_client + "?uid=" + item.id, {
      method: 'DELETE',
      headers: {
        'Content-Type': 'application/json'
      }
    })
      .then(response => {
        if (response.status !== 200) NotificationManager.error("Não foi possível deletar o usuário")
      })
      .catch(error => { this.handleError(error.errorCode) })
  }
}

class User extends Component {

  constructor(props) {
    super(props)

    this.state = {
      clients: [],
      users: [],
      employees: [],
      clientModal: false,
      selectedUser: undefined
    }

    this.toggleClient = this.toggleClient.bind(this)
    this.editClient = this.editClient.bind(this)
    this.editEmployee = this.editEmployee.bind(this)
    this.toggleEmployee = this.toggleEmployee.bind(this)
  }

  componentWillMount() {
    database.ref('clients').on('value', snapshot => {
      var clients = []
      snapshot.forEach(childSnapshot => {
        var client = childSnapshot.val()
        client.id = childSnapshot.key
        clients.push(client)
      })

      clients.sort((a, b) => { return (a.name > b.name) ? 1 : ((b.name > a.name) ? -1 : 0) })

      this.setState({
        clients
      })
    })

    database.ref('users').on('value', snapshot => {
      var users = []
      var employees = []
      snapshot.forEach(childSnapshot => {
        var user = childSnapshot.val()
        user.id = childSnapshot.key
        if (!user.employee) users.push(user)
        else employees.push(user)
      })

      users.sort((a, b) => { return (a.name > b.name) ? 1 : ((b.name > a.name) ? -1 : 0) })
      employees.sort((a, b) => { return (a.name > b.name) ? 1 : ((b.name > a.name) ? -1 : 0) })

      this.setState({
        users,
        employees
      })
    })
  }

  createCustomSearchField(props) {
    return (
      <SearchField
        defaultValue={props.defaultSearch}
        placeholder={'Pesquisar'} />
    )
  }

  createCustomClearButton(onClick) {
    return (
      <ClearSearchButton
        btnText='Limpar'
        btnContextual='btn-warning'
        onClick={onClick} />
    )
  }

  toggleClient() {
    this.setState(prevState => ({
      clientModal: !prevState.clientModal
    }))
  }

  toggleEmployee() {
    this.setState(prevState => ({
      employeeModal: !prevState.employeeModal
    }))
  }

  saveClient() {
    this.setState(prevState => ({
      clientModal: !prevState.clientModal
    }))
    NotificationManager.success("Usuário criado com sucesso!")
  }

  saveEmployee() {
    this.setState(prevState => ({
      employeeModal: !prevState.employeeModal
    }))
    NotificationManager.success("Usuário criado com sucesso!")
  }

  editClient(item) {
    this.setState({
      selectedUser: item
    }, () => this.toggleClient())
  }

  editEmployee(item) {
    this.setState({
      selectedUser: item
    }, () => this.toggleEmployee())
  }

  addClient() {
    this.setState({
      selectedUser: undefined
    }, () => this.toggleClient())
  }

  addEmployee() {
    this.setState({
      selectedUser: undefined
    }, () => this.toggleEmployee()
    )
  }

  companyFormatter(cell, row) {
    var found = this.state.clients.find(item => item.id == cell)
    return (
      <span>{found ? found.name : ''}</span>
    )
  }

  sortByCompany(a, b, order) {
    var first = this.state.clients.find(item => item.id == a.company)
    var second = this.state.clients.find(item => item.id == b.company)
    if (order == 'desc') {
      if (first.name > second.name) return -1;
      else if (first.name < second.name) return 1;
      else return 0;
    } else {
      if (first.name > second.name) return 1;
      else if (first.name < second.name) return -1;
      else return 0;
    }
  }

  buttonFormatter(cell, row) {
    return (
      <div>
        <Button onClick={() => deleteTool(row)}><i className="fa fa-trash" aria-hidden="true"></i></Button>
      </div>
    )
  }

  render() {
    const selectRowProp = {
      mode: 'checkbox',
      bgColor: 'gray', // you should give a bgcolor, otherwise, you can't regonize which row has been selected
      hideSelectColumn: true,  // enable hide selection column.
      clickToSelect: true  // you should enable clickToSelect, otherwise, you can't select column.
    }

    const options = {
      noDataText: 'Não existem dados para esta pesquisa',
      searchField: this.createCustomSearchField,
      onRowDoubleClick: this.editClient
    }

    const employeeOptions = {
      noDataText: 'Não existem dados para esta pesquisa',
      searchField: this.createCustomSearchField,
      onRowDoubleClick: this.editEmployee
    }

    return (
      <div>
        <Row>
          <Col sm={{ size: 10, offset: 1 }}>
            <Card>
              <CardHeader>
                Clientes - Usuários
              </CardHeader>
              <CardBody>
                <BootstrapTable version='4' data={this.state.users} search={false} hover pagination options={options}>
                  <TableHeaderColumn dataField='id' isKey searchable={false} hidden>Código</TableHeaderColumn>
                  <TableHeaderColumn dataField='name' dataSort={true}>Nome</TableHeaderColumn>
                  <TableHeaderColumn dataField='email' dataSort={true}>Email</TableHeaderColumn>
                  <TableHeaderColumn dataField='company' dataFormat={this.companyFormatter.bind(this)} sortFunc={this.sortByCompany.bind(this)} dataSort={true} >Empresa</TableHeaderColumn>
                  <TableHeaderColumn dataField="button" width="60" editable={false} dataFormat={this.buttonFormatter}></TableHeaderColumn>
                </BootstrapTable>
              </CardBody>
              <CardFooter>
                <Button color="primary" className="float-right" onClick={this.addClient.bind(this)}><i className="fa fa-plus" aria-hidden="true"></i> Adicionar</Button>
              </CardFooter>
            </Card>
          </Col>
        </Row>

        <Row>
          <Col sm={{ size: 10, offset: 1 }}>
            <Card>
              <CardHeader>
                Funcionários - Usuários
              </CardHeader>
              <CardBody>
                <BootstrapTable version='4' data={this.state.employees} search={false} hover pagination options={employeeOptions}>
                  <TableHeaderColumn dataField='id' isKey searchable={false} hidden>Código</TableHeaderColumn>
                  <TableHeaderColumn dataField='name' dataSort={true}>Nome</TableHeaderColumn>
                  <TableHeaderColumn dataField='email' dataSort={true}>Email</TableHeaderColumn>
                  <TableHeaderColumn dataField="button" width="60" editable={false} dataFormat={this.buttonFormatter}></TableHeaderColumn>
                </BootstrapTable>
              </CardBody>
              <CardFooter>
                <Button color="primary" className="float-right" onClick={this.addEmployee.bind(this)}><i className="fa fa-plus" aria-hidden="true"></i> Adicionar</Button>
              </CardFooter>
            </Card>
          </Col>
        </Row>

        <Modal isOpen={this.state.clientModal} toggle={this.toggleClient}>
          <ModalBody>
            <RegisterClient onSave={this.saveClient.bind(this)} user={this.state.selectedUser} />
          </ModalBody>
          <ModalFooter>
            <Button color="secondary" onClick={this.toggleClient}>Cancelar</Button>
          </ModalFooter>
        </Modal>

        <Modal isOpen={this.state.employeeModal} toggle={this.toggleEmployee}>
          <ModalBody>
            <RegisterEmployee onSave={this.saveEmployee.bind(this)} user={this.state.selectedUser} />
          </ModalBody>
          <ModalFooter>
            <Button color="secondary" onClick={this.toggleEmployee}>Cancelar</Button>
          </ModalFooter>
        </Modal>
      </div>
    )
  }
}

export default User