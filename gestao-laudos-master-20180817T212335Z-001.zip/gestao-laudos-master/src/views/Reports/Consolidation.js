import React, { Component } from 'react'

import {
    Row,
    Col,
    Button,
    Card,
    CardHeader,
    CardFooter,
    CardBody,
    CardTitle,
    Table,
    Pagination,
    PaginationItem,
    PaginationLink,
    Badge,
    FormGroup,
    Form,
    FormText,
    Input,
    InputGroup,
    InputGroupButton,
    ListGroup,
    ListGroupItem,
    Label
} from 'reactstrap'
import { database } from '../../firebase'
import { NotificationManager } from 'react-notifications'
import Autocomplete from '../../components/Autocomplete/Autocomplete'
import * as pdf from './_consolidation-pdf'
import Moment from 'moment'

var dateFormat = "DD/MM/YYYY"

function deleteReport(item) {
    if (confirm('Tem certeza que deseja deletar este relatório?')) {
        database.ref('consolidations/' + item.id).remove();
    }
}

class Consolidation extends Component {
    constructor(props) {
        super(props)

        this.state = {
            consolidations: [],
            equipment: {},
            client: undefined,
            standard: undefined,
            type: {},
            os_number: undefined,
            ura: '',
            temperature: '',
            selectedStd: {},
            selectedStds: [],
            selectedTests: [],
            reports: [],
            clients: [],
            groups: [],
            categories: [],
            equipments: [],
            standards: [],
            types: [],
            category: {},
            users: [],
            selectedUser: {},
            selectedUsers: []
        }
    }

    componentWillMount() {
        database.ref('consolidations').on('value', snapshot => {
            var consolidations = []
            snapshot.forEach(childSnapshot => {
                var consolidation = childSnapshot.val()
                consolidation.id = childSnapshot.key
                consolidations.push(consolidation)
            })

            this.setState({
                consolidations
            })
        })

        database.ref('reports').on('value', snapshot => {
            const reports = []
            snapshot.forEach(childSnapshot => {
                const report = childSnapshot.val()
                report.id = childSnapshot.key
                reports.push(report)
            })
            this.setState({
                reports
            })
        })

        database.ref('clients').on('value', snapshot => {
            const clients = []
            snapshot.forEach(childSnapshot => {
                var client = childSnapshot.val()
                client.id = childSnapshot.key
                clients.push(client)
            })

            this.setState({ clients })
        })

        var standards = []
        database.ref('standards').on('value', snapshot => {
            snapshot.forEach(childSnapshot => {
                var standard = {}
                standard.name = childSnapshot.val()
                standard.id = childSnapshot.key
                standards.push(standard)
            })

            standards.sort((a, b) => { return (a.name > b.name) ? 1 : ((b.name > a.name) ? -1 : 0) })

            this.setState({
                standards
            })
        })

        var types = []
        database.ref('tests').on('value', snapshot => {
            snapshot.forEach(childSnapshot => {
                var type = {}
                type.name = childSnapshot.val()
                type.id = childSnapshot.key

                types.push(type)
            })
            types.sort((a, b) => { return (a.name > b.name) ? 1 : ((b.name > a.name) ? -1 : 0) })

            this.updateGroups()

            this.setState({
                types
            })
        })

        database.ref('responsables').on('value', snapshot => {
            var users = []
            snapshot.forEach(childSnapshot => {
                let user = childSnapshot.val()
                user.id = childSnapshot.key
                users.push(user)
            })

            users.sort((a, b) => { return (a.name > b.name) ? 1 : ((b.name > a.name) ? -1 : 0) })

            this.setState({
                users
            })
        })
    }

    onSelectClient(item) {
        this.setState({ client: item })
    }

    updateGroups() {
        database.ref('groups')
            .once('value', (snapshot) => {
                var groups = []
                snapshot.forEach(child => {
                    var id = child.key
                    var group = child.val()
                    group.id = id
                    groups.push(group)
                })
                groups.sort((a, b) => { return (a.name > b.name) ? 1 : ((b.name > a.name) ? -1 : 0) })

                this.setState({
                    groups
                })
            })
    }

    onSelectGroup(event) {
        let selectedGroupId = event.target.value
        this.setState({
            categories: [],
            inputs: [],
            equips: [],
            equipment: {},
            category: {},
            selectedGroup: selectedGroupId
        }, () => this.getCategories())
    }

    getCategories() {
        database.ref('groups').child(this.state.selectedGroup).child('categories')
            .once('value', (snapshot) => {
                var categories = []
                snapshot.forEach(child => {
                    var id = child.key
                    var category = child.val()
                    category.id = id
                    categories.push(category)
                })
                categories.sort((a, b) => { return (a.name > b.name) ? 1 : ((b.name > a.name) ? -1 : 0) })

                this.setState({
                    categories
                })
            })
    }

    onSelectCategory(event) {
        let selected = this.state.categories.find(cat => cat.id == event.target.value)
        this.setState({
            category: selected,
            inputs: selected.fields || [],
            equips: [],
            equipment: {},
            tests: {}
        }, () => this.getEquipments())

    }

    getEquipments() {
        database.ref('equipments').on('value', snapshot => {
            var equipments = []
            snapshot.forEach(childSnapshot => {
                var equip = childSnapshot.val()
                equip.id = childSnapshot.key
                if (equip.category == this.state.category.id) equipments.push(equip)
            })
            equipments.sort((a, b) => { return (a.name > b.name) ? 1 : ((b.name > a.name) ? -1 : 0) })

            this.setState({
                equipments
            })
        })
    }

    onSelectEquipment(item) {
        let equipment = this.state.equipment
        equipment = item
        equipment.isGroup = this.state.category.isGroup

        this.setState({
            equipment
        })
    }


    onChangeStandard(event) {
        let selected = this.state.standards.find(cat => cat.id == event.target.value)

        this.setState({
            selectedStd: selected
        })
    }

    onAddStandard() {
        let selectedStds = this.state.selectedStds
        var std = this.state.selectedStd

        selectedStds.push(std)
        var standard = selectedStds.map((item) => item.name).join(' / ')

        this.setState({
            selectedStds,
            standard
        })
    }

    onRemoveStd(item) {
        var selectedStds = this.state.selectedStds.filter(val => { return val.id != item.id })

        var standard = selectedStds.map((item) => item.name).join(' / ')

        this.setState({
            selectedStds,
            standard
        })
    }

    onSelectTest(event) {
        var selectedTest = this.state.selectedTest
        let found = {}
        this.state.types.forEach(type => {
            if (type.id == event.target.value) found = type
        })
        selectedTest = found
        var type = event.target.value

        this.setState({
            type,
            selectedTest
        })
    }

    onAddTest() {
        var selectedTests = [...this.state.selectedTests, this.state.selectedTest]

        this.setState({
            selectedTests
        })
    }

    onRemoveTest(item) {
        var selectedTests = this.state.selectedTests.filter(val => { return val.id != item.id })

        this.setState({
            selectedTests
        })
    }

    onChangeInput(event) {
        var name = event.target.name
        var value = event.target.value.toUpperCase()

        this.setState({
            [name]: value
        })
    }

    onSelectResponsable(event) {
        var selectedUser = this.state.users.find((item) => { return item.id == event.target.value })
        this.setState({
            selected: event.target.value,
            selectedUser
        })
    }

    onAddResponsable() {
        this.setState(prevState => ({
            selectedUsers: [...prevState.selectedUsers, this.state.selectedUser]
        }))
    }

    onRemoveResponsable(item) {
        this.setState(prevState => ({
            selectedUsers: prevState.selectedUsers.filter(function (val) { return val.id !== item.id })
        }))
    }

    generate() {
        var reports = this.state.reports

        if (this.state.client) {
            reports = reports.filter(r => r.info && r.info.client ? r.info.client.id == this.state.client.id : false)
            console.log(this.state.client, reports)
        }

        if (this.state.os_number) {
            reports = reports.filter(r => r.info && r.info.os_number ? r.info.os_number.includes(this.state.os_number) : false)
            console.log(this.state.os_number, reports)
        }

        if (this.state.equipment && Object.keys(this.state.equipment).length > 0) {
            reports = reports.filter(r => r.equipment ? r.equipment.id == this.state.equipment.id : false)
            console.log(this.state.equipment, reports)
        }

        // if(this.state.standard) {
        //     reports = reports.filter(r => r.test_variables ? r.test_variables.standard.split('/') == this.state.standard.split('/') : false )
        // }

        var ids = []
        ids = reports.map(r => {
            return r.id
        })

        var report = {
            date: Moment(new Date()).format(dateFormat),
            number: this.getNumber() + "/" + this.getYear(),
            equipment: this.state.equipment,
            standard: this.state.standard,
            types: this.state.selectedTests,
            os_number: this.state.os_number,
            ura: this.state.ura,
            temperature: this.state.temperature,
            responsables: this.state.selectedUsers,
            reports: ids,
            client: this.state.client ? this.state.client : null
        }

        database.ref('consolidations').push().set(report)
            .then(snapshot => {
                pdf.loadImages(report, reports)
            })

    }

    getNumber() {
        var number = 1
        if (this.state.consolidations.length > 0) {
            var last = this.state.consolidations[this.state.consolidations.length - 1]
            var lastNumberStr = last.number.substring(0, last.number.indexOf('/'))
            var lastNumber = Number(lastNumberStr)
            number = lastNumber + 1
        }

        return this.pad(number, 3)
    }

    getYear() {
        return (new Date()).getFullYear()
    }

    pad(num, size) {
        var s = num + ""
        while (s.length < size) s = "0" + s
        return s
    }

    equipmentFormatter(cell, row) {
        return <p>{cell ? cell.name : ''}</p>
    }

    buttonFormatter(cell, row) {
        return (
            <div>
                <Button onClick={() => this.openPdf(row)} style={{ marginRight: 12 }}><i className="fa fa-external-link" aria-hidden="true"></i></Button>
                <Button onClick={() => deleteReport(row)}><i className="fa fa-trash" aria-hidden="true"></i></Button>
            </div>
        )
    }

    sortByDate(a, b, order) {
        var dateParts = a.date.split("/");
        var first = new Date(dateParts[2], dateParts[1] - 1, dateParts[0]);
        dateParts = b.date.split("/")
        var second = new Date(dateParts[2], dateParts[1] - 1, dateParts[0]);
        console.log(first, second)
        if (first && second) {
            if (order == 'desc') {
                if (first.getTime() > second.getTime()) return -1;
                else if (first.getTime() < second.getTime()) return 1;
                else return 0;
            } else {
                if (first.getTime() > second.getTime()) return 1;
                else if (first.getTime() < second.getTime()) return -1;
                else return 0;
            }
        }
    }

    sortByEquipment(a, b, order) {
        var first = a.equipment
        var second = b.equipment
        if (first && second) {
            if (order == 'desc') {
                if (first.name > second.name) return -1;
                else if (first.name < second.name) return 1;
                else return 0;
            } else {
                if (first.name > second.name) return 1;
                else if (first.name < second.name) return -1;
                else return 0;
            }
        }
    }

    openPdf(report) {
        var reports = [];
        (report.reports || []).forEach(r => {
            var report = this.state.reports.find(rep => rep.id == r)
            reports.push(report)
        })
        pdf.loadImages(report, reports)
    }

    render() {
        const options = {
            noDataText: 'Não existem dados para esta pesquisa',
        }

        return (
            <Row>
                <Col xs="12" sm={{ size: 10, offset: 1 }}>
                    <Card>
                        <CardHeader>
                            <strong>Relatórios</strong>
                        </CardHeader>
                        <CardBody>
                            <form ref={el => this.form = el}>
                                <Row>
                                    <Col xs="12">
                                        <FormGroup>
                                            <Label htmlFor="client">Cliente</Label>
                                            <Autocomplete id="client" field="name" ref={el => { this.client = el }} placeholder="Cliente" onSelectItem={this.onSelectClient.bind(this)} defaultList={this.state.clients} />
                                            <FormText color="muted">
                                                Comece a digitar e espere pelos resultados
                                            </FormText>
                                        </FormGroup>
                                    </Col>
                                </Row>
                                <Row>
                                    <Col xs="12" sm="6">
                                        <FormGroup>
                                            <Label htmlFor="group">Grupo</Label>
                                            <Input type="select" id="group" name="group" placeholder="Grupo" onChange={this.onSelectGroup.bind(this)} defaultValue="invalid" >
                                                <option value="invalid" disabled>Selecione</option>
                                                {this.state.groups.map(group => <option key={group.id} value={group.id}>{group.name}</option>)}
                                            </Input>
                                        </FormGroup>
                                    </Col>
                                    <Col xs="12" sm="6">
                                        <FormGroup>
                                            <Label htmlFor="category">Categoria</Label>
                                            <Input type="select" id="category" value={this.state.category.id || "invalid"} ref={el => { this.category = el }} onChange={this.onSelectCategory.bind(this)} name="category" placeholder="Categoria" defaultValue="invalid" >
                                                <option value="invalid" disabled>Selecione</option>
                                                {this.state.categories.map(category => <option key={category.id} value={category.id}>{category.name}</option>)}
                                            </Input>
                                        </FormGroup>
                                    </Col>
                                </Row>
                                <Row>
                                    <Col xs="12">
                                        <FormGroup>
                                            <Label htmlFor="equipment">Equipamento</Label>
                                            <Autocomplete ref={el => this.equipment = el} id="equipment" field="name" placeholder="Equipamento a ser ensaiado" onSelectItem={this.onSelectEquipment.bind(this)} defaultList={this.state.equipments} />
                                            <FormText color="muted">
                                                Comece a digitar e espere pelos resultados
                                        </FormText>
                                        </FormGroup>
                                    </Col>
                                </Row>
                                <Row>
                                    <Col xs="12">
                                        <FormGroup>
                                            <Label htmlFor="standard">Norma</Label>
                                            <InputGroup>
                                                <Input type="select" id="standard" name="standard" required onChange={(event) => this.onChangeStandard(event)}>
                                                    <option value="invalid">Selecione</option>
                                                    {this.state.standards.map(std => <option key={std.id} value={std.id}>{std.name}</option>)}
                                                </Input>
                                                <InputGroupButton onClick={this.onAddStandard.bind(this)}>Adicionar</InputGroupButton>
                                            </InputGroup>
                                        </FormGroup>
                                    </Col>
                                </Row>
                                <Row>
                                    <Col xs="12">
                                        <ListGroup>
                                            {
                                                this.state.selectedStds.map(item =>
                                                    <ListGroupItem key={item.id} style={{ height: 50 }}>
                                                        <p style={{ display: 'inline-block' }}>{item.name}</p>
                                                        <p style={{ cursor: 'pointer', verticalAlign: 'middle' }}
                                                            className="float-right" onClick={this.onRemoveStd.bind(this, item)}>
                                                            <i className="fa fa-times" aria-hidden="true"></i>
                                                        </p>
                                                    </ListGroupItem>
                                                )
                                            }
                                        </ListGroup>
                                    </Col>
                                </Row>
                                <br />
                                <Row>
                                    <Col xs="12">
                                        <FormGroup>
                                            <Label htmlFor="test-type">Tipo do ensaio</Label>
                                            <InputGroup>
                                                <Input type="select" id="test-type" name="test-type" required
                                                    value={this.state.type.length > 0 ? this.state.type : "invalid"} onChange={this.onSelectTest.bind(this)}>
                                                    <option value="invalid" disabled >Selecione</option>
                                                    {
                                                        this.state.types.map(item => <option key={item.id} value={item.id}>{item.name}</option>)
                                                    }
                                                </Input>
                                                <InputGroupButton onClick={this.onAddTest.bind(this)}>Adicionar</InputGroupButton>
                                            </InputGroup>
                                        </FormGroup>
                                    </Col>
                                </Row>
                                <Row>
                                    <Col xs="12">
                                        <ListGroup>
                                            {
                                                this.state.selectedTests.map((item) =>
                                                    <ListGroupItem key={item.id} style={{ height: 50 }}>
                                                        <p style={{ display: 'inline-block' }}>{item.name}</p>
                                                        <p style={{ cursor: 'pointer', verticalAlign: 'middle' }}
                                                            className="float-right" onClick={this.onRemoveTest.bind(this, item)}>
                                                            <i className="fa fa-times" aria-hidden="true"></i>
                                                        </p>
                                                    </ListGroupItem>
                                                )
                                            }
                                        </ListGroup>
                                    </Col>
                                </Row>
                                <br />
                                <Row>
                                    <Col xs="12" md="4">
                                        <FormGroup>
                                            <Label htmlFor="os">Número da OS</Label>
                                            <Input type="number" id="os_number" name="os_number" ref={el => { this.os = el }} onChange={this.onChangeInput.bind(this)} placeholder="12345" required />
                                        </FormGroup>
                                    </Col>
                                    <Col xs="12" sm="4">
                                        <FormGroup>
                                            <Label htmlFor="ura">URA</Label>
                                            <Input type="number" id="ura" name="ura" placeholder="3.5" required onChange={this.onChangeInput.bind(this)} />
                                        </FormGroup>
                                    </Col>
                                    <Col xs="12" sm="4">
                                        <FormGroup>
                                            <Label htmlFor="temperature">Tempreratura</Label>
                                            <Input type="number" id="temperature" name="temperature" placeholder="25º" required onChange={this.onChangeInput.bind(this)} />
                                        </FormGroup>
                                    </Col>
                                </Row>
                                <Row>
                                    <Col xs="12">
                                        <FormGroup>
                                            <Label htmlFor="responsables">Responsabilidade técnica</Label>
                                            <InputGroup>
                                                <Input type="select" id="responsables" name="responsables" required
                                                    defaultValue="invalid" onChange={this.onSelectResponsable.bind(this)}>
                                                    <option value="invalid" disabled>Selecione</option>
                                                    {this.state.users.map((user) => <option key={user.id} value={user.id}>{user.name}</option>)}
                                                </Input>
                                                <InputGroupButton onClick={this.onAddResponsable.bind(this)}>Adicionar</InputGroupButton>
                                            </InputGroup>
                                        </FormGroup>
                                        <Row>
                                            <Col xs="12">
                                                <ListGroup>
                                                    {this.state.selectedUsers.map((user) =>
                                                        <ListGroupItem key={user.id}>
                                                            <p style={{ display: 'inline-block' }}>{user.name} - {user.occupation}</p>
                                                            <p style={{ cursor: 'pointer', verticalAlign: 'middle' }}
                                                                className="float-right" onClick={this.onRemoveResponsable.bind(this, user)}>
                                                                <i className="fa fa-times" aria-hidden="true"></i>
                                                            </p>
                                                        </ListGroupItem>
                                                    )}
                                                </ListGroup>
                                            </Col>
                                        </Row>
                                    </Col>
                                </Row>
                                <br />
                            </form>
                            <Row>
                                <Col xs="12">
                                    <Button color="primary" size="lg" className="float-right" onClick={this.generate.bind(this)} >Gerar Relatório</Button>
                                </Col>
                            </Row>
                            <br />
                            <BootstrapTable version='4' data={this.state.consolidations} hover pagination options={options}>
                                <TableHeaderColumn dataField='id' isKey hidden searchable={false} >ID</TableHeaderColumn>
                                <TableHeaderColumn dataField='number' dataSort={true} >Número</TableHeaderColumn>
                                <TableHeaderColumn dataField='date' dataSort={true} sortFunc={this.sortByDate.bind(this)} >Data</TableHeaderColumn>
                                <TableHeaderColumn dataField='os_number' dataSort={true} width="100">Nº OS</TableHeaderColumn>
                                <TableHeaderColumn dataField='equipment' dataSort={true} sortFunc={this.sortByEquipment.bind(this)} dataFormat={this.equipmentFormatter}>Equipamento</TableHeaderColumn>
                                <TableHeaderColumn dataField="button" width="120" editable={false} dataFormat={this.buttonFormatter.bind(this)}></TableHeaderColumn>
                            </BootstrapTable>
                        </CardBody>
                    </Card>
                </Col>
            </Row>
        )
    }
}

export default Consolidation