import React, { Component } from 'react';

import {
    Row,
    Col,
    Button,
    Card,
    CardHeader,
    CardFooter,
    CardBody,
    CardTitle,
    Table,
    Pagination,
    PaginationItem,
    PaginationLink,
    Badge,
    FormGroup,
    Form,
    Input,
    Label
} from 'reactstrap';

import { DateTimePicker } from 'react-widgets';
import Globalize from 'globalize';
import globalizeLocalizer from 'react-widgets-globalize';
import { database } from '../../firebase';
import { BootstrapTable, TableHeaderColumn } from 'react-bootstrap-table';
import Moment from 'moment';
import * as pdf from '../Report/_report-pdf';
import * as reportsPdf from './_reports-pdf';
import { NotificationManager } from 'react-notifications';

var dateFormat = "DD/MM/YYYY";


function deleteReport(item) {
    if (confirm('Tem certeza que deseja deletar este laudo?')) {
        database.ref('reports/' + item.id).remove();
    }
}

class Reports extends Component {

    constructor(props) {
        super(props);

        Globalize.locale("pt");
        globalizeLocalizer();

        this.state = {
            allReports: [],
            reports: [],
            start_date: undefined,
            end_date: undefined,
            query: '',
            type: "invalid",
            selected: [],
            header: 'RELATÓRIO DE LAUDOS'
        }

        this.onRowSelect = this.onRowSelect.bind(this)
        this.onSelectAll = this.onSelectAll.bind(this)
    }

    componentWillMount() {
        database.ref('reports').on('value', snapshot => {
            var reports = []
            snapshot.forEach(childSnapshot => {
                var report = childSnapshot.val();
                report.id = childSnapshot.key;
                reports.push(report);
            });
            this.setState({
                reports,
                allReports: reports
            })
        })
    }


    buttonFormatter(cell, row) {
        return (
            <div>
                <Button onClick={() => pdf.loadImages(row)} style={{ marginRight: 12 }}><i className="fa fa-external-link" aria-hidden="true"></i></Button>
                <Button onClick={() => deleteReport(row)}><i className="fa fa-trash" aria-hidden="true"></i></Button>
            </div>
        );
    }

    clientFormatter(cell, row) {
        return (
            <div>{row && row.info && row.info.client && row.info.client.name || ""}</div>
        );
    }

    numberFormatter(cell, row) {
        return (
            <div>{row && row.info ? row.info.number : ""}</div>
        )
    }

    dateFormatter(cell, row) {
        return (
            <div>{row && row.info && row.info.test_date && Moment(row.info.test_date).format(dateFormat)}</div>
        )
    }

    expireFormatter(cell, row) {
        return (
            <div>{row && row.info && row.info.expire_date && Moment(row.info.expire_date).format(dateFormat)}</div>
        )
    }

    equipmentFormatter(cell, row) {
        return (
            <div>{cell && cell.name ? cell.name : ''}</div>
        )
    }

    resultFormatter(cell, row) {
        return (
            <Badge color={cell.result && cell.result.toLowerCase() == "aprovado" ? "success" : "danger"}>{cell.result || ""}</Badge>
        )
    }

    handleInputChange(event) {
        let name = event.target.name;
        let value = event.target.value;

        this.setState({
            [name]: value
        })
    }

    search() {
        var reports = this.state.allReports;
        let query = this.state.query;
        let type = this.state.type;
        var header = 'RELATÓRIO DE LAUDOS';

        if (query != null && query.length > 0 && type != "invalid") {
            switch (type) {
                case "number": {
                    reports = reports.filter(item => { return item.info ? item.info.number.includes(query) : false })
                    break;
                }
                case "serial": {
                    reports = reports.filter(item => {
                        var keys = Object.keys(item.tests);
                        var key = keys.filter(k => { return k.toUpperCase().includes("SÉRIE") || k.toUpperCase().includes("SERIE") })
                        if (key) {
                            var hasValue = false;
                            key.forEach(k => {
                                hasValue = item.tests && item.tests[k] ?
                                    item.tests[k]
                                        .replace(" ", "")
                                        .toUpperCase()
                                        .includes(query.replace(" ", "").toUpperCase()) || hasValue :
                                    false
                            })
                            return hasValue;
                        }
                        else return false
                    })
                    break;
                }
                case "plate": {
                    reports = reports.filter(item => {
                        var keys = Object.keys(item.tests);
                        var key = keys.find(k => { return k.toUpperCase().includes("PLACA") })
                        if (key) return item.tests && item.tests[key] ?
                            item.tests[key]
                                .replace(" ", "")
                                .toUpperCase()
                                .includes(query.replace(" ", "").toUpperCase()) :
                            false
                        else return false
                    })
                    break;
                }
                case 'dealership': {
                    reports = reports.filter(item => {
                        var keys = Object.keys(item.tests);
                        var key = keys.find(k => { return k.toUpperCase().includes("LIGHT") })
                        if (key) return item.tests && item.tests[key] ?
                            item.tests[key]
                                .replace(" ", "")
                                .toUpperCase()
                                .includes(query.replace(" ", "").toUpperCase()) : false
                        else return false
                    })
                    break;
                }
                case 'client': {
                    reports = reports.filter(item => {
                        return item.info && item.info.client && item.info.client.name ?
                            item.info.client.name.toUpperCase().includes(query.toUpperCase()) : false
                    })
                    break;
                }
            }
        }

        if (this.state.start_date && this.state.end_date) {
            var start = new Date(this.state.start_date + ' 00:00');
            var end = new Date(this.state.end_date + ' 00:00');

            reports = reports.filter(item => {
                var date = new Date(item.info['test_date'] + ' 00:00');
                return date.getTime() >= start.getTime() && date.getTime() <= end.getTime();
            })

            header = 'RELATÓRIO DE LAUDOS EMITIDOS ENTRE OS DIAS ' + Moment(start).format(dateFormat) + ' e ' + Moment(end).format(dateFormat)
        }

        if (this.state.start_expire_date && this.state.end_expire_date) {
            var today = new Date();
            var start = new Date(this.state.start_expire_date + ' 00:00');
            var end = new Date(this.state.end_expire_date + ' 00:00');
            reports = reports.filter(item => {
                var date = new Date(item.info['expire_date'] + ' 00:00');
                return date.getTime() >= start.getTime() && date.getTime() <= end.getTime();
            })

            header = 'RELATÓRIO DE LAUDOS COM VENCIMENTO ENTRE OS DIAS ' + Moment(start).format(dateFormat) + ' e ' + Moment(end).format(dateFormat)
        }

        this.setState({
            reports,
            header
        })
    }

    clearFilter() {
        this.form.reset();
        this.setState(prevState => ({
            reports: prevState.allReports,
            query: '',
            type: "invalid",
            start_date: undefined,
            end_date: undefined,
            start_expire_date: undefined,
            end_expire_date: undefined,
        }))
    }

    sortByCompany(a, b, order) {
        var first = a.info.client
        var second = b.info.client
        if (first && second) {
            if (order == 'desc') {
                if (first.name > second.name) return -1;
                else if (first.name < second.name) return 1;
                else return 0;
            } else {
                if (first.name > second.name) return 1;
                else if (first.name < second.name) return -1;
                else return 0;
            }
        }
    }

    sortByNumber(a, b, order) {
        var first = parseInt(a.info.number)
        var second = parseInt(b.info.number)
        if (first && second) {
            if (order == 'desc') {
                if (first > second) return -1;
                else if (first < second) return 1;
                else return 0;
            } else {
                if (first > second) return 1;
                else if (first < second) return -1;
                else return 0;
            }
        }
    }

    sortByDate(a, b, order) {
        var first = new Date(a.info.test_date)
        var second = new Date(b.info.test_date)
        if (first && second) {
            if (order == 'desc') {
                if (first.getTime() > second.getTime()) return -1;
                else if (first.getTime() < second.getTime()) return 1;
                else return 0;
            } else {
                if (first.getTime() > second.getTime()) return 1;
                else if (first.getTime() < second.getTime()) return -1;
                else return 0;
            }
        }
    }

    sortByExpire(a, b, order) {
        var first = new Date(a.info.expire_date)
        var second = new Date(b.info.expire_date)
        if (first && second) {
            if (order == 'desc') {
                if (first.getTime() > second.getTime()) return -1;
                else if (first.getTime() < second.getTime()) return 1;
                else return 0;
            } else {
                if (first.getTime() > second.getTime()) return 1;
                else if (first.getTime() < second.getTime()) return -1;
                else return 0;
            }
        }
    }

    sortByEquipment(a, b, order) {
        var first = a.equipment
        var second = b.equipment
        if (first && second) {
            if (order == 'desc') {
                if (first.name > second.name) return -1;
                else if (first.name < second.name) return 1;
                else return 0;
            } else {
                if (first.name > second.name) return 1;
                else if (first.name < second.name) return -1;
                else return 0;
            }
        }
    }

    sortByResult(a, b, order) {
        var first = a.tests
        var second = b.tests

        if (first && second) {
            if (order == 'desc') {
                if (first.result > second.result) return -1;
                else if (first.result < second.result) return 1;
                else return 0;
            } else {
                if (first.result > second.result) return 1;
                else if (first.result < second.result) return -1;
                else return 0;
            }
        }
    }

    onRowSelect(row, isSelected, e) {
        if (isSelected) {
            var selected = this.state.selected;
            selected.push(row);
        }
    }

    downaloadZip() {
        var files = [];
        NotificationManager.warning("Aguarde enquanto todos os PDFs selecionados são gerados.")
        this.state.selected.forEach(report => {
            pdf.loadImages(report, true,
                (blob, number) => {
                    files.push({ blob, number });
                    if (files.length == this.state.selected.length) {
                        pdf.zip(files);
                        return;
                    }
                }
            );
        });

    }

    onSelectAll(isSelected, rows) {
        if (isSelected) {
            return this.state.reports.map(row => {
                let selected = this.state.selected;
                selected.push(row)
                this.setState({
                    selected
                })
                return row.id
            });
        } else {
            return [];
        }
    }

    generatePdf() {
        reportsPdf.loadImages(this.state.reports, this.state.header)
    }

    render() {
        const selectRowProp = {
            mode: 'checkbox',
            bgColor: 'gray', // you should give a bgcolor, otherwise, you can't regonize which row has been selected
            clickToSelect: false,  // you should enable clickToSelect, otherwise, you can't select column.
            onSelect: this.onRowSelect,
            onSelectAll: this.onSelectAll
        };

        const options = {
            noDataText: 'Não existem dados para esta pesquisa',
        }

        return (
            <div>
                <Row>
                    <Col xs="12">
                        <Card>
                            <CardHeader>
                                <strong>Relatórios</strong>
                            </CardHeader>
                            <CardBody>
                                <form ref={el => this.form = el}>
                                    <Row>
                                        <Col xs="12" sm="4">
                                            <FormGroup>
                                                <Label htmlFor="type">Tipo</Label>
                                                <Input type="select" id="type" name="type" onChange={this.handleInputChange.bind(this)}>
                                                    <option value="invalid">Selecione</option>
                                                    <option value="number">Nº Laudo</option>
                                                    <option value="serial">Nº de Série Equipamento</option>
                                                    <option value="plate">Placa do veículo</option>
                                                    <option value="dealership">Código Concessionária</option>
                                                    <option value="client">Cliente</option>
                                                </Input>
                                            </FormGroup>
                                        </Col>
                                        <Col xs="12" sm="8">
                                            <FormGroup>
                                                <Label htmlFor="query">Número</Label>
                                                <Input type="text" id="query" name="query" onChange={this.handleInputChange.bind(this)} />
                                            </FormGroup>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col xs="12">
                                            <Button color="secondary" size="lg" onClick={this.clearFilter.bind(this)} ><i className="fa fa-close" aria-hidden="true"></i> Limpar</Button>
                                            <Button color="primary" size="lg" className="float-right" onClick={this.search.bind(this)} ><i className="fa fa-search" aria-hidden="true"></i> Pesquisar</Button>
                                        </Col>
                                    </Row>
                                    <br />
                                    <b>Data de ensaio</b>
                                    <Row>
                                        <Col xs="12" sm="6">
                                            <FormGroup>
                                                <Label htmlFor="start_date">Data inicial</Label>
                                                <Input type="date"
                                                    id="start-date"
                                                    name="start_date" onChange={this.handleInputChange.bind(this)} />
                                            </FormGroup>
                                        </Col>
                                        <Col xs="12" sm="6">
                                            <FormGroup>
                                                <Label htmlFor="end_date">Data final</Label>
                                                <Input type="date"
                                                    id="end-date"
                                                    name="end_date" onChange={this.handleInputChange.bind(this)} />
                                            </FormGroup>
                                        </Col>
                                    </Row>
                                    <b>Data de vencimento</b>
                                    <Row>
                                        <Col xs="12" sm="6">
                                            <FormGroup>
                                                <Label htmlFor="start_expire_date">Data inicial</Label>
                                                <Input type="date"
                                                    id="start-date"
                                                    name="start_expire_date" onChange={this.handleInputChange.bind(this)} />
                                            </FormGroup>
                                        </Col>
                                        <Col xs="12" sm="6">
                                            <FormGroup>
                                                <Label htmlFor="end_date">Data final</Label>
                                                <Input type="date"
                                                    id="end-date"
                                                    name="end_expire_date" onChange={this.handleInputChange.bind(this)} />
                                            </FormGroup>
                                        </Col>
                                    </Row>
                                </form>

                                <br />
                                <Row>
                                    <Col xs="12">
                                        <Button color="secondary" size="lg" onClick={this.generatePdf.bind(this)} ><i className="fa fa-external-link" aria-hidden="true"></i> Relatório</Button>
                                        <Button color="primary" size="lg" className="float-right" onClick={this.downaloadZip.bind(this)} >Gerar PDFs</Button>
                                    </Col>
                                </Row>
                                <br />
                                <BootstrapTable version='4' data={this.state.reports} hover pagination options={options} selectRow={selectRowProp}>
                                    <TableHeaderColumn dataField='id' isKey hidden searchable={false} >ID</TableHeaderColumn>
                                    <TableHeaderColumn dataField='info.client' dataSort={true} sortFunc={this.sortByCompany.bind(this)} dataFormat={this.clientFormatter}>Cliente</TableHeaderColumn>
                                    <TableHeaderColumn dataField='info.number' dataSort={true} sortFunc={this.sortByNumber.bind(this)} width="100" dataFormat={this.numberFormatter}>Nº Laudo</TableHeaderColumn>
                                    <TableHeaderColumn dataField='info.date' dataSort={true} sortFunc={this.sortByDate.bind(this)} width="100" dataFormat={this.dateFormatter}>Data</TableHeaderColumn>
                                    <TableHeaderColumn dataField='info.expire' dataSort={true} sortFunc={this.sortByExpire.bind(this)} width="100" dataFormat={this.expireFormatter}>Vencimento</TableHeaderColumn>
                                    <TableHeaderColumn dataField='equipment' dataSort={true} sortFunc={this.sortByEquipment.bind(this)} dataFormat={this.equipmentFormatter}>Equipamento</TableHeaderColumn>
                                    <TableHeaderColumn dataField='tests' dataSort={true} sortFunc={this.sortByResult.bind(this)} width="100" dataFormat={this.resultFormatter}>Resultado</TableHeaderColumn>
                                    <TableHeaderColumn dataField="button" width="120" editable={false} dataFormat={this.buttonFormatter}></TableHeaderColumn>
                                </BootstrapTable>
                            </CardBody>
                        </Card>
                    </Col>
                </Row>
            </div>
        );
    }
}

export default Reports;