import React, { Component } from 'react';
import Raven from 'raven-js';

import {
    Row,
    Col,
    Button,
    Modal,
    ModalBody,
    ModalFooter,
    ModalHeader,
    Progress,
    Card,
    CardHeader,
    CardFooter,
    CardBody,
    CardTitle,
    Table,
    Pagination,
    PaginationItem,
    PaginationLink,
    Badge,
    FormGroup,
    Form,
    Input,
    Label
} from 'reactstrap';

import Dropzone from 'react-dropzone';
import {NotificationManager} from 'react-notifications';
import firebase, { auth, database, storage } from '../../firebase';

class Settings extends Component {

    constructor() {
        super()
        this.state = { 
            files: [],
            dropzoneActive: false,
            user: {},
            document: {},
            modal: false,
            progress: 0,
            uploadRunning: false,
            isFinished: false
        }    

        this.toggle = this.toggle.bind(this);
    }

    componentWillMount() {
        database.ref()
            .on('value',  snapshot => {
                var user = snapshot.child('users').child(auth.currentUser.uid).val();
                var document = snapshot.child('document').val();
                if (document == null) document = {};
                this.setState({
                    user,
                    document,
                })
            });
        
    }

    toggle() {
        this.setState(prevState => {
            modal: !prevState.modal
        })
    }

    onChangeName(event) {
        let user = this.state.user;
        user.name = event.target.value;
        this.setState({
            user
        })
    }

    onChangeEmail(event) {
        let user = this.state.user;
        user.email = event.target.value;
        this.setState({
            user
        })
    }
    
    onChangeDocument(event) {
        let document = this.state.document;
        document.fixed = event.target.value;
        this.setState({
            document
        })
    }

    onChangePassword(event) {
        let user = this.state.user;
        user.password = event.target.value;
        this.setState({
            user
        })
    }

    onHandleSubmit() {
        if (auth.currentUser.displayName != this.state.user.name) {
            this.updateName();
        } else {
            this.updateEmail();
        }
    }

    updateName() {
        auth.currentUser.updateProfile({
            displayName: this.state.user.name
        }).then(() => {
            this.updateEmail()
        }).catch(error => {
            this.handleError(error.code);
        })
    }

    updateEmail() {
        if (auth.currentUser.email != this.state.user.email) {
            auth.currentUser.updateEmail(this.state.user.email)
                .then(() => {
                    this.updatePassword()
                })
                .catch(error => {
                    this.handleError(error.code);
                })
        } else {
            this.updatePassword();
        }
    }

    updatePassword() {
        if (this.state.user.password && this.state.user.password.length > 0) {
            auth.currentUser.updatePassword(this.state.user.password)
                .then(() => {
                    let user = this.state.user;
                    user.password = null;
                    this.setState({
                        user
                    })
                    this.updateDatabase()
                })
                .catch(error => {
                    this.handleError(error.code)
                })
        } else {
            this.updateDatabase();
        }
    }

    updateDatabase() {
        database.ref('users').child(auth.currentUser.uid).set(this.state.user)
            .then(() => {
                auth.currentUser.reload();
                if (this.state.document && this.state.document.fixed && this.state.document.fixed.length > 0) {
                    database.ref('document').set(this.state.document)
                        .then(() => {
                            NotificationManager.success('Dados atualizados com sucesso!');
                        });
                } else {
                    NotificationManager.success('Dados atualizados com sucesso!');
                }
            }).catch(error => {
                Raven.captureException(error)
                this.handleError(error.code)
            });
        
    }

    handleError(errorCode) {
        switch(errorCode) {
            case "auth/invalid-email":
                NotificationManager.error('Email inválido!');
                break;
            case "auth/email-already-in-use":
                NotificationManager.error('Este email já está sendo usado por outro usuário.');
                break;
            case "auth/requires-recent-login":
                this.setState({
                    modal: true
                })
                break;
            case "auth/weak-password":
                NotificationManager.error('A senha deve ter no mínimo 6 caracteres');
                break;
            default:
                NotificationManager.error('Ocorreu um erro ao atualizar as configurações. Tente novamente.');
                break;
        }
    }

    reauthenticate() {
        var user = this.state.user;
        var credential = firebase.auth.EmailAuthProvider.credential(
            auth.currentUser.email,
            user.password
        );
        
        auth.currentUser.reauthenticateWithCredential(credential)
            .then(() => {
                var user = this.state.user;
                user.password = null;
                this.setState({
                    user,
                    modal: false
                })
            }).catch(error => {
                this.handleError(error.code);
            });
    }

    render() {

        return (
            <div>
                <Row>
                    <Col xs="12" sm={{ size: 10, offset: 1 }}>
                        <Card>
                            <CardHeader>
                                Configurações
                            </CardHeader>
                            <CardBody>
                                <Row>
                                    <Col xs="12">
                                        <CardTitle>Perfil</CardTitle>
                                    </Col>
                                </Row>
                                <Row>
                                    <Col xs="12" sm="4">
                                        <FormGroup>
                                            <Label htmlFor="name">Nome</Label>
                                            <Input type="text" id="name" onChange={this.onChangeName.bind(this)} value={this.state.user.name} placeholder="Jhon Doe"/>
                                        </FormGroup>
                                    </Col>
                                    <Col xs="12" sm="4">
                                        <FormGroup>
                                            <Label htmlFor="email">Email</Label>
                                            <Input type="email" id="email" onChange={this.onChangeEmail.bind(this)} value={this.state.user.email} placeholder="jhon@doe.com"/>
                                        </FormGroup>
                                    </Col>
                                    <Col xs="12" sm="4">
                                        <FormGroup>
                                            <Label htmlFor="password">Senha</Label>
                                            <Input type="password" id="password" onChange={this.onChangePassword.bind(this)} value={this.state.user.password} placeholder="Para não alterar, deixe em branco"/>
                                        </FormGroup>
                                    </Col>
                                </Row>
                            </CardBody>
                            <CardFooter>
                                <Button color="primary" className="float-right" onClick={this.onHandleSubmit.bind(this)}>Salvar</Button>
                            </CardFooter>
                        </Card>
                    </Col>
                </Row>

                <Modal isOpen={this.state.modal} toggle={this.toggle} className={this.props.className}>
                    <ModalHeader toggle={this.toggle}>Necessário Reautenticação</ModalHeader>
                    <ModalBody>
                        <Row>
                            <Col xs="12" sm="6">
                                <FormGroup>
                                    <Label htmlFor="email-re">Email</Label>
                                    <Input type="text" id="email-re" disabled name="email-re" value={auth.currentUser.email} placeholder="jhon@doe.com" />
                                </FormGroup>
                            </Col>
                            <Col xs="12" sm="6">
                                <FormGroup>
                                    <Label htmlFor="password-re">Senha</Label>
                                    <Input type="password" id="password-re" name="password-re" placeholder="Senha" onChange={this.onChangePassword.bind(this)} />
                                </FormGroup>
                            </Col>
                        </Row>
                    </ModalBody>
                    <ModalFooter>
                        <Button color="primary" onClick={this.reauthenticate.bind(this)}>Reautenticar</Button>
                        <Button color="secondary" onClick={this.toggle}>Cancelar</Button>
                    </ModalFooter>
                </Modal>   
            </div>
        );
    }
}

export default Settings;