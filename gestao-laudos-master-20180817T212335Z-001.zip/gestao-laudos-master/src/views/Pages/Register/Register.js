import React, {Component} from 'react';
import {Container, Row, Col, Card, CardBody, CardFooter, Button, Input, FormFeedback, InputGroup, InputGroupAddon, FormGroup, Label } from 'reactstrap';
import { Redirect, Route } from 'react-router-dom';
import {NotificationManager} from 'react-notifications';
import {auth, database} from '../../../firebase.js';

const FormErrors = ({formErrors}) =>
<div className='formErrors'>
  {Object.keys(formErrors).map((fieldName, i) => {
    if(formErrors[fieldName].length > 0){
      return (
        <p key={i}>{formErrors[fieldName]}</p>
      )        
    } else {
      return '';
    }
  })}
</div>

class Register extends Component {

  constructor(props) {
    super(props);

    this.state = {
      isEmployee: true,
      name: '',
      email: '',
      password: '',
      confirmPassword: '',
      errors: {name: '', email: '', password: '', confirmPassword: '', type: '', code: ''},
      nameValid: false,
      emailValid: false,
      passwordValid: false,
      confirmPasswordValid: false,
      codeValid: true,
      typeValid: true,
      formValid: false,
      redirect: false
    }

  }

  onEmployeeChange(event) {
    if (event.target.checked) {
      this.setState({
        isEmployee: true
      }, () => (this.validateType()))
    }
  }

  onClientChange(event) {
    if(event.target.checked) {
      this.setState({
        isEmployee: false
      }, () => this.validateType())
    }
  }

  handleUserInput(event) {
    const name = event.target.name;
    const value = event.target.value;

    this.setState({
      [name]: value
    }, () => { this.validateField(name, value) })
  }

  validateType() {
    let fieldErrors = this.state.errors;
    let typeValid = this.state.isEmployee != null;
    fieldErrors.type = typeValid ? '' : 'Selecione o tipo de usuário';
    this.setState({
      errors: fieldErrors,
      typeValid
    }, this.validateForm())
  }

  validateField(fieldName, value) {
    let fieldValidationErrors = this.state.errors;
    let nameValid = this.state.nameValid;
    let emailValid = this.state.emailValid;
    let passwordValid = this.state.passwordValid;
    let confirmPasswordValid = this.state.confirmPasswordValid;
    let codeValid = this.state.codeValid;
  
    switch(fieldName) {
      case 'name':
        nameValid = value.length >= 3;
        fieldValidationErrors.name = nameValid ? '' : 'Nome deve ter no mínimo 3 caracteres';
        break;
      case 'email':
        emailValid = value.match(/^([\w.%+-]+)@([\w-]+\.)+([\w]{2,})$/i) ? true : false;
        fieldValidationErrors.email = emailValid ? '' : 'Email inválido';
        break;
      case 'password':
        passwordValid = value.length >= 6;
        fieldValidationErrors.password = passwordValid ? '': 'A senha deve ter no mínimo 6 caracteres';
        break;
      case 'confirmPassword':
        let pwd = this.password.props.value;
        confirmPasswordValid = value == pwd;
        fieldValidationErrors.confirmPassword = confirmPasswordValid ? '': 'As senhas não conferem';
        break;
      case 'code':
        codeValid = this.state.isEmployee == false && value.length > 0;
        fieldValidationErrors.code = codeValid ? '' : 'O código da empresa é obrigatório';
        break;
      default:
        break;
    }

    this.setState({errors: fieldValidationErrors,
                    nameValid,
                    emailValid: emailValid,
                    passwordValid: passwordValid,
                    confirmPasswordValid,
                    codeValid
                  }, this.validateForm);
  }

  validateForm() {
    this.setState({formValid: this.state.nameValid && this.state.emailValid && this.state.passwordValid && this.state.confirmPasswordValid && this.state.typeValid});
  }

  handleSubmit() {
    let email = this.state.email;
    let password = this.state.password;

    if(this.state.formValid) {
      auth.createUserWithEmailAndPassword(email, password)
        .then(result => {
          this.updateProfile();
          this.sendVerificationEmail();
          this.saveUser();
          this.setState({redirect: true})
        }).catch(error => {
          this.handleError(error.code)
        })
    }
  }

  saveUser() {
    let name = this.state.name;
    let email = this.state.email;
    let employee = this.state.isEmployee;
    let code = this.state.isEmployee == false ? this.state.code : undefined; 

    let user = {name, email, employee, code}
    database.ref('users/' + auth.currentUser.uid).set(user);
  }

  updateProfile() {
    auth.currentUser.updateProfile({
            displayName: this.state.name
          }).catch(error => {
            this.handleError(error.code)
          });
  }

  sendVerificationEmail() {
    auth.currentUser.sendEmailVerification()
      .then(function() {
        NotificationManager.info("Um email foi enviado para confirmação.")
       }, function(error) {
        this.handleError(error.code)
       });
  }

  handleError(errorCode) {
    var message = 'Ocorreu um erro ao registrar o usuário'
    switch(errorCode) {
      case 'auth/invalid-email':
        message = 'O email inserido é inválido.';
        break;
      case 'auth/email-already-in-use':
        message = 'Este email já está cadastrado no sistema.';
        break;
      case 'auth/weak-password':
        message = 'Senha muito fraca! A senha deve ter no mínimo 6 caracteres.';
        break;
    }

    NotificationManager.error(message, "Atenção!");
  }

  render() {
    var path = this.state.isEmployee ? '/' : '/client'
    return (
      <div className="app flex-row align-items-center">
        {
          (this.state.redirect === true) && 
            <Route render={(props) => (<Redirect to={{ pathname: path }} />)} />
        } 
        <Container>
          <Row className="justify-content-center">
            <Col md="6">
              <Card className="mx-4">
                <CardBody className="p-4">
                  <h1>Registrar</h1>
                  <p className="text-muted">Crie a sua conta</p>
                    <FormGroup>
                      <InputGroup className="mb-3">
                        <InputGroupAddon><i className="icon-user"></i></InputGroupAddon>
                        <Input type="text" style={{textTransform: 'capitalize'}} valid={this.state.nameValid} placeholder="Nome completo" value={this.state.name} name="name" onChange={this.handleUserInput.bind(this)}/>
                      </InputGroup>
                      <FormFeedback>{this.state.errors.name}</FormFeedback>
                    </FormGroup>
                    <FormGroup>
                      <InputGroup className="mb-3">
                        <InputGroupAddon>@</InputGroupAddon>
                        <Input type="email" style={{textTransform: 'none'}} placeholder="Email" name="email" valid={this.state.emailValid} value={this.state.email} onChange={this.handleUserInput.bind(this)}/>
                      </InputGroup>
                      <FormFeedback>{this.state.errors.email}</FormFeedback>
                    </FormGroup>
                    <FormGroup>
                      <InputGroup className="mb-3">
                        <InputGroupAddon><i className="icon-lock"></i></InputGroupAddon>
                        <Input type="password" placeholder="Senha"style={{textTransform: 'none'}} ref={c => {this.password = c}} valid={this.state.passwordValid} value={this.state.password} name="password" onChange={this.handleUserInput.bind(this)}/>
                      </InputGroup>
                      <FormFeedback>{this.state.errors.password}</FormFeedback>
                    </FormGroup>
                    <FormGroup>
                      <InputGroup className="mb-4">
                        <InputGroupAddon><i className="icon-lock"></i></InputGroupAddon>
                        <Input type="password" placeholder="Confirme a senha" style={{textTransform: 'none'}} valid={this.state.confirmPasswordValid} value={this.state.confirmPassword} name="confirmPassword" onChange={this.handleUserInput.bind(this)}/>
                      </InputGroup>
                      <FormFeedback>{this.state.errors.confirmPassword}</FormFeedback>
                    </FormGroup>
                    {
                      this.state.isEmployee == false &&
                      <FormGroup>
                        <InputGroup className="mb-5">
                          <InputGroupAddon><i className="icon-key"></i></InputGroupAddon>
                          <Input type="text" placeholder="Código da empresa" valid={this.state.codeValid} value={this.state.code} name="code" onChange={this.handleUserInput.bind(this)}/>
                        </InputGroup>
                        <FormFeedback>{this.state.errors.confirmPassword}</FormFeedback>
                      </FormGroup>
                    }
                    
                    <FormErrors formErrors={this.state.errors} />
                  <Button color="success" disabled={!this.state.formValid} block onClick={this.handleSubmit.bind(this)}>Criar conta</Button>
                </CardBody>
              </Card>
            </Col>
          </Row>
        </Container>
      </div>
    );
  }
}

export default Register;
