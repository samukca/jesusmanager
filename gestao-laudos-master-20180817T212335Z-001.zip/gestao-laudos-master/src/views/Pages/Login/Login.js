import React, {Component} from 'react';
import { Redirect, Route, Link } from 'react-router-dom';
import {Container, Row, Modal, FormGroup, Label, ModalHeader, ModalBody, ModalFooter, Col, CardGroup, Card, CardBody, Button, Input, InputGroup, InputGroupAddon} from 'reactstrap';
import { NotificationManager } from 'react-notifications';
import { auth, database } from '../../../firebase';

const FormErrors = ({formErrors}) =>
<div className='formErrors'>
  {Object.keys(formErrors).map((fieldName, i) => {
    if(formErrors[fieldName].length > 0){
      return (
        <p key={i}>{formErrors[fieldName]}</p>
      )        
    } else {
      return '';
    }
  })}
</div>

class Login extends Component {

  constructor(props) {
    super(props);

    this.state = {
      redirect: false,
      email: '',
      password: '',
      user: null,
      emailValid: false,
      passwordValid: false,
      errors: {email: '', password: '' },
      passwordModal: false,
      emailRecover: ''
    }

    this.toggleModal = this.toggleModal.bind(this);
  }

  toggleModal() {
    this.setState(prevState => ({
      passwordModal: !prevState.passwordModal
    }))
  }

  login() {
    auth.signInWithEmailAndPassword(this.state.email, this.state.password)
      .then(result => {
        database.ref('users').child(result.uid).once('value').then(r => {
          if (r.val() != null) {
            this.setState({
              user: result,
              redirect: true
            })
          } else {
            auth.signOut();
            NotificationManager.error("Usuário inválido.");
          }
        })
      })
      .catch(error => {
        this.handleError(error.code)
      })
  }

  onChangeEmail(event) {
    this.setState({
      email: event.target.value
    }, () => this.validateEmail())
  }

  onChangePassword(event) {
    this.setState({
      password: event.target.value
    }, () => this.validatePassword())
  }

  onChangeEmailRecover(event) {
    this.setState({
      emailRecover: event.target.value
    })
  }

  recoverPassword() {
    auth.sendPasswordResetEmail(this.state.emailRecover)
      .then(() => {
        NotificationManager.success("Um email foi enviado para resetar a senha. Por favor, verifique sua caixa de entrada.")
        this.setState(prevState => ({
          passwordModal: !prevState.passwordModal
        }))
      }).catch((error) => {
        this.handleError(error.code)
      })
  }

  validateEmail() {
    let errors = this.state.errors;

    let emailValid = this.state.email.match(/^([\w.%+-]+)@([\w-]+\.)+([\w]{2,})$/i) ? true : false;
    errors.email = emailValid ? '' : 'Email inválido';

    this.setState({
      emailValid,
      errors
    })
  }

  validatePassword() {
    let errors = this.state.errors;

    let passwordValid = this.state.password.length >= 0;
    errors.password = passwordValid ? '' : 'Digite a senha';

    this.setState({
      passwordValid,
      errors
    })
  }

  handleError(errorCode) {
    var message = 'Ocorreu um erro ao entrar no sistema.'
    switch(errorCode) {
      case 'auth/invalid-email':
        message = 'O email inserido é inválido.';
        break;
      case 'auth/user-disabled':
        message = 'O usuário deste email foi desabilitado.';
        break;
      case 'auth/user-not-found':
        message = 'Nenhum usuário foi encontrado para este email.';
        break;
      case 'auth/wrong-password':
        message = 'A senha digitada não é válida para este email.'
    }

    NotificationManager.error(message);
  }

  render() {
    const { from } = this.props.location.state || { from: { pathname: '/' } }

    return (
      <div className="app flex-row align-items-center">
        {
          (this.state.redirect === true) && 
            <Route render={(props) => (<Redirect to={from} />)} />
        } 
        <Container>
          <Row className="justify-content-center">
            <Col md="8">
              <CardGroup>
                <Card className="p-4">
                  <CardBody>
                    <h1>Login</h1>{this.state.from}
                    <p className="text-muted">Entre com a sua conta</p>
                    <InputGroup className="mb-3">
                      <InputGroupAddon><i className="icon-user"></i></InputGroupAddon>
                      <Input type="email" placeholder="Email" style={{textTransform: 'none'}} valid={this.state.emailValid} onChange={this.onChangeEmail.bind(this)}/>
                    </InputGroup>
                    <InputGroup className="mb-4">
                      <InputGroupAddon><i className="icon-lock"></i></InputGroupAddon>
                      <Input type="password" placeholder="Senha" style={{textTransform: 'none'}} valid={this.state.passwordValid} onChange={this.onChangePassword.bind(this)}/>
                    </InputGroup>
                    <FormErrors formErrors={this.state.errors} />
                    <Row>
                      <Col xs="6">
                        <Button color="primary" className="px-4" onClick={this.login.bind(this)}>Login</Button>
                      </Col>
                      <Col xs="6" className="text-right">
                        <Button color="link" className="px-0" onClick={this.toggleModal}>Esqueceu a senha?</Button>
                      </Col>
                    </Row>
                  </CardBody>
                </Card>
              </CardGroup>
            </Col>
          </Row>
        </Container>

        <Modal isOpen={this.state.passwordModal} toggle={this.toggleModal} className={this.props.className}>
          <ModalHeader toggle={this.toggleModal}>Recuperar senha</ModalHeader>
          <ModalBody>
            <Row>
              <Col xs="12">
                <FormGroup>
                  <Label htmlFor="email">Email</Label>
                  <Input type="text" id="email" name="email" placeholder="email@email.com" onChange={this.onChangeEmailRecover.bind(this)} />
                </FormGroup>
              </Col>
            </Row>
          </ModalBody>
          <ModalFooter>
            <Button color="primary" onClick={this.recoverPassword.bind(this)}>Recuperar</Button>
            <Button color="secondary" onClick={this.toggleModal}>Cancelar</Button>
          </ModalFooter>
        </Modal> 
      </div>
    );
  }
}

export default Login;
