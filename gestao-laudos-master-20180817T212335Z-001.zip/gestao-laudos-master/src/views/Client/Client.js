import React, { Component } from 'react';

import {
    Row,
    Col,
    Button,
    Card,
    CardHeader,
    CardFooter,
    CardBody,
    CardTitle,
    Table,
    Pagination,
    PaginationItem,
    PaginationLink,
    Badge,
    FormGroup,
    Form,
    Input,
    Label
} from 'reactstrap';

import { DateTimePicker } from 'react-widgets';
import Globalize from 'globalize';
import globalizeLocalizer from 'react-widgets-globalize';
import { auth, database } from '../../firebase';
import { BootstrapTable, TableHeaderColumn } from 'react-bootstrap-table';
import Moment from 'moment';
import * as pdf from '../Report/_report-pdf';
import * as clientPdf from './_client-pdf';

var dateFormat = "DD/MM/YYYY";

class Client extends Component {

    constructor(props) {
        super(props);

        Globalize.locale("pt");
        globalizeLocalizer();

        this.state = {
            allReports: [],
            reports: [],
            departments: [],
            start_date: undefined,
            end_date: undefined,
            query: '',
            type: "invalid",
            header: 'RELATÓRIO DE LAUDOS'
        }
    }

    componentWillMount() {
        auth.onAuthStateChanged(user => {
            if (user) {
                database.ref('users/' + auth.currentUser.uid).on('value', snapshot => {
                    let user = snapshot.val();
                    this.setState({
                        code: user.company
                    }, () => this.getReports())
                })
            }
        })

    }

    getReports() {
        database.ref('clients').child(this.state.code).on('value', snapshot => {
            var departments = snapshot.val().departments;
            if (departments) this.setState({ departments })
        })

        database.ref('reports').on('value', snapshot => {
            var reports = []
            snapshot.forEach(childSnapshot => {
                var report = childSnapshot.val();
                report.id = childSnapshot.key;
                if (report.info && report.info.client && report.info.client.id == this.state.code) {
                    reports.push(report);
                }
            });
            this.setState({
                reports,
                allReports: reports
            })
        })
    }

    buttonFormatter(cell, row) {
        return (
            <div>
                <Button onClick={() => pdf.loadImages(row)}><i className="fa fa-external-link" aria-hidden="true"></i></Button>
            </div>
        );
    }

    clientFormatter(cell, row) {
        return (
            <div>{row && row.info && row.info.client ? row.info.client.name : ""}</div>
        );
    }

    numberFormatter(cell, row) {
        return (
            <div>{row && row.info ? row.info.number : ""}</div>
        )
    }

    dateFormatter(cell, row) {
        return (
            <div>{row && row.info ? Moment(row.info.test_date).format(dateFormat) : ''}</div>
        )
    }

    expireFormatter(cell, row) {
        return (
            <div>{row && row.info ? Moment(row.info.expire_date).format(dateFormat) : ''}</div>
        )
    }

    equipmentFormatter(cell, row) {
        return (
            <div>{cell ? cell.name : ""}</div>
        )
    }

    resultFormatter(cell, row) {
        return (
            <Badge color={cell.result ? cell.result.toLowerCase() == "aprovado" ? "success" : "danger" : "warning"}>{cell.result || ""}</Badge>
        )
    }

    sortByCompany(a, b, order) {
        var first = a.info.client
        var second = b.info.client
        if (first && second) {
            if (order == 'desc') {
                if (first.name > second.name) return -1;
                else if (first.name < second.name) return 1;
                else return 0;
            } else {
                if (first.name > second.name) return 1;
                else if (first.name < second.name) return -1;
                else return 0;
            }
        }
    }

    sortByNumber(a, b, order) {
        var first = parseInt(a.info.number)
        var second = parseInt(b.info.number)
        if (first && second) {
            if (order == 'desc') {
                if (first > second) return -1;
                else if (first < second) return 1;
                else return 0;
            } else {
                if (first > second) return 1;
                else if (first < second) return -1;
                else return 0;
            }
        }
    }

    sortByDate(a, b, order) {
        var first = new Date(a.info.test_date)
        var second = new Date(b.info.test_date)
        if (first && second) {
            if (order == 'desc') {
                if (first.getTime() > second.getTime()) return -1;
                else if (first.getTime() < second.getTime()) return 1;
                else return 0;
            } else {
                if (first.getTime() > second.getTime()) return 1;
                else if (first.getTime() < second.getTime()) return -1;
                else return 0;
            }
        }
    }

    sortByExpire(a, b, order) {
        var first = new Date(a.info.expire_date)
        var second = new Date(b.info.expire_date)
        if (first && second) {
            if (order == 'desc') {
                if (first.getTime() > second.getTime()) return -1;
                else if (first.getTime() < second.getTime()) return 1;
                else return 0;
            } else {
                if (first.getTime() > second.getTime()) return 1;
                else if (first.getTime() < second.getTime()) return -1;
                else return 0;
            }
        }
    }

    sortByEquipment(a, b, order) {
        var first = a.equipment
        var second = b.equipment
        if (first && second) {
            if (order == 'desc') {
                if (first.name > second.name) return -1;
                else if (first.name < second.name) return 1;
                else return 0;
            } else {
                if (first.name > second.name) return 1;
                else if (first.name < second.name) return -1;
                else return 0;
            }
        }
    }

    sortByResult(a, b, order) {
        var first = a.tests
        var second = b.tests

        if (first && second) {
            if (order == 'desc') {
                if (first.result > second.result) return -1;
                else if (first.result < second.result) return 1;
                else return 0;
            } else {
                if (first.result > second.result) return 1;
                else if (first.result < second.result) return -1;
                else return 0;
            }
        }
    }

    handleInputChange(event) {
        let name = event.target.name;
        let value = event.target.value;

        this.setState({
            [name]: value
        })
    }

    search() {
        var reports = this.state.allReports;
        let department = this.state.department;
        let query = this.state.query;
        let type = this.state.type;
        var header = 'RELATÓRIO DE LAUDOS';

        if (department) {
            reports = reports.filter(item => {
                return item.info.client && item.info.client.departments && item.info.client.departments[item.info.department] ?
                    item.info.client.departments[item.info.department].name == department : false
            })
        }

        if (query != null && query.length > 0 && type != "invalid") {
            switch (type) {
                case "number": {
                    reports = reports.filter(item => { return item.info && item.info.number ? item.info.number.includes(query) : false })
                    break;
                }
                case "serial": {
                    reports = reports.filter(item => {
                        var keys = Object.keys(item.tests);
                        var key = keys.filter(k => { return k.toUpperCase().includes("SÉRIE") || k.toUpperCase().includes("SERIE") })
                        if (key) {
                            var hasValue = false;
                            key.forEach(k => {
                                hasValue = item.tests && item.tests[k] ?
                                    item.tests[k]
                                        .replace(" ", "")
                                        .toUpperCase()
                                        .includes(query.replace(" ", "").toUpperCase()) || hasValue :
                                    false
                            })
                            return hasValue;
                        }
                        else return false
                    })
                    break;
                }
                case "plate": {
                    reports = reports.filter(item => {
                        var keys = Object.keys(item.tests);
                        var key = keys.find(k => { return k.toUpperCase().includes("PLACA") })
                        if (key) return item.tests && item.tests[key] ?
                            item.tests[key]
                                .replace(" ", "")
                                .toUpperCase()
                                .includes(query.replace(" ", "").toUpperCase()) :
                            false
                        else return false
                    })
                    break;
                }
                case 'dealership': {
                    reports = reports.filter(item => {
                        var keys = Object.keys(item.tests);
                        var key = keys.find(k => { return k.toUpperCase().includes("LIGHT") })
                        if (key) return item.tests && item.tests[key] ?
                            item.tests[key]
                                .replace(" ", "")
                                .toUpperCase()
                                .includes(query.replace(" ", "").toUpperCase()) : false
                        else return false
                    })
                    break;
                }
            }
        }

        if (this.state.start_expire_date && this.state.end_expire_date) {
            var start = new Date(this.state.start_expire_date + ' 00:00');
            var end = new Date(this.state.end_expire_date + ' 00:00');
            reports = reports.filter(item => {
                var date = new Date(item.info['expire_date'] + ' 00:00');
                return date.getTime() >= start.getTime() && date.getTime() <= end.getTime();
            })

            header = 'RELATÓRIO DE LAUDOS COM VENCIMENTO ENTRE OS DIAS ' + Moment(start).format(dateFormat) + ' e ' + Moment(end).format(dateFormat)
        }

        this.setState({
            reports,
            header
        })
    }

    generatePdf() {
        clientPdf.loadImages(this.state.reports.sort((a, b) => { return b.info.os_number - a.info.os_number }), this.state.header);
    }

    clearFilter() {
        this.form.reset();
        this.setState(prevState => ({
            reports: prevState.allReports,
            start_date: undefined,
            end_date: undefined,
            query: '',
            type: "invalid"
        }))
    }

    render() {
        const selectRowProp = {
            mode: 'checkbox',
            bgColor: 'gray', // you should give a bgcolor, otherwise, you can't regonize which row has been selected
            hideSelectColumn: true,  // enable hide selection column.
            clickToSelect: true  // you should enable clickToSelect, otherwise, you can't select column.
        };

        const options = {
            noDataText: 'Não existem dados para esta pesquisa',
        }

        return (
            <div>
                <Row>
                    <Col xs="12">
                        <Card>
                            <CardHeader>
                                <strong>Laudos</strong>
                            </CardHeader>
                            <CardBody>
                                <form ref={el => this.form = el}>
                                    {this.state.departments.length > 0 &&
                                        <Row>
                                            <Col xs="12">
                                                <FormGroup>
                                                    <Label htmlFor="department">Departamento</Label>
                                                    <Input type="select" id="department" name="department" onChange={this.handleInputChange.bind(this)}>
                                                        <option value="invalid">Selecione</option>
                                                        {
                                                            this.state.departments.map((depto, i) =>
                                                                <option key={i} value={depto.name}>{depto.name}</option>
                                                            )

                                                        }
                                                    </Input>
                                                </FormGroup>
                                            </Col>
                                        </Row>
                                    }

                                    <Row>
                                        <Col xs="12" sm="4">
                                            <FormGroup>
                                                <Label htmlFor="type">Tipo</Label>
                                                <Input type="select" id="type" name="type" onChange={this.handleInputChange.bind(this)}>
                                                    <option value="invalid">Selecione</option>
                                                    <option value="number">Nº Laudo</option>
                                                    <option value="serial">Nº de Série Equipamento</option>
                                                    <option value="plate">Placa do veículo</option>
                                                    <option value="dealership">Código Concessionária</option>
                                                </Input>
                                            </FormGroup>
                                        </Col>
                                        <Col xs="12" sm="8">
                                            <FormGroup>
                                                <Label htmlFor="query">Número</Label>
                                                <Input type="text" id="query" name="query" onChange={this.handleInputChange.bind(this)} />
                                            </FormGroup>
                                        </Col>
                                    </Row>
                                    <Row>
                                        <Col xs="12">
                                            <Button color="secondary" size="lg" onClick={this.clearFilter.bind(this)} ><i className="fa fa-close" aria-hidden="true"></i> Limpar</Button>
                                            <Button color="primary" size="lg" className="float-right" onClick={this.search.bind(this)} ><i className="fa fa-search" aria-hidden="true"></i> Pesquisar</Button>
                                        </Col>
                                    </Row>
                                    <br />
                                    <b>Data de vencimento</b>
                                    <Row>
                                        <Col xs="12" sm="6">
                                            <FormGroup>
                                                <Label htmlFor="start_expire_date">Data inicial</Label>
                                                <Input type="date"
                                                    id="start-date"
                                                    name="start_expire_date" onChange={this.handleInputChange.bind(this)} />
                                            </FormGroup>
                                        </Col>
                                        <Col xs="12" sm="6">
                                            <FormGroup>
                                                <Label htmlFor="end_date">Data final</Label>
                                                <Input type="date"
                                                    id="end-date"
                                                    name="end_expire_date" onChange={this.handleInputChange.bind(this)} />
                                            </FormGroup>
                                        </Col>
                                    </Row>
                                </form>
                                <Row>
                                    <Col xs="12">
                                        <Button color="primary" size="lg" className="float-right" onClick={this.generatePdf.bind(this)} ><i className="fa fa-external-link" aria-hidden="true"></i> Relatório</Button>
                                    </Col>
                                </Row>
                                <br />
                                <BootstrapTable version='4' data={this.state.reports} hover pagination options={options}>
                                    <TableHeaderColumn dataField='id' isKey hidden searchable={false} >ID</TableHeaderColumn>
                                    <TableHeaderColumn dataField='info.client' dataSort={true} sortFunc={this.sortByCompany} dataFormat={this.clientFormatter}>Cliente</TableHeaderColumn>
                                    <TableHeaderColumn dataField='info.number' dataSort={true} width="100" sortFunc={this.sortByNumber} dataFormat={this.numberFormatter}>Nº Laudo</TableHeaderColumn>
                                    <TableHeaderColumn dataField='info.date' dataSort={true} width="100" sortFunc={this.sortByDate} dataFormat={this.dateFormatter}>Data</TableHeaderColumn>
                                    <TableHeaderColumn dataField='info.expire' dataSort={true} width="100" sortFunc={this.sortByExpire} dataFormat={this.expireFormatter}>Vencimento</TableHeaderColumn>
                                    <TableHeaderColumn dataField='equipment' dataSort={true} sortFunc={this.sortByEquipment} dataFormat={this.equipmentFormatter}>Equipamento</TableHeaderColumn>
                                    <TableHeaderColumn dataField='tests' dataSort={true} width="90" sortFunc={this.sortByResult} dataFormat={this.resultFormatter}>Resultado</TableHeaderColumn>
                                    <TableHeaderColumn dataField="button" dataSort={true} width="60" editable={false} dataFormat={this.buttonFormatter}></TableHeaderColumn>
                                </BootstrapTable>
                            </CardBody>
                        </Card>
                    </Col>
                </Row>
            </div>
        );
    }
}

export default Client;