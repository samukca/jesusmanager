import jsPDF from 'jspdf';
import logo from '../../../public/img/logo.jpg';
import Moment from 'moment';
import { NotificationManager } from 'react-notifications';
import Raven from 'raven-js';
import FileSaver from 'file-saver';
import JSZip from 'jszip';

var logoBase64 = '';
var creaImg = '';
var signatureImg = '';

var dateFormat = "DD/MM/YYYY";
var footer = "Este documento foi emitido a partir do sistema de gestão da empresa 08.618.923/0001-13 e sua veracidade poderá ser consultada no site https://laudostecnicosee.com.br/"

export function loadImages(reports, header) {
  var creaImage = "https://firebasestorage.googleapis.com/v0/b/gestao-laudos.appspot.com/o/users%2FCREA-RJ.jpg?alt=media&token=bba228a6-a620-46c1-97a8-199060dff749";
  var signature = "https://firebasestorage.googleapis.com/v0/b/gestao-laudos.appspot.com/o/users%2F1522227840348_ASSINATURA%20MARCOS.jpg?alt=media&token=ac983f13-f9ce-4058-a20c-476a3969d155";

  imgToBase64(logo)
    .then(base64 => {
      logoBase64 = base64;
      return imgToBase64(signature);
    })
    .then(base64 => {
      signatureImg = base64;
      return imgToBase64(creaImage);
    })
    .then(base64 => {
      creaImg = base64;
      savePdf(reports, header);
    })
    .catch(error => {
      Raven.captureException(error);
      console.log(error);
      NotificationManager.error('Aconteceu um erro ao gerar o PDF, tente novamente');
    })
}

export function savePdf(reports, header) {
  var doc = new jsPDF('p', 'mm', 'a4', true);

  var lineColumns = ["ITEM", "Nº OS", "Nº LAUDO", "DATA", "VALIDADE", "EQUIPAMENTO", "RESULTADO"]

  var i, j, idx, temparray, chunk = 25;
  for (i = 0, j = reports.length, idx = 0; i < j; i += chunk) {
    if (i != 0) {
      doc.setFontSize(7);
      doc.text(footer, 12, 290);
      doc.addPage();
    }
    temparray = reports.slice(i, i + chunk);
    // header
    var headerColumns = ["LAUDO TÉCNICO"];
    var headerRows = [["MSSR - Tecnologia em serviços de manuntenção de equipamentos elétricos Ltda."], ["CNPJ: 08.618.923/0001-13 - CREA/RJ 2016200583"], ["RUA CARACAS, 269 - BENTO RIBEIRO - RIO DE JANEIRO"], ["CEP: 21.331-740 - TELEFONE: (21) 2464-8772"]];

    doc.autoTable(headerColumns, headerRows, {
      theme: 'grid',
      margin: { left: 60 },
      styles: { overflow: 'linebreak', cellPadding: 0.2, lineWidth: 0 },
      headerStyles: { fontSize: 8, halign: 'center', fillColor: false, textColor: 80 },
      bodyStyles: { fontSize: 7, halign: 'center' },
      addPageContent: () => {
        doc.addImage(logoBase64, 'JPEG', 15, 10, 20, 20, undefined, 'FAST')
      }
    });

    var next = doc.autoTable.previous;

    var columns = ["", ""]
    var line = (reports[0] && reports[0].info && reports[0].info.client) ?
      [reports[0].info.client.name, "CNPJ " + reports[0].info.client.cnpj] : []

    var clientRows = [line];

    doc.autoTable(columns, clientRows, {
      styles: { overflow: 'linebreak', fontSize: 8, cellPadding: 1, fillColor: false, textColor: 80, fontStyle: 'bold' },
      theme: 'grid',
      showHeader: 'never',
      startY: next.finalY + 5
    })

    next = doc.autoTable.previous;

    var lines = [];
    temparray.forEach((r, i) => {
      var line = [];
      line.push(idx + 1);
      line.push(r.info ? r.info.os_number : '');
      line.push(r.info ? r.info.number : '');
      line.push(r.info ? Moment(r.info.test_date).format(dateFormat) : '');
      line.push(r.info ? Moment(r.info.expire_date).format(dateFormat) : '');
      line.push(r.equipment && r.equipment.name ? r.equipment.name.toUpperCase() : '');
      line.push(r.tests ? r.tests.result : '');
      lines.push(line);
      idx++;
    })

    doc.autoTable(lineColumns, lines, {
      styles: { overflow: 'linebreak', fontSize: 8, cellPadding: 1, fillColor: false, textColor: 80 },
      headerStyles: { lineWidth: 0.1 },
      theme: 'grid',
      startY: next.finalY + 7,
      addPageContent: (data) => {
        if (header) {
          doc.rect(data.settings.margin.left, next.finalY, data.table.width, 7, 'S');
          doc.setFontStyle('bold');
          doc.text(header, data.settings.margin.left + 1, next.finalY + 4.5);
        }
      }
    });

    var seventh = doc.autoTable.previous;

    //Responsables
    var testsColumns = [
      "",
      "CARGO",
      "NOME",
      "CREA-RJ",
    ]
    var testsRows = [];


    (reports[0].results.responsables || []).map(responsable => {
      let line = [""]
      line.push(responsable.occupation.toUpperCase());
      line.push(responsable.name.toUpperCase());
      line.push(responsable.register.toUpperCase());
      testsRows.push(line);
    })

    doc.autoTable(testsColumns, testsRows, {
      styles: { overflow: 'linebreak', fontSize: 8, cellPadding: 1, fillColor: false, textColor: 80 },
      headerStyles: { lineWidth: 0.1 },
      columnStyles: {
        0: { columnWidth: 19 }
      },
      theme: 'grid',
      showHeader: 'firstPage',
      startY: seventh.finalY,
      createdCell: function (cell, opts) {
        var padding = 0.5;
        switch (reports[0].results.responsables.length) {
          case 1:
            padding = 7;
            break;
          case 2:
            padding = 3;
            break;
          case 3:
            padding = 1;
            break;
          case 4:
            padding = 0.6;
            break;
          case 5:
            padding = 0.2;
            break;
        }
        cell.styles.cellPadding = { vertical: padding };
      },
      drawCell: (cell, data) => {
        // Rowspan
        if (data.column.dataKey === 0) {
          if (data.row.index === 0) {
            doc.rect(cell.x, cell.y, data.table.width, cell.height * reports[0].results.responsables.length, 'S');
            doc.addImage(creaImg, 'JPEG', cell.x + 2, cell.y + 2, 15, 15, undefined, 'FAST');
          }
          return false;
        }
      },
    });

    let eightth = doc.autoTable.previous;

    //Responsables
    var signatureColumns = [
      "DATA",
      ""
    ]
    var signatureRows = [
      [Moment(new Date()).format(dateFormat), ""]
    ]
    doc.autoTable(signatureColumns, signatureRows, {
      styles: {
        overflow: 'linebreak', fontSize: 12, cellPadding: 5,
        fillColor: false, textColor: 80,
      },
      headerStyles: { lineWidth: 0.1 },
      columnStyles: {
        0: { columnWidth: 35 }
      },
      showHeader: 'never',
      theme: 'grid',
      startY: eightth.finalY,
      createdCell: function (cell, opts) {
        cell.styles.cellPadding = { vertical: 10 };
      },
      drawCell: (cell, data) => {
        // Rowspan
        if (data.column.dataKey === 1) {
          if (data.row.index === 0) {
            doc.rect(cell.x, cell.y, cell.width, cell.height, 'S');
            doc.addImage(signatureImg, 'JPEG', cell.x + 50, cell.y + 2, 50, 20, undefined, 'FAST');
          }
          return false;
        }
      }
    });
  }

  var blob = doc.output("blob");
  if (window.navigator && window.navigator.msSaveOrOpenBlob) {
    window.navigator.msSaveOrOpenBlob(blob);
    return;
  }

  window.open(URL.createObjectURL(blob));
  // FileSaver.saveAs(blob, reports[0].info.client.name + ".pdf")
  // doc.save("LD " + report.info.number + " " + report.equipment.name + ".pdf")
}

export function zip(files) {
  var zip = new JSZip();
  for (var i = 0; i < files.length; i++) {
    zip.file("LD" + i + ".pdf", files[i])
  }
  zip.generateAsync({ type: "blob" })
    .then(content => {
      FileSaver.saveAs(content, "laudos.zip");
    })
}

function imgToBase64(url) {
  if (!window.FileReader) {
    return;
  }
  return new Promise(function (resolve, reject) {
    var xhr = new XMLHttpRequest();
    xhr.responseType = 'blob';
    xhr.open('GET', url, true);
    xhr.withCredentials = false;
    xhr.onload = function () {
      var reader = new FileReader();
      reader.onloadend = function () {
        resolve(reader.result.replace('text/xml', 'image/jpeg'));
      };
      reader.onerror = function () {
        reject({
          status: this.status,
          statusText: xhr.statusText
        })
      }
      reader.readAsDataURL(xhr.response);
    };
    xhr.send();
  })
}