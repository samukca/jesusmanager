import React, { Component } from 'react';
import {
  Row,
  Col,
  Button,
  ButtonDropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
  Card,
  CardHeader,
  CardFooter,
  CardBody,
  Form,
  FormGroup,
  FormText,
  Label,
  Input,
  InputGroup,
  InputGroupAddon,
  InputGroupButton,
  ListGroup,
  ListGroupItem
} from 'reactstrap';
import { database } from '../../firebase';
import Autocomplete from '../../components/Autocomplete/Autocomplete'

class ReportTests extends Component {

  constructor(props) {
    super(props)

    this.state = {
      category: {},
      instruments: [],
      selected: {},
      selectedInstrument: {},
      selectedInstruments: [],
      standards: [],
      types: [],
      tests: {},
      test_variables: {},
      groups: [],
      categories: [],
      inputs: [],
      equipment: {},
      equips: [],
      selectedTest: {},
      selectedTests: [],
      type: '',
      selectedStds: [],
      standard: {},
      fields: []
    }

  }

  componentWillMount() {
    var instruments = [];
    database.ref('tools').on('value', snapshot => {
      snapshot.forEach(childSnapshot => {
        var tool = childSnapshot.val();
        tool.id = childSnapshot.key;

        instruments.push(tool);
      });
      instruments.sort((a, b) => { return (a.name > b.name) ? 1 : ((b.name > a.name) ? -1 : 0) })

      this.setState({
        instruments
      })
    });

    var standards = [];
    database.ref('standards').on('value', snapshot => {
      snapshot.forEach(childSnapshot => {
        var standard = {};
        standard.name = childSnapshot.val();
        standard.id = childSnapshot.key;
        standards.push(standard);
      });

      standards.sort((a, b) => { return (a.name > b.name) ? 1 : ((b.name > a.name) ? -1 : 0) })

      this.setState({
        standards
      });
    });

    var types = [];
    database.ref('tests').on('value', snapshot => {
      snapshot.forEach(childSnapshot => {
        var type = {};
        type.name = childSnapshot.val();
        type.id = childSnapshot.key;

        types.push(type);
      });
      types.sort((a, b) => { return (a.name > b.name) ? 1 : ((b.name > a.name) ? -1 : 0) })

      this.updateGroups()

      this.setState({
        types
      })
    })
  }

  updateGroups() {
    database.ref('groups')
      .once('value', (snapshot) => {
        var groups = []
        snapshot.forEach(child => {
          var id = child.key;
          var group = child.val();
          group.id = id;
          groups.push(group)
        })
        groups.sort((a, b) => { return (a.name > b.name) ? 1 : ((b.name > a.name) ? -1 : 0) })

        this.setState({
          groups
        })
      });
  }

  onSelectGroup(event) {
    let selectedGroupId = event.target.value;
    this.setState({
      categories: [],
      inputs: [],
      equips: [],
      equipment: {},
      category: {},
      selectedGroup: selectedGroupId
    }, () => this.getCategories())
  }

  getCategories() {
    database.ref('groups').child(this.state.selectedGroup).child('categories')
      .once('value', (snapshot) => {
        var categories = []
        snapshot.forEach(child => {
          var id = child.key;
          var category = child.val();
          category.id = id;
          categories.push(category)
        })
        categories.sort((a, b) => { return (a.name > b.name) ? 1 : ((b.name > a.name) ? -1 : 0) })

        this.setState({
          categories
        })
      })
  }

  onSelectCategory(event) {
    let selected = this.state.categories.find(cat => cat.id == event.target.value);
    var tests = {};
    if (Object.keys(this.state.tests).length > 0) {
      var result = this.state.tests.result;
      var look = this.state.tests.look;
      tests = { result, look }

      Object.keys(this.state.tests).forEach(k => {
        var input = (selected.fields || []).find(i => i.name == k);
        var field = (this.state.inputs || []).find(f => f.field == k);
        console.log(k, input, field)
        if (input || field) tests[k] = this.state.tests[k]
      })
    }

    this.setState({
      category: selected,
      inputs: selected.fields || [],
      equips: [],
      equipment: {},
      tests: tests
    }, () => { this.getEquipments(); this.props.onChange(this.state.tests) })

  }

  getEquipments() {

    database.ref('equipments').on('value', snapshot => {
      var equipments = [];
      snapshot.forEach(childSnapshot => {
        var equip = childSnapshot.val();
        equip.id = childSnapshot.key;
        if (equip.category == this.state.category.id) equipments.push(equip);
      })
      equipments.sort((a, b) => { return (a.name > b.name) ? 1 : ((b.name > a.name) ? -1 : 0) })

      this.setState({
        equips: equipments
      });
    });
  }

  onSelectInstrument(event, group) {
    var selectedInstrument = this.state.selectedInstrument;
    let found = this.state.instruments.find((item) => { return item.id == event.target.value })
    group ? selectedInstrument[group] = found : selectedInstrument = found;
    var selected = this.state.selected;
    group ? selected[group] = event.target.value.toUpperCase() : selected = event.target.value.toUpperCase();
    this.setState({
      selected,
      selectedInstrument
    })
  }

  onSelectTest(event) {
    var selectedTest = this.state.selectedTest;
    let found = {};
    this.state.types.forEach(type => {
      if (type.id == event.target.value) found = type;
    });
    selectedTest = found;
    var type = event.target.value;

    this.setState({
      type,
      selectedTest
    })
  }

  onAddInstrument() {
    var selectedInstruments = [...this.state.selectedInstruments, this.state.selectedInstrument];
    var fields = this.state.fields
    selectedInstruments.forEach(i => {
      if (i.fields) {
        i.fields.forEach(f => {
          fields.push(f)
        })
      }
    })

    fields = fields.filter((thing, index, self) =>
      index === self.findIndex((t) => (
        t.field === thing.field && t.type === thing.type
      ))
    )

    this.setState(prevState => ({
      fields,
      selectedInstruments
    }), () => this.props.onChangeInstruments(this.state.selectedInstruments))
  }

  onAddTest() {
    var selectedTests = [...this.state.selectedTests, this.state.selectedTest];

    this.setState({
      selectedTests
    }, () => this.props.onChangeTests(this.state.selectedTests))
  }

  onRemoveInstrument(item, group) {
    var selectedInstruments = this.state.selectedInstruments;
    group && (typeof group) == "string" ? selectedInstruments[group] = this.state.selectedInstruments[group].filter(function (val) { return val.id !== item.id })
      : selectedInstruments = this.state.selectedInstruments.filter(function (val) { return val.id !== item.id })

    var fields = []
    selectedInstruments.forEach(i => {
      if (i.fields) {
        i.fields.forEach(f => {
          fields.push(f)
        })
      }
    })

    fields = fields.filter((thing, index, self) =>
      index === self.findIndex((t) => (
        t.field === thing.field && t.type === thing.type
      ))
    )
    this.setState(prevState => ({
      selectedInstruments,
      fields
    }), () => this.props.onChangeInstruments(this.state.selectedInstruments))
  }

  onRemoveTest(item) {
    var selectedTests = this.state.selectedTests.filter(val => { return val.id != item.id });

    this.setState({
      selectedTests
    }, () => this.props.onChangeTests(this.state.selectedTests))
  }

  onRemoveStd(item) {
    var selectedStds = this.state.selectedStds.filter(val => { return val.id != item.id });
    let test_variables = this.state.test_variables;

    test_variables.standard = selectedStds.map((item) => item.name).join(' / ')

    this.setState({
      selectedStds,
      test_variables
    }, this.props.onChangeVariables(this.state.test_variables))
  }

  onChange(event) {
    var name = event.target.name;
    var value = event.target.value.toUpperCase();

    let test_variables = this.state.test_variables;
    test_variables[name] = value
    this.setState({
      test_variables
    }, () => this.props.onChangeVariables(this.state.test_variables))
  }

  onChangeStandard(event) {
    let selected = this.state.standards.find(cat => cat.id == event.target.value);

    this.setState({
      standard: selected
    })
  }

  onAddStandard() {
    let std = this.state.standard;
    let selectedStds = this.state.selectedStds;
    let test_variables = this.state.test_variables;

    selectedStds.push(std);
    test_variables.standard = selectedStds.map((item) => item.name).join(' / ')

    this.setState({
      selectedStds,
      test_variables,
      standard: {}
    }, () => this.props.onChangeVariables(this.state.test_variables))
  }

  onChangeInput(event) {
    var name = event.target.name;
    var value = event.target.value.toUpperCase();

    let tests = this.state.tests;
    tests[name] = value;

    this.setState({
      tests
    }, () => this.props.onChange(this.state.tests))
  }

  onSelectEquipment(item) {
    let equipment = this.state.equipment;
    equipment = item;
    if (equipment) {
      equipment.isGroup = this.state.category.isGroup

      this.setState({
        equipment,
      }, () => this.props.onChangeEquipment(equipment))
    }
  }

  onInputChange(event, input) {
    let name = event.target.name;
    let value = event.target.value.toUpperCase();
    let equipment = this.state.equipment;
    let tests = this.state.tests;

    if (equipment.isGroup && input.differGroup || !equipment.isGroup) tests[name] = value;
    else equipment[name] = value;

    this.setState({
      tests,
      equipment
    }, () => this.props.onChange(this.state.tests) && this.props.onChangeEquipment(this.state.equipment))
  }

  onInputGroupChange(event, group) {
    let name = event.target.name;
    let value = event.target.value.toUpperCase();
    let equipment = this.state.equipment;
    let tests = this.state.tests;

    if (tests.groups == undefined) tests.groups = [];
    var g = {};
    let found = undefined;
    tests.groups.map(item => { if (item.name == group) found = item })
    if (found != undefined) g = found;
    else g.name = group;

    g[name] = value;

    if (found == undefined) tests.groups.push(g)
    this.setState({
      tests
    }, () => this.props.onChange(this.state.tests))
  }

  clearForm() {
    // this.equipment.clear();
    // this.setState({
    // equipment: {},
    // selectedInstruments: [],
    // selectedTests: [],
    // inputs: [],
    // selected: {},
    // tests: {},
    // selectedGroup: null,
    // test_variables: {},
    // selectedInstrument: {},
    // selectedTest: {},
    // category: {},
    // type: {},
    // selectedStds: [],
    // standard: {}
    // })
  }

  render() {
    return (
      <div>
        <Row>
          <Col xs="12" sm="6">
            <FormGroup>
              <Label htmlFor="ura">Umidade relativa do ar</Label>
              <Input type="number" id="ura" name="ura" placeholder="3.5" required onChange={(event) => this.onChange(event)} />
            </FormGroup>
          </Col>
          <Col xs="12" sm="6">
            <FormGroup>
              <Label htmlFor="temperature">Tempreratura</Label>
              <Input type="number" id="temperature" name="temperature" placeholder="25º" required onChange={(event) => this.onChange(event)} />
            </FormGroup>
          </Col>
        </Row>
        <Row>
          <Col xs="12" sm="6">
            <FormGroup>
              <Label htmlFor="group">Grupo</Label>
              <Input type="select" id="group" name="group" placeholder="Grupo" onChange={this.onSelectGroup.bind(this)} defaultValue="invalid" >
                <option value="invalid" disabled>Selecione</option>
                {this.state.groups.map(group => <option key={group.id} value={group.id}>{group.name}</option>)}
              </Input>
            </FormGroup>
          </Col>
          <Col xs="12" sm="6">
            <FormGroup>
              <Label htmlFor="category">Categoria</Label>
              <Input type="select" id="category" value={this.state.category.id || "invalid"} ref={el => { this.category = el }} onChange={this.onSelectCategory.bind(this)} name="category" placeholder="Categoria" defaultValue="invalid" >
                <option value="invalid" disabled>Selecione</option>
                {this.state.categories.map(category => <option key={category.id} value={category.id}>{category.name}</option>)}
              </Input>
            </FormGroup>
          </Col>
        </Row>
        <Row>
          <Col xs="12">
            <FormGroup>
              <Label htmlFor="equipment">Equipamento</Label>
              <Autocomplete ref={el => this.equipment = el} id="equipment" field="name" placeholder="Equipamento a ser ensaiado" onSelectItem={this.onSelectEquipment.bind(this)} defaultList={this.state.equips} />
              <FormText color="muted">
                Comece a digitar e espere pelos resultados
              </FormText>
            </FormGroup>
          </Col>
        </Row>
        <Row>
          <Col xs="12">
            <FormGroup>
              <Label htmlFor="standard">Norma</Label>
              <InputGroup>
                <Input type="select" id="standard" name="standard" required onChange={(event) => this.onChangeStandard(event)}>
                  <option value="invalid">Selecione</option>
                  {this.state.standards.map(std => <option key={std.id} value={std.id}>{std.name}</option>)}
                </Input>
                <InputGroupButton onClick={this.onAddStandard.bind(this)}>Adicionar</InputGroupButton>
              </InputGroup>
            </FormGroup>
          </Col>
        </Row>
        <Row>
          <Col xs="12">
            <ListGroup>
              {
                this.state.selectedStds.map(item =>
                  <ListGroupItem key={item.id} style={{ height: 50 }}>
                    <p style={{ display: 'inline-block' }}>{item.name}</p>
                    <p style={{ cursor: 'pointer', verticalAlign: 'middle' }}
                      className="float-right" onClick={this.onRemoveStd.bind(this, item)}>
                      <i className="fa fa-times" aria-hidden="true"></i>
                    </p>
                  </ListGroupItem>
                )
              }
            </ListGroup>
          </Col>
        </Row>
        <br />
        <Row>
          <Col xs="12">
            {this.state.inputs.filter(i => i.changeOnReport).map(input =>
              !input.differGroup
                ? <FormGroup key={input.name}><Label>{input.name}</Label> <Input type={input.type} name={input.name} onChange={(event) => this.onInputChange(event, input)} /></FormGroup>
                : (this.state.category.groups || []).map(group =>
                  <FormGroup key={input.name + '/' + group}><Label>{input.name} - {group}</Label><Input type={input.type} name={input.name} onChange={event => this.onInputGroupChange(event, group)} /></FormGroup>
                )
            )
            }
          </Col>
        </Row>
        <Row>
          <Col xs="12">
            <FormGroup>
              <Label htmlFor="instrument">Instrumento de Medição</Label>
              <InputGroup>
                <Input type="select" id="instrument" name="instrument" required defaultValue="invalid" onChange={this.onSelectInstrument.bind(this)}>
                  <option value="invalid" disabled >Selecione</option>
                  {
                    this.state.instruments.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)
                  }
                </Input>
                <InputGroupButton onClick={this.onAddInstrument.bind(this)}>Adicionar</InputGroupButton>
              </InputGroup>
            </FormGroup>
          </Col>
        </Row>
        <Row>
          <Col xs="12">
            <ListGroup>
              {
                this.state.selectedInstruments.map((item) =>
                  <ListGroupItem key={item.id} style={{ height: 50 }}>
                    <p style={{ display: 'inline-block' }}>{item.name}</p>
                    <p style={{ cursor: 'pointer', verticalAlign: 'middle' }}
                      className="float-right" onClick={this.onRemoveInstrument.bind(this, item)}>
                      <i className="fa fa-times" aria-hidden="true"></i>
                    </p>
                  </ListGroupItem>
                )
              }
            </ListGroup>
          </Col>
        </Row>
        <br />
        <Row>
          <Col xs="12">
            <FormGroup>
              <Label htmlFor="test-type">Tipo do ensaio</Label>
              <InputGroup>
                <Input type="select" id="test-type" name="test-type" required
                  value={this.state.type.length > 0 ? this.state.type : "invalid"} onChange={this.onSelectTest.bind(this)}>
                  <option value="invalid" disabled >Selecione</option>
                  {
                    this.state.types.map(item => <option key={item.id} value={item.id}>{item.name}</option>)
                  }
                </Input>
                <InputGroupButton onClick={this.onAddTest.bind(this)}>Adicionar</InputGroupButton>
              </InputGroup>
            </FormGroup>
          </Col>
        </Row>
        <Row>
          <Col xs="12">
            <ListGroup>
              {
                this.state.selectedTests.map((item) =>
                  <ListGroupItem key={item.id} style={{ minHeight: 50, display: 'flex' }}>
                    <p style={{ flexGrow: 1 }}>{item.name}</p>
                    <p style={{ cursor: 'pointer', verticalAlign: 'middle', marginLeft: 10 }}
                      className="float-right" onClick={this.onRemoveTest.bind(this, item)}>
                      <i className="fa fa-times" aria-hidden="true"></i>
                    </p>
                  </ListGroupItem>
                )
              }
            </ListGroup>
          </Col>
        </Row>
        <br />
        <Row>
          {
            this.state.fields.map(field =>
              <Col xs="12" md="6" >
                <FormGroup>
                  <Label>{field.field}</Label>
                  <Input type={field.type.toLowerCase()} name={field.field} onChange={(event) => this.onChangeInput(event, field)} />
                </FormGroup>
              </Col>
            )
          }
          <Col xs="6">
            <FormGroup>
              <Label htmlFor="result">Resultado</Label>
              <Input type="select" id="result" name="result" required onChange={(event) => this.onChangeInput(event)}>
                <option value="invalid">Selecione</option>
                <option value="Aprovado">Aprovado</option>
                <option value="Reprovado">Reprovado</option>
              </Input>
            </FormGroup>
          </Col>
          <Col xs="6">
            <FormGroup>
              <Label htmlFor="look">Visual</Label>
              <Input type="text" id="look" name="look" required onChange={(event) => this.onChangeInput(event)} />
            </FormGroup>
          </Col>
        </Row>
      </div>
    )
  }
}

export default ReportTests;