import React, { Component } from 'react';
import Dropzone from 'react-dropzone';
import {
  Row,
  Col,
  Button,
  ButtonDropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
  Card,
  CardHeader,
  CardFooter,
  CardBody,
  Form,
  FormGroup,
  FormText,
  Label,
  Input,
  InputGroup,
  InputGroupAddon,
  InputGroupButton,
  ListGroup,
  ListGroupItem,
  Progress
} from 'reactstrap';
import { database, storage } from '../../firebase';

function makeid() {
  var text = "";
  var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

  for (var i = 0; i < 5; i++)
    text += possible.charAt(Math.floor(Math.random() * possible.length));

  return text;
}

class ReportResults extends Component {

  constructor() {
    super()
    this.state = {
      files: [],
      dropzoneActive: false,
      selected: 'invalid',
      selectedUser: {},
      selectedUsers: [],
      users: [],
      results: {}
    }
  }

  componentWillMount() {
    database.ref('responsables').on('value', snapshot => {
      var users = [];
      snapshot.forEach(childSnapshot => {
        let user = childSnapshot.val()
        user.id = childSnapshot.key;
        users.push(user);
      });

      users.sort((a, b) => { return (a.name > b.name) ? 1 : ((b.name > a.name) ? -1 : 0) })

      this.setState({
        users
      })
    })
  }

  onDragEnter() {
    this.setState({
      dropzoneActive: true
    });
  }

  onDragLeave() {
    this.setState({
      dropzoneActive: false
    });
  }

  onDrop(localFiles) {
    var ref = storage.ref();
    var metadata = {
      contentType: 'image/jpeg'
    };
    var key = makeid();
    localFiles.map(file => {
      var uploadTask = ref.child('reports/' + key + "/" + file.name).put(file, metadata);
      uploadTask.on('state_changed', // or 'state_changed'
        (snapshot) => {
          var progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
          console.log('Upload is ' + progress + '% done');
          this.setState({
            isFinished: false,
            uploadRunning: true
          })
          this.setState({
            progress
          })
          switch (snapshot.state) {
            case 'paused': // or 'paused'
              console.log('Upload is paused');
              break;
            case 'running': // or 'running'
              console.log('Upload is running');
              break;
          }
        }, function (error) {
          switch (error.code) {
            case 'storage/unauthorized':
              NotificationManager.error('Você não está autorizado a fazer essa operação.')
              break;
            case 'storage/canceled':
              NotificationManager.error('O usuário cancelou o upload.')
              break;
            case 'storage/unknown':
              NotificationManager.error('Ocorreu um erro desconhecido ao fazer upload das imagens.')
              break;
          }
        }, () => {
          var downloadURL = uploadTask.snapshot.downloadURL;
          let files = this.state.files;
          files = files ? [...files, downloadURL] : [downloadURL];
          this.setState({
            isFinished: true,
            files
          }, () => this.onChangeValues())
        })
    })

    this.setState({
      dropzoneActive: false
    }, () => this.onChangeValues());
  }

  onSelectResponsable(event) {
    var selectedUser = this.state.users.find((item) => { return item.id == event.target.value });
    this.setState({
      selected: event.target.value,
      selectedUser
    })
  }

  onAddResponsable() {
    this.setState(prevState => ({
      selectedUsers: [...prevState.selectedUsers, this.state.selectedUser]
    }), () => this.onChangeValues())
  }

  onRemoveResponsable(item) {
    this.setState(prevState => ({
      selectedUsers: prevState.selectedUsers.filter(function (val) { return val.id !== item.id })
    }), () => this.onChangeValues())
  }

  onChangeInput(event) {
    var name = event.target.name;
    var value = event.target.value.toUpperCase();

    let results = this.state.results;
    results[name] = value;
    this.setState({
      results
    }, () => this.onChangeValues())
  }

  onChangeValues() {
    let results = this.state.results;
    results.evidences = this.state.files;
    results.responsables = this.state.selectedUsers;

    this.setState({
      results
    }, () => this.props.onChange(results));
  }

  clearForm() {
    this.setState({
      files: [],
      // uploadRunning: false,
      // selected: 'invalid',
      // selectedUser: {},
      // selectedUsers: [],
      // results: []
    })
  }

  render() {

    return (
      <div>
        <Row>
          <Col xs="12">
            <FormGroup>
              <Label htmlFor="value">Valor</Label>
              <Input type="text" name="value" id="value" placeholder="1234.90" onChange={this.onChangeInput.bind(this)} />
            </FormGroup>
          </Col>
        </Row>
        <Row>
          <Col xs="12" sm="6" >
            <Label>Evidências do ensaio</Label>
            <Dropzone onDrop={this.onDrop.bind(this)}
              style={{ position: "relative" }} accept="image/jpeg"
              onDragEnter={this.onDragEnter.bind(this)}
              onDragLeave={this.onDragLeave.bind(this)}>
              {this.state.dropzoneActive && <div className="dropzone-container-active"></div>}
              <div className="dropzone-container">
                <p>Arraste os arquivos aqui ou clique para selecioná-los. *Apenas .jpg</p>
              </div>
            </Dropzone>
            <Row>
              <Col xs="12">
                <p className="text-muted">Clique duas vezes na imagem para apagar</p>
                <ul className="preview">
                  {
                    this.state.files.map(f => <li key={f} className="preview-item"><img key={f} src={f} /></li>)
                  }
                </ul>
                {this.state.uploadRunning && <div><div>{this.state.isFinished ? 'Upload finalizado!' : 'Fazendo upload das imagens'}</div><Progress value={this.state.progress} /></div>}
              </Col>
            </Row>
          </Col>
          <Col xs="12" sm="6">
            <FormGroup>
              <Label htmlFor="observations">Observações</Label>
              <Input type="textarea" name="observations" id="observations" placeholder="Foi observado que..." style={{ height: 100, maxHeight: 100, minHeight: 100 }} onChange={this.onChangeInput.bind(this)} />
            </FormGroup>
          </Col>
        </Row>
        <Row>
          <Col xs="12">
            <FormGroup>
              <Label htmlFor="responsables">Responsabilidade técnica</Label>
              <InputGroup>
                <Input type="select" id="responsables" name="responsables" required
                  value={this.state.selected} onChange={this.onSelectResponsable.bind(this)}>
                  <option value="invalid" disabled>Selecione</option>
                  {this.state.users.map((user) => <option key={user.id} value={user.id}>{user.name}</option>)}
                </Input>
                <InputGroupButton onClick={this.onAddResponsable.bind(this)}>Adicionar</InputGroupButton>
              </InputGroup>
            </FormGroup>
            <Row>
              <Col xs="12">
                <ListGroup>
                  {this.state.selectedUsers.map((user) =>
                    <ListGroupItem key={user.id}>
                      <p style={{ display: 'inline-block' }}>{user.name} - {user.occupation}</p>
                      <p style={{ cursor: 'pointer', verticalAlign: 'middle' }}
                        className="float-right" onClick={this.onRemoveResponsable.bind(this, user)}>
                        <i className="fa fa-times" aria-hidden="true"></i>
                      </p>
                    </ListGroupItem>
                  )}
                </ListGroup>
              </Col>
            </Row>
          </Col>
        </Row>
      </div>
    )
  }
}

export default ReportResults;