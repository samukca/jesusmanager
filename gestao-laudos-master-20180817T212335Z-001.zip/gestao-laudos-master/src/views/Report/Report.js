import React, { Component } from 'react';

import {
    Row,
    Col,
    Button,
    Card,
    CardHeader,
    CardFooter,
    CardBody,
    CardTitle
} from 'reactstrap';
import { database } from '../../firebase';
import { NotificationManager } from 'react-notifications';

import ReportInfo from './_report-info';
import ReportTests from './_report-tests';
import ReportResults from './_report-results';
import * as pdf from './_report-pdf';

class Report extends Component {

    constructor(props) {
        super(props);

        this.state = {
            info: {},
            equipment: {},
            loading: false
        }
    }

    onChangeInfo(info) {
        this.setState({
            info
        })
    }

    onChangeTestsVariables(variables) {
        this.setState({
            tests_variables: variables
        })
    }

    onChangeTestsEquipment(equipment) {
        this.setState({
            equipment
        })
    }

    onChangeTests(tests) {
        this.setState({
            tests
        })
    }

    onChangeTestsTypes(types) {
        this.setState({
            types
        })
    }

    onChangeResults(results) {
        this.setState({
            results
        })
    }

    onChangeInstruments(instruments) {
        this.setState({
            instruments
        })
    }

    onSave() {
        let info = this.state.info;
        let tests_variables = this.state.tests_variables;
        let equipment = this.state.equipment;
        let tests = this.state.tests;
        let instruments = this.state.instruments;
        let results = this.state.results;
        let types = this.state.types;

        var report = { info, tests_variables, tests, instruments, types, equipment, results };


        if (equipment == undefined) {
            NotificationManager.warning("Por favor, selecione um equipamento.");
        } else if (info == undefined || info.number == undefined || info.number == "" || info.os_number == undefined) {
            NotificationManager.warning("Por favor, verifique as datas e o números do laudo e o cliente.");
        } else if (info.client == undefined) {
            NotificationManager.warning("Por favor, selecione um cliente.")
        } else if (tests_variables == undefined) {
            NotificationManager.warning("Por favor, verifique a URA e Temperatura.");
        } else if (results == undefined) {
            NotificationManager.warning("Por favor, verifique os responsáveis pelo laudo.")
        } else {
            try {
                this.setState({ loading: true })
                database.ref('reports').push().set(report)
                    .then(snapshot => {
                        NotificationManager.success('Laudo gerado com sucesso!');
                        pdf.loadImages(report).then(() => {
                            this.setState({ loading: false })
                        }).catch(error => {
                            this.setState({loading: false})
                        })
                        // this.form.reset();
                        this.info.clearForm();
                        // this.test.clearForm();
                        // this.results.clearForm();
                        window.scrollTo(0, 0)
                    }).catch(error => {
                        this.setState({loading: false})
                        NotificationManager.error("Não foi possível gerar laudo. Verifique todos os campos e tente novamente.")
                    });
            } catch (error) {
                this.setState({loading: false})
                NotificationManager.error("Não foi possível gerar laudo. Verifique os campos e tente novamente.");
                console.error(error);
            }
        }
    }

    render() {

        return (
            <div>
                <Row>
                    <Col xs="12" sm={{ size: 10, offset: 1 }}>
                        <Card>
                            <CardHeader>
                                Gerar novo laudo
                            </CardHeader>
                            <CardBody>
                                <form ref={el => { this.form = el }} >
                                    <CardTitle>Informações</CardTitle>
                                    <ReportInfo ref={el => this.info = el} onChange={this.onChangeInfo.bind(this)} />
                                    <hr />
                                    <CardTitle>Ensaios</CardTitle>
                                    <ReportTests ref={el => this.test = el}
                                        onChange={this.onChangeTests.bind(this)}
                                        onChangeVariables={this.onChangeTestsVariables.bind(this)}
                                        onChangeEquipment={this.onChangeTestsEquipment.bind(this)}
                                        onChangeInstruments={this.onChangeInstruments.bind(this)}
                                        onChangeTests={this.onChangeTestsTypes.bind(this)} />
                                    <hr />
                                    <CardTitle>Resultados</CardTitle>
                                    <ReportResults ref={el => this.results = el} onChange={this.onChangeResults.bind(this)} />
                                </form>
                            </CardBody>
                            <CardFooter>
                                <Button color="primary" disabled={this.state.loading} className="float-right" onClick={this.onSave.bind(this)}>Salvar</Button>
                            </CardFooter>
                        </Card>
                    </Col>
                </Row>
            </div>
        );
    }
}

export default Report;