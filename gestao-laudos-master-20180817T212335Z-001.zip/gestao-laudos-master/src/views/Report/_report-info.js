import React, { Component } from 'react';
import {
  Row,
  Col,
  Button,
  ButtonDropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
  Card,
  CardHeader,
  CardFooter,
  CardBody,
  Form,
  FormGroup,
  FormText,
  Label,
  Input,
  InputGroup,
  InputGroupAddon,
  InputGroupButton
} from 'reactstrap';
import Globalize from 'globalize';
import globalizeLocalizer from 'react-widgets-globalize';
import Autocomplete from '../../components/Autocomplete/Autocomplete'
import { database } from '../../firebase'
import index from 'react-notifications';
import { NotificationManager } from 'react-notifications';

class ReportInfo extends Component {

  constructor(props) {
    super(props);

    Globalize.locale("pt");
    globalizeLocalizer();

    this.state = {
      date: new Date().toISOString(),
      equips: [],
      clients: [],
      client: {},
      unit: null,
      department: null,
      limits: {},
      os: [],
      numbers: []
    }

  }

  componentWillMount() {
    this.getNumbersOfReport();

    database.ref('clients').on('value', snapshot => {
      var clients = [];
      snapshot.forEach(childSnapshot => {
        var client = childSnapshot.val();
        client.id = childSnapshot.key;
        clients.push(client);
      });

      clients.sort((a, b) => { return (a.name > b.name) ? 1 : ((b.name > a.name) ? -1 : 0) })

      this.setState({
        clients
      })
    });
  }

  onSelectClient(item) {
    if (item.limit == null || this.state.limits[item.id] == null ||
      this.state.limits[item.id] && this.state.limits[item.id] < item.limit) {
      this.setState({
        client: item,
        unit: null,
        department: null
      }, () => this.onChangeValue())
    } else {
      NotificationManager.warning("Esse cliente já atingiu o limite de laudos que podem ser realizados!");
    }
  }

  onSelectDepartment(event) {
    this.setState({
      department: event.target.value
    }, () => this.onChangeValue())
  }

  onSelectUnit(event) {
    this.setState({
      unit: event.target.value
    }, () => this.onChangeValue())
  }

  onChangeInput(event) {
    let name = event.target.name;
    let value = event.target.value.toUpperCase();

    this.setState({
      [name]: value
    }, () => this.onChangeValue())
  }

  onChangeValue() {
    var os_number = this.state.os_number;
    var number = this.state.number;
    var test_date = this.state.test_date;
    var expire_date = this.state.expire_date;
    var client = this.state.client;
    var unit = this.state.unit;
    var department = this.state.department;

    let info = {
      os_number,
      number,
      test_date,
      expire_date,
      client,
      unit,
      department
    }

    this.props.onChange(info);
  }

  getNumbersOfReport() {
    database.ref('reports').on('value', snapshot => {
      var reports = {};
      var os = [];
      var numbers = [];
      snapshot.forEach(childSnapshot => {
        var report = childSnapshot.val();
        if (report && report.info) {
          var today = new Date();
          var date = new Date(report.info['test_date'] + ' 00:00');
          os.push(report.info.os_number);
          numbers.push(report.info.number);
          if (report.info && report.info.client) {
            if (today.getMonth() == date.getMonth() && today.getFullYear() == date.getFullYear()) {
              if (!reports[report.info.client.id]) {
                reports[report.info.client.id] = 1;
              } else {
                reports[report.info.client.id]++;
              }
            }
          }
        }
      });
      this.setState({
        limits: reports,
        os,
        numbers
      })
    });
  }

  clearForm() {
    // this.client.clear();
    this.setState({
      // client: {},
      // unit: undefined,
      // department: undefined,
      number: "",
      // test_date: null,
      // expire_date: null
    }, () => this.props.onChange(this.state.info))
  }

  checkoutOsNumber(event) {
    var value = event.target.value;
    var contains = this.state.os.includes(value);

    if (contains) {
      NotificationManager.warning("Este número de OS já existe!", "Atenção!", 10000);

      this.setState({
        os_number: ""
      })
    }
  }

  checkoutNumber(event) {
    var value = event.target.value;
    var contains = this.state.numbers.includes(value);
    if (contains) {
      NotificationManager.warning("Este número de laudo já existe!", "Atenção!", 10000);
      this.setState({
        number: ""
      })
    }
  }

  render() {

    return (
      <div style={{ backgroundColor: 'white', textAlign: 'left' }}>
        <Row>
          <Col xs="12" md="3">
            <FormGroup>
              <Label htmlFor="os">Número da OS</Label>
              <Input type="number" id="os" name="os_number" value={this.state.os_number} ref={el => { this.os = el }} onChange={this.onChangeInput.bind(this)} placeholder="12345" required />
            </FormGroup>
          </Col>
          <Col xs="12" md="3">
            <FormGroup>
              <Label htmlFor="number">Número do laudo</Label>
              <Input type="number" id="number" name="number" value={this.state.number} ref={el => { this.number = el }} onBlur={this.checkoutNumber.bind(this)} onChange={this.onChangeInput.bind(this)} placeholder="12345" required />
            </FormGroup>
          </Col>
          <Col xs="12" sm="3">
            <FormGroup>
              <Label htmlFor="test_date">Data do ensaio</Label>
              <Input type="date"
                id="test-date"
                name="test_date"
                onChange={this.onChangeInput.bind(this)} />
            </FormGroup>
          </Col>
          <Col xs="12" sm="3">
            <FormGroup>
              <Label htmlFor="expire_date">Data de validade</Label>
              <Input type="date"
                id="test-date"
                name="expire_date"
                onChange={this.onChangeInput.bind(this)} />
            </FormGroup>
          </Col>
        </Row>
        <Row>
          <Col xs="12" md="4">
            <FormGroup>
              <Label htmlFor="client">Cliente</Label>
              <Autocomplete id="client" field="name" ref={el => { this.client = el }} placeholder="Cliente" onSelectItem={this.onSelectClient.bind(this)} defaultList={this.state.clients} />
              <FormText color="muted">
                Comece a digitar e espere pelos resultados
              </FormText>
            </FormGroup>
          </Col>
          <Col xs="12" md="4">
            <FormGroup>
              <Label htmlFor="branch">Departamento</Label>
              <Input type="select" disabled={!this.state.client.departments} id="branch" name="branch" onChange={this.onSelectDepartment.bind(this)} value={this.state.department ? this.state.department : "invalid"}>
                <option value="invalid" disabled>Selecione</option>
                {this.state.client.departments &&
                  this.state.client.departments.map((item, index) => {
                    return <option key={index} value={index}>{item.name}</option>
                  })}
              </Input>
            </FormGroup>
          </Col>
          <Col xs="12" md="4">
            <FormGroup>
              <Label htmlFor="department">Unidade</Label>
              <Input type="select" id="department" disabled={!this.state.client.units} name="department" required onChange={this.onSelectUnit.bind(this)} value={this.state.unit ? this.state.unit : "invalid"}>
                <option disabled value="invalid">Selecione</option>
                {this.state.client.units &&
                  this.state.client.units.map((item, index) => {
                    return <option key={index} value={index}>{item.name}</option>
                  })}
              </Input>
            </FormGroup>
          </Col>
        </Row>
      </div>
    )
  }
}

export default ReportInfo;