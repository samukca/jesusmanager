import jsPDF from 'jspdf';
import ReactDOMServer from 'react-dom/server';
import logo from '../../../public/img/logo.jpg';
import { autoTableHtmlToJson, autoTable } from 'jspdf-autotable';
import Moment from 'moment';
import { NotificationManager } from 'react-notifications';
import Raven from 'raven-js';
import FileSaver from 'file-saver';
import JSZip from 'jszip';

var logoBase64 = '';
var equipmentsImages = [];
var reportImages = [];
var creaImg = '';
var signatureImg = '';
var files = [];

var dateFormat = "DD/MM/YYYY";
var footer = "Este documento foi emitido a partir do sistema de gestão da empresa 08.618.923/0001-13 e sua veracidade poderá ser consultada no site https://laudostecnicosee.com.br/"

export function loadImages(report, multiple = false, callback = undefined) {
  var images = report.equipment.pictures || [];
  var creaImage = "https://firebasestorage.googleapis.com/v0/b/gestao-laudos.appspot.com/o/users%2FCREA-RJ.jpg?alt=media&token=bba228a6-a620-46c1-97a8-199060dff749";
  var signature = "https://firebasestorage.googleapis.com/v0/b/gestao-laudos.appspot.com/o/users%2F1522227840348_ASSINATURA%20MARCOS.jpg?alt=media&token=ac983f13-f9ce-4058-a20c-476a3969d155";

  return Promise.all(images ? images.map(img => { return scaleImage(img, 0.3) }) : () => { return new Promise() })
    .then(base => {
      equipmentsImages = base;

      Promise.all((report.results.evidences || []).map(img => { if (!img.includes('.png')) return scaleImage(img, 0.3) }))
        .then(base => {
          reportImages = base;

          return scaleImage(logo, 1)
        })
        .then(base64 => {
          logoBase64 = base64;
          return scaleImage(signature, 0.8);
        })
        .then(base64 => {
          signatureImg = base64;
          return scaleImage(creaImage, 1);
        })
        .then(base64 => {
          creaImg = base64;
          savePdf(report, multiple, callback);
        })
    })
    .catch(error => {
      Raven.captureException(error);
      NotificationManager.error('Aconteceu um erro ao gerar o PDF, tente novamente');
    })


}

export function savePdf(report, multiple, callback) {
  var doc = new jsPDF('p', 'mm', 'a4', true);
  console.log(report.equipment, report.id)

  // header
  var headerColumns = ["LAUDO TÉCNICO"];
  var headerRows = [["MSSR - Tecnologia em serviços de manuntenção de equipamentos elétricos Ltda."], ["CNPJ: 08.618.923/0001-13 - CREA/RJ 2016200583"], ["RUA CARACAS, 269 - BENTO RIBEIRO - RIO DE JANEIRO"], ["CEP: 21.331-740 - TELEFONE: (21) 2464-8772"]];

  doc.autoTable(headerColumns, headerRows, {
    theme: 'grid',
    margin: { left: 60 },
    styles: { overflow: 'linebreak', cellPadding: 0.2, lineWidth: 0 },
    headerStyles: { fontSize: 8, halign: 'center', fillColor: false, textColor: 80 },
    bodyStyles: { fontSize: 7, halign: 'center' },
    addPageContent: () => {
      doc.addImage(logoBase64, 'JPEG', 15, 10, 20, 20, 'logo', 'FAST')
    }
  });

  let first = doc.autoTable.previous;

  // Info Header
  var infoHeader = [
    "",
    "",
    "DATA DO ENSAIO",
    "VENCIMENTO",
    "Nº DO LAUDO",
    "Data do ensaio",
    "Vencimento",
    "Nº Laudo"
  ]
  var infoRows = [["DATA DO ENSAIO", Moment(report.info.test_date).format(dateFormat), "VENCIMENTO", Moment(report.info.expire_date).format(dateFormat), "Nº OS", report.info.os_number, "Nº DO LAUDO", report.info.number]];
  doc.autoTable(infoHeader, infoRows, {
    showHeader: 'never',
    styles: { overflow: 'linebreak', cellPadding: 1, halign: 'center', fontSize: 8 },
    theme: 'grid',
    columnStyles: {
      5: { columnWidth: 15 },
      4: { columnWidth: 15 },
      7: { columnWidth: 15 }
    },
    startY: first.finalY + 5,
    drawCell: (cell, data) => {
      if (data.column.dataKey % 2 == 0) {
        doc.setFontStyle('bold');
      }
    }
  });

  var second = doc.autoTable.previous;

  //Client
  var clientColumns = [];
  if (report.info.unit != undefined) {
    clientColumns = [
      "UNIDADE",
      "ENDEREÇO",
    ]
  } else {
    clientColumns = [
      "ENDEREÇO",
    ]
  }

  if (report.info.department) {
    clientColumns.push("DEPARTAMENTO")
  }

  var columns = ["", ""]
  var line = (report.info.client) ? [report.info.client.name, "CNPJ " + report.info.client.cnpj] : []

  var clientRows = [line];

  doc.autoTable(columns, clientRows, {
    styles: { overflow: 'linebreak', fontSize: 8, cellPadding: 1, fillColor: false, textColor: 80, fontStyle: 'bold' },
    theme: 'grid',
    showHeader: 'never',
    startY: second.finalY
  })

  var second = doc.autoTable.previous;

  var line = (report.info.client) ? ((report.info.unit != undefined) ?
    [report.info.client.units[report.info.unit].name.toUpperCase(), typeof (report.info.client.units[report.info.unit].address) == "string" ? report.info.client.units[report.info.unit].address.toUpperCase() : report.info.client.units[report.info.unit] ? report.info.client.units[report.info.unit].address.address_string.toUpperCase() : ""]
    : [typeof (report.info.client.address) == "string" ? report.info.client.address.toUpperCase() : report.info.client.address ? report.info.client.address.address_string.toUpperCase() : ""]) : []

  if ((report.info.unit && report.info.client.units[report.info.unit] &&
    report.info.client.units[report.info.unit].address
    && report.info.client.units[report.info.unit].address.area) ||
    (report.info.client.address && report.info.client.address.area)) {
    clientColumns.push("ÁREA")
    line.push(report.info.client.address.area);
  }

  if (report.info.department && report.info.client && report.info.client.departments) {
    if (report.info.client.departments[report.info.department])
      line.push(report.info.client.departments[report.info.department].name)
  }

  var clientRows = [line];

  doc.autoTable(clientColumns, clientRows, {
    styles: { overflow: 'linebreak', fontSize: 8, cellPadding: 1, fillColor: false, textColor: 80 },
    headerStyles: { lineWidth: 0.1 },
    theme: 'grid',
    startY: second.finalY
  })

  var third = doc.autoTable.previous;

  //Tools
  var toolsColumns = [
    "FABRICANTE",
    "MODELO",
    "Nº DE SÉRIE",
    "VALIDADE DE CALIBRAÇÃO"
  ];

  (report.instruments || []).map(instrument => {
    var toolsRows = [
      [instrument.brand, instrument.model, instrument.serial, instrument.callibration]
    ]

    doc.autoTable(toolsColumns, toolsRows, {
      styles: { overflow: 'linebreak', fontSize: 8, cellPadding: 1, fillColor: false, textColor: 80 },
      headerStyles: { lineWidth: 0.1 },
      columnStyles: {
        3: { columnWidth: 50 },
      },
      theme: 'grid',
      startY: third.finalY + 7,
      addPageContent: (data) => {
        doc.rect(data.settings.margin.left, third.finalY, data.table.width, 7, 'S');
        doc.setFontStyle('bold');
        doc.text("INSTRUMENTO DE MEDIÇÃO - " + instrument.name.toUpperCase(), data.settings.margin.left + 1, third.finalY + 4.5);
      }
    })

    third = doc.autoTable.previous;
  })


  let fourth = doc.autoTable.previous;

  //Report
  var reportColumns = [
    "NORMA",
    "URA (%)",
    "TEMPERATURA (°C)"
  ]
  var reportRows = [
    [report.tests_variables.standard, report.tests_variables.ura, report.tests_variables.temperature]
  ]

  doc.autoTable(reportColumns, reportRows, {
    styles: { overflow: 'linebreak', fontSize: 8, cellPadding: 1, fillColor: false, textColor: 80 },
    headerStyles: { lineWidth: 0.1 },
    columnStyles: {
      2: { columnWidth: 50 },
    },
    theme: 'grid',
    startY: fourth.finalY + 7,
    addPageContent: (data) => {
      doc.rect(data.settings.margin.left, fourth.finalY, data.table.width, 7, 'S');
      doc.setFontStyle('bold');
      doc.text("CARACTERÍSTICAS DO ENSAIO", data.settings.margin.left + 1, fourth.finalY + 4.5);
    }
  })

  let fifith = doc.autoTable.previous;

  //Equipment
  var reportColumns = []
  var reportRows = []
  var equipKeys = Object.keys(report.equipment);
  var line = [];
  equipKeys.map(key => {
    if (key != "name" && key != "isGroup" && key != "group" && key != "category" && key != "id" && key != "pictures") {
      reportColumns.push(key.toUpperCase());
      var value = report.equipment[key].toUpperCase().replace(/[^\x00-\xFF]/g, "");
      line.push(value);
    }
  })
  reportRows.push(line);

  doc.autoTable(reportColumns, reportRows, {
    styles: { overflow: 'linebreak', fontSize: 8, cellPadding: 1, fillColor: false, textColor: 80 },
    headerStyles: { lineWidth: 0.1 },
    columnStyles: {
      2: { columnWidth: 50 },
    },
    theme: 'grid',
    startY: fifith.finalY + 7,
    addPageContent: (data) => {
      doc.rect(data.settings.margin.left, fifith.finalY, data.table.width, 7, 'S');
      doc.setFontStyle('bold');
      doc.setFontSize(8);
      doc.setTextColor(80);
      doc.text(report.equipment.name ? report.equipment.name.toUpperCase() : " ", data.settings.margin.left + 1, fifith.finalY + 4.5);

      if (equipmentsImages.length > 0) {
        var size = equipmentsImages.length;
        var lineSize = (size > 3) ? 3 : size;
        var increment = 60
        if (size === 4) {
          lineSize = 2;
          increment = 60;
        }
        var x = data.settings.margin.left + 1;
        if (size == 1) {
          x += increment;
        }
        if (size == 2) {
          x += increment / 2
        }
        var y = data.cursor.y + 1;
        var yIncrement = 30;
        switch (lineSize % 3) {
          case 0:
            yIncrement = 30;
            break;
          case 1:
            yIncrement = 45;
            break;
          case 2:
            yIncrement = 30;
            break;
        }

        let height = Math.ceil(size / lineSize) * yIncrement + 1 + (size / lineSize * 1);

        let index = 0;

        doc.rect(data.settings.margin.left, data.cursor.y, data.table.width, height, 'S');
        equipmentsImages.forEach(image => {
          doc.addImage(image, 'JPEG', x, y, increment, yIncrement, image, 'FAST');
          index++;
          x += increment + 1;
          if (lineSize % 3 == 0 && index % 3 == 0) {
            y += yIncrement + 1;
            x = data.settings.margin.left + 1;
          } else if (lineSize === 2 && index % 2 === 0) {
            y += yIncrement + 1;
            x = data.settings.margin.left + 1
          }
        });

        data.cursor.y += height;
      }
    }
  });

  let sixth = doc.autoTable.previous;

  var keys = Object.keys(report.tests);
  var valueColumns = [];
  var valuesRows = [];
  var childKeys = [];
  var groups = [];

  var line = [];
  keys.forEach(key => {
    if (report.tests[key] != null && report.tests[key].length > 0) {
      switch (key.toLowerCase()) {
        case "current":
          valueColumns.push("mA");
          line.push(report.tests[key].toUpperCase());
          break;
        case "corrente":
          valueColumns.push("mA");
          line.push(report.tests[key].toUpperCase());
          break;
        case "look":
          valueColumns.push("VISUAL");
          line.push(report.tests[key].toUpperCase());
          break;
        case "visual":
          valueColumns.push("VISUAL");
          line.push(report.tests[key].toUpperCase());
          break;
        case "condutividade":
          valueColumns.push("CONDUTIVIDADE");
          line.push(report.tests[key].toUpperCase());
          break;
        case "conductivity":
          valueColumns.push("CONDUTIVIDADE");
          line.push(report.tests[key].toUpperCase());
          break;
        case "ensaio mecânico":
          valueColumns.push("E. MECÂNICO");
          line.push(report.tests[key].toUpperCase());
          break;
        case "mechanical":
          valueColumns.push("E. MECÂNICO");
          line.push(report.tests[key].toUpperCase());
          break;
        case "result":
          valueColumns.push("RESULTADO");
          line.push(report.tests[key].toUpperCase());
          break;
        default:
          childKeys.push(key.toUpperCase());
          groups.push([typeof (report.tests[key]) == 'string' ? report.tests[key].toUpperCase() : report.tests[key]]);
      }
    }
  })

  valuesRows.push(line);

  let next = doc.autoTable.previous;

  if (report.tests.groups != null && report.tests.groups != undefined) {
    var testsColumns = [""];
    var testsRows = [];

    report.types.forEach(type => {
      var line = [];
      line.push(type.name);
      testsRows.push(line);
    })

    doc.autoTable(testsColumns, testsRows, {
      styles: { overflow: 'linebreak', fontSize: 8, cellPadding: 1, fillColor: false, textColor: 80 },
      headerStyles: { lineWidth: 0.1 },
      theme: 'grid',
      showHeader: 'never',
      startY: sixth.finalY + 7,
      addPageContent: (data) => {
        doc.rect(data.settings.margin.left, sixth.finalY, data.table.width, 7, 'S');
        doc.setFontStyle('bold');
        doc.text("ENSAIOS REALIZADOS", data.settings.margin.left + 1, sixth.finalY + 4.5);
      }
    })

    next = doc.autoTable.previous;

    var itemColumns = ["MATERIAL ENSAIADO"];
    var itemRows = [];

    var innerKeys = Object.keys(report.tests.groups[0]);
    innerKeys.forEach(inner => {
      if (inner != "name") itemColumns.push(inner.toUpperCase());
    })

    report.tests.groups.forEach(key => {
      var line = [key.name];
      innerKeys.forEach(inner => {
        if (inner != "name") line.push(key[inner].toUpperCase());
      })
      itemRows.push(line);
    });

    doc.autoTable(itemColumns, itemRows, {
      styles: { overflow: 'linebreak', fontSize: 8, cellPadding: 1, fillColor: false, textColor: 80 },
      headerStyles: { lineWidth: 0.1 },
      theme: 'grid',
      showHeader: 'firstPage',
      startY: next.finalY
    })
  } else {
    if (childKeys.length > 5) {
      let halfWayThough = Math.floor(childKeys.length / 2)

      let arrayFirstHalf = childKeys.slice(0, halfWayThough);
      let arraySecondHalf = childKeys.slice(halfWayThough, childKeys.length);

      let firstRowsArray = groups.slice(0, halfWayThough);
      let secontRowsArray = groups.slice(halfWayThough, groups.length);

      doc.autoTable(arrayFirstHalf, [firstRowsArray], {
        styles: { overflow: 'linebreak', fontSize: 8, cellPadding: 1, fillColor: false, textColor: 80 },
        headerStyles: { lineWidth: 0.1 },
        theme: 'grid',
        columnStyles: { 2: { columnWidth: 40 } },
        showHeader: 'firstPage',
        startY: next.finalY
      })

      next = doc.autoTable.previous;

      doc.autoTable(arraySecondHalf, [secontRowsArray], {
        styles: { overflow: 'linebreak', fontSize: 8, cellPadding: 1, fillColor: false, textColor: 80 },
        headerStyles: { lineWidth: 0.1 },
        theme: 'grid',
        showHeader: 'firstPage',
        startY: next.finalY
      })
    } else {
      var line = [groups]
      doc.autoTable(childKeys, line, {
        styles: { overflow: 'linebreak', fontSize: 8, cellPadding: 1, fillColor: false, textColor: 80 },
        headerStyles: { lineWidth: 0.1 },
        theme: 'grid',
        showHeader: 'firstPage',
        startY: next.finalY
      })
    }

    next = doc.autoTable.previous;

    var testsColumns = [""];
    var testsRows = [];

    report.types.forEach(type => {
      var line = [];
      line.push(type.name);
      testsRows.push(line);
    })

    doc.autoTable(testsColumns, testsRows, {
      styles: { overflow: 'linebreak', fontSize: 8, cellPadding: 1, fillColor: false, textColor: 80 },
      headerStyles: { lineWidth: 0.1 },
      theme: 'grid',
      showHeader: 'never',
      startY: next.finalY + 7,
      addPageContent: (data) => {
        doc.rect(data.settings.margin.left, next.finalY, data.table.width, 7, 'S');
        doc.setFontStyle('bold');
        doc.text("ENSAIOS REALIZADOS", data.settings.margin.left + 1, next.finalY + 4.5);
      }
    })
  }

  next = doc.autoTable.previous;

  doc.autoTable(valueColumns, valuesRows, {
    styles: { overflow: 'linebreak', fontSize: 8, cellPadding: 1, fillColor: false, textColor: 80 },
    headerStyles: { lineWidth: 0.1 },
    theme: 'grid',
    showHeader: 'firstPage',
    startY: next.finalY
  })

  if (report.results.observations) {
    next = doc.autoTable.previous;
    doc.autoTable(["OBSERVAÇÕES"], [[report.results.observations ? report.results.observations.toUpperCase() : ""]], {
      styles: { overflow: 'linebreak', fontSize: 8, cellPadding: 1, fillColor: false, textColor: 80 },
      headerStyles: { lineWidth: 0.1 },
      theme: 'grid',
      showHeader: 'firstPage',
      startY: next.finalY
    })
  }

  let seventh = doc.autoTable.previous;

  //Responsables
  var testsColumns = [
    "",
    "CARGO",
    "NOME",
    "CREA-RJ",
  ]
  var testsRows = [];

  (report.results.responsables || []).map(responsable => {
    let line = [""]
    line.push(responsable.occupation.toUpperCase());
    line.push(responsable.name.toUpperCase());
    line.push(responsable.register.toUpperCase());
    testsRows.push(line);
  })

  doc.autoTable(testsColumns, testsRows, {
    styles: { overflow: 'linebreak', fontSize: 8, cellPadding: 1, fillColor: false, textColor: 80 },
    headerStyles: { lineWidth: 0.1 },
    columnStyles: {
      0: { columnWidth: 19 }
    },
    theme: 'grid',
    showHeader: 'firstPage',
    startY: seventh.finalY,
    createdCell: function (cell, opts) {
      var padding = 0.5;
      switch (report.results.responsables.length) {
        case 1:
          padding = 7;
          break;
        case 2:
          padding = 3;
          break;
        case 3:
          padding = 1;
          break;
        case 4:
          padding = 0.6;
          break;
        case 5:
          padding = 0.2;
          break;
      }
      cell.styles.cellPadding = { vertical: padding };
    },
    drawCell: (cell, data) => {
      // Rowspan
      if (data.column.dataKey === 0) {
        if (data.row.index === 0) {
          doc.rect(cell.x, cell.y, data.table.width, cell.height * report.results.responsables.length, 'S');
          doc.addImage(creaImg, 'JPEG', cell.x + 2, cell.y + 2, 15, 15, 'crea', 'FAST');
        }
        return false;
      }
    },
  });

  let eightth = doc.autoTable.previous;

  //Responsables
  var signatureColumns = [
    "DATA",
    ""
  ]
  var signatureRows = [
    [Moment(new Date()).format(dateFormat), ""]
  ]

  doc.autoTable(signatureColumns, signatureRows, {
    styles: {
      overflow: 'linebreak', fontSize: 12, cellPadding: 5,
      fillColor: false, textColor: 80,
    },
    headerStyles: { lineWidth: 0.1 },
    columnStyles: {
      0: { columnWidth: 35 }
    },
    showHeader: 'never',
    theme: 'grid',
    startY: eightth.finalY,
    createdCell: function (cell, opts) {
      cell.styles.cellPadding = { vertical: 10 };
    },
    drawCell: (cell, data) => {
      // Rowspan
      if (data.column.dataKey === 1) {
        if (data.row.index === 0) {
          doc.rect(cell.x, cell.y, cell.width, cell.height, 'S');
          doc.addImage(logoBase64, 'JPEG', cell.x + 20, cell.y + 2, 20, 20, 'logo', 'FAST');
          doc.addImage(signatureImg, 'JPEG', cell.x + 50, cell.y + 2, 50, 20, 'signature', 'FAST');
        }
        return false;
      }
    }
  });

  if (reportImages.length > 0) {
    doc.setFontSize(7)
    doc.text(footer, 12, 290)
    doc.addPage();

    var headerColumns = ["LAUDO TÉCNICO"];
    var headerRows = [["MSSR - Tecnologia em serviços de manuntenção de equipamentos elétricos Ltda."], ["CNPJ: 08.618.923/0001-13 - CREA/RJ 2016200583"], ["RUA CARACAS, 269 - BENTO RIBEIRO - RIO DE JANEIRO"], ["CEP: 21.331-740 - TELEFONE: (21) 2464-8772"]];

    doc.autoTable(headerColumns, headerRows, {
      theme: 'grid',
      margin: { left: 60 },
      styles: { overflow: 'linebreak', cellPadding: 0.2, lineWidth: 0 },
      headerStyles: { fontSize: 8, halign: 'center', fillColor: false, textColor: 80 },
      bodyStyles: { fontSize: 7, halign: 'center' },
      addPageContent: () => {
        doc.addImage(logoBase64, 'JPEG', 15, 10, 25, 25, 'logo', 'FAST')
      }
    });

    let first = doc.autoTable.previous;

    var infoHeader = [
      "",
      "",
      "DATA DO ENSAIO",
      "VENCIMENTO",
      "Nº DO LAUDO",
      "Data do ensaio",
      "Vencimento",
      "Nº do Laudo"
    ]
    var infoRows = [["DATA DO ENSAIO", Moment(report.info.test_date).format(dateFormat), "VENCIMENTO", Moment(report.info.expire_date).format(dateFormat), "Nº OS", report.info.os_number, "Nº DO LAUDO", report.info.number]];
    doc.autoTable(infoHeader, infoRows, {
      showHeader: 'never',
      styles: { overflow: 'linebreak', cellPadding: 1, halign: 'center', fontSize: 8 },
      theme: 'grid',
      columnStyles: {
        5: { columnWidth: 15 },
        4: { columnWidth: 15 },
        7: { columnWidth: 15 }
      },
      startY: first.finalY + 5,
      drawCell: (cell, data) => {
        if (data.column.dataKey % 2 == 0) {
          doc.setFontStyle('bold');
        }
      }
    });

    next = doc.autoTable.previous;

    doc.autoTable([""], [], {
      styles: { overflow: 'linebreak', fontSize: 8, cellPadding: 1, fillColor: false, textColor: 80 },
      headerStyles: { lineWidth: 0.1 },
      columnStyles: {
        2: { columnWidth: 50 },
      },
      showHeader: 'never',
      theme: 'grid',
      startY: next.finalY + 7,
      addPageContent: (data) => {
        doc.rect(data.settings.margin.left, next.finalY, data.table.width, 7, 'S');
        doc.setFontStyle('bold');
        doc.setFontSize(8);
        doc.setTextColor(80);
        doc.text("Evidências do Ensaio" || " ", data.settings.margin.left + 1, next.finalY + 4.5);

        var size = reportImages.length;
        var lineSize = (size > 2) ? 2 : size;
        var increment = 89;
        var x = data.settings.margin.left + 1;
        if (size == 1) {
          x += 30;
        }
        var y = data.cursor.y + 1;
        var yIncrement = 60;
        // switch(lineSize % 3) {
        //   case 0:
        //     yIncrement = 34;
        //     break;
        //   case 1:
        //     yIncrement = 50;
        //     break;
        //   case 2:
        //     yIncrement = 34;
        //     break;
        // }

        var height = Math.ceil(size / lineSize) * yIncrement + 1 + (size / lineSize);

        let index = 0;

        doc.rect(data.settings.margin.left, data.cursor.y, data.table.width, height, 'S');
        reportImages.forEach(image => {
          doc.addImage(image, 'JPEG', x, y, increment, yIncrement, image, 'FAST');
          index++;
          x += increment + 1;
          if (lineSize === 2 && index % 2 === 0) {
            y += yIncrement + 1;
            x = data.settings.margin.left + 1;
          }
        });

        data.cursor.y += height;
      }
    });

    let seventh = doc.autoTable.previous;

    //Responsables
    var testsColumns = [
      "",
      "CARGO",
      "NOME",
      "CREA-RJ",
    ]
    var testsRows = [];

    (report.results.responsables || []).map(responsable => {
      let line = [""]
      line.push(responsable.occupation.toUpperCase());
      line.push(responsable.name.toUpperCase());
      line.push(responsable.register.toUpperCase());
      testsRows.push(line);
    })

    doc.autoTable(testsColumns, testsRows, {
      styles: { overflow: 'linebreak', fontSize: 8, cellPadding: 1, fillColor: false, textColor: 80 },
      headerStyles: { lineWidth: 0.1 },
      columnStyles: {
        0: { columnWidth: 19 }
      },
      theme: 'grid',
      showHeader: 'firstPage',
      startY: seventh.finalY,
      createdCell: function (cell, opts) {
        var padding = 0.5;
        switch (report.results.responsables.length) {
          case 1:
            padding = 7;
            break;
          case 2:
            padding = 3;
            break;
          case 3:
            padding = 1;
            break;
          case 4:
            padding = 0.6;
            break;
          case 5:
            padding = 0.2;
            break;
        }
        cell.styles.cellPadding = { vertical: padding };
      },
      drawCell: (cell, data) => {
        // Rowspan
        if (data.column.dataKey === 0) {
          if (data.row.index === 0) {
            doc.rect(cell.x, cell.y, data.table.width, cell.height * report.results.responsables.length, 'S');
            doc.addImage(creaImg, 'JPEG', cell.x + 2, cell.y + 2, 15, 15, 'crea', 'FAST');
          }
          return false;
        }
      },
    });

    eightth = doc.autoTable.previous;

    //Responsables
    var signatureColumns = [
      "DATA",
      ""
    ]
    var signatureRows = [
      [Moment(new Date()).format(dateFormat), ""]
    ]

    doc.autoTable(signatureColumns, signatureRows, {
      styles: {
        overflow: 'linebreak', fontSize: 12, cellPadding: 5,
        fillColor: false, textColor: 80,
      },
      headerStyles: { lineWidth: 0.1 },
      columnStyles: {
        0: { columnWidth: 35 }
      },
      showHeader: 'never',
      theme: 'grid',
      startY: eightth.finalY,
      createdCell: function (cell, opts) {
        cell.styles.cellPadding = { vertical: 10 };
      },
      drawCell: (cell, data) => {
        // Rowspan
        if (data.column.dataKey === 1) {
          if (data.row.index === 0) {
            doc.rect(cell.x, cell.y, cell.width, cell.height, 'S');
            doc.addImage(logoBase64, 'JPEG', cell.x + 20, cell.y + 2, 20, 20, 'logo', 'FAST');
            doc.addImage(signatureImg, 'JPEG', cell.x + 50, cell.y + 2, 50, 20, 'signature', 'FAST');
          }
          return false;
        }
      }
    });
  }
  doc.setFontSize(7)
  doc.text(footer, 12, 290)

  var blob = doc.output("blob");
  if (multiple && callback != undefined) {
    callback(blob, report.info.number);
  } else {
    // if (window.navigator && window.navigator.msSaveOrOpenBlob) {
    //   window.navigator.msSaveOrOpenBlob(blob);
    //   return;
    // }

    window.open(URL.createObjectURL(blob));
    // FileSaver.saveAs(blob, "LD " + report.info.number + ".pdf")
    // doc.save("LD " + report.info.number + " " + report.equipment.name + ".pdf")
  }
}

export function zip(files) {
  var zip = new JSZip();
  for (var i = 0; i < files.length; i++) {
    zip.file("LD " + files[i].number + ".pdf", files[i].blob)
  }
  zip.generateAsync({ type: "blob" })
    .then(content => {
      FileSaver.saveAs(content, "laudos.zip");
    })
}

function imgToBase64(url) {
  if (!window.FileReader) {
    return;
  }
  return new Promise(function (resolve, reject) {
    var xhr = new XMLHttpRequest();
    xhr.responseType = 'blob';
    xhr.open('GET', url, true);
    xhr.withCredentials = false;
    xhr.onload = function () {
      var reader = new FileReader();
      reader.onloadend = function () {
        resolve(reader.result.replace('text/xml', 'image/jpeg'));
      };
      reader.onerror = function () {
        reject({
          status: this.status,
          statusText: xhr.statusText
        })
      }
      reader.readAsDataURL(xhr.response);
    };
    xhr.send();
  })
}

function scaleImage(dataUrl, scale, imageType, imageArguments) {
  return new Promise(function (resolve, reject) {
    try {
      var image, oldWidth, oldHeight, canvas, ctx, newDataUrl;

      // Provide default values
      imageType = imageType || "image/jpeg";
      imageArguments = imageArguments || 0.7;

      // Create a temporary image so that we can compute the height of the downscaled image.
      image = new Image();
      image.crossOrigin = "Anonymous";

      // Create a temporary canvas to draw the downscaled image on.
      canvas = document.createElement("canvas");

      // Draw the downscaled image on the canvas and return the new data URL.
      ctx = canvas.getContext("2d");

      image.onload = function () {
        oldWidth = image.width;
        oldHeight = image.height;
        canvas.width = oldWidth * scale;
        canvas.height = oldHeight * scale;
        ctx.drawImage(image, 0, 0, oldWidth * scale, oldHeight * scale);

        // const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height)
        newDataUrl = canvas.toDataURL(imageType);
        // console.log(imgData);
        resolve(newDataUrl);
      }

      image.src = dataUrl;
    } catch (e) {
      reject(e)
    }
  })
}