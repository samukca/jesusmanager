import React, {Component} from 'react';
import {Link, Switch, Route, Redirect} from 'react-router-dom';
import {Container} from 'reactstrap';
import Header from '../../components/Header/';
import ClientSidebar from '../../components/Sidebar/ClientSidebar';
import Breadcrumb from '../../components/Breadcrumb/';
import Aside from '../../components/Aside/';
import Footer from '../../components/Footer/';
import firebase, { auth, database } from '../../firebase';

import Client from '../../views/Client/Client';

class ClientFull extends Component {

  constructor(props) {
    super(props);

    this.state = {
      loading: true,
      user: auth.currentUser,
      employee: undefined
    }
  }

  componentWillMount() {
    auth.onAuthStateChanged((user) => {
      if (user) {
        database.ref('users/' + user.uid).on('value', snapshot => {
          var employee = snapshot.val().employee;
          this.setState({ user, employee, loading: false });
        })
      } else {
        this.setState({ user: null, loading: false })
      }
    });
  }

  render() {
    return (
      <div className="app">
        {
          !this.state.loading && this.state.user == null &&
            <Route render={(props) => (<Redirect to={{pathname: "/login"}} />)} />
        }
        {
          !this.state.loading && this.state.employee &&
            <Route render={(props) => (<Redirect to={{pathname: "/"}} />)} />
        }
        <Header />
        <div className="app-body">
          <ClientSidebar {...this.props} />
          <main className="main">
            <Breadcrumb />
            <Container fluid>
              <Client />
            </Container>
          </main>
          <Aside />
        </div>
        <Footer />
      </div>
    );
  }
}

export default ClientFull;
