import React, {Component} from 'react';
import {Link, Switch, Route, Redirect} from 'react-router-dom';
import {Container} from 'reactstrap';
import Header from '../../components/Header/';
import Sidebar from '../../components/Sidebar/';
import Breadcrumb from '../../components/Breadcrumb/';
import Aside from '../../components/Aside/';
import Footer from '../../components/Footer/';

import Report from '../../views/Report/';
import Client from '../../views/Register/Client/';
import User from '../../views/Register/User/';
import Tool from '../../views/Register/Tool/';
import Standard from '../../views/Register/Standard/';
import Equipment from '../../views/Register/Equipment/';
import Categories from '../../views/Register/Equipment/Categories';
import Test from '../../views/Register/Test/';
import Responsable from '../../views/Register/Responsable/';
import Reports from '../../views/Reports/Reports.js';
import Consolidation from '../../views/Reports/Consolidation.js';
import Settings from '../../views/Settings/';

class Full extends Component {

  render() {
    return (
      <div className="app">
        <Header />
        <div className="app-body">
          <Sidebar {...this.props}/>
          <main className="main">
            <Breadcrumb />
            <Container fluid>
              <Switch>
                <Route path="/home" name="Home" component={Report}/>
                <Route path="/entities/clients" name="Clients" component={Client}/>
                <Route path="/entities/users" name="Users" component={User}/>
                <Route path="/entities/tools" name="Tools" component={Tool} />
                <Route path="/entities/standards" name="Standards" component={Standard} />
                <Route path="/entities/equipments" name="Equipments" component={Equipment} />
                <Route path="/entities/tests" name="Equipments" component={Test} />
                <Route path="/entities/responsables" name="Técnicos" component={Responsable} />
                <Route path='/entities/groups' name="Grupos" component={Categories} />
                <Route path="/reports/report" name="Reports" component={Reports} />
                <Route path="/reports/consolidation" name="Consolidation" component={Consolidation} />
                <Route path="/settings" name="Settings" component={Settings} />
                {/* <Redirect from="/" to="/home"/> */}
              </Switch>
            </Container>
          </main>
          <Aside />
        </div>
        <Footer />
      </div>
    );
  }
}

export default Full;
