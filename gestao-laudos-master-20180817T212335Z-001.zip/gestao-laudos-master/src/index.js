import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import {HashRouter, Route, Switch, Redirect} from 'react-router-dom';
import {NotificationContainer} from 'react-notifications';
import firebase, { auth, database } from './firebase';

// Styles
import 'react-notifications/lib/notifications.css';
// Import Font Awesome Icons Set
import 'font-awesome/css/font-awesome.min.css';
// Import Simple Line Icons Set
import 'simple-line-icons/css/simple-line-icons.css';
// Temp fix for reactstrap
// import '../scss/core/_dropdown-menu-right.scss';
//Impor styles for bootstrap-table
import 'react-bootstrap-table/dist/react-bootstrap-table-all.min.css';
// Import Main styles for this application
import '../scss/style.scss';

// Containers
import Full from './containers/Full/'
import ClientFull from './containers/ClientFull/ClientFull'

// Views
import Login from './views/Pages/Login/'
import Register from './views/Pages/Register/'
import Page404 from './views/Pages/Page404/'
import Page500 from './views/Pages/Page500/'

import Raven from 'raven-js';

const PrivateRoute = ({ component: Component, ...rest }) => (
  rest.employee ?
    <Route {...rest} render={(props) => (
      auth.currentUser
        ? <Component {...props} />
        : <Redirect to={{
            pathname: '/login',
            state: { from: props.location }
          }} />
    )} />
  :
    <Route {...rest} render={(props) => (
      auth.currentUser
        ? <Redirect to={{pathname: '/client'}}/>
        : <Redirect to={{
            pathname: '/login',
            state: { from: props.location }
          }} />
    )} />  
)

class App extends Component {

  constructor(props) {
    super(props);

    this.state = {
      user: auth.currentUser,
      loading: true
    }
  }

  componentWillMount() {
    Raven.config('https://0381de2bf4714cdfb2e81819c5b4b9c6@sentry.io/283481', {
      autoBreadcrumbs: true
    }).install();

    auth.onAuthStateChanged((user) => {
      if (user) {
        database.ref('users/' + user.uid).on('value', snapshot => {
          var employee = snapshot.val().employee;
          this.setState({ user, employee, loading: false });
        })
      } else {
        this.setState({ user: null, loading: false })
      }
    });
  }

  render() {
    return(
      <div>
        <HashRouter>
          <Switch>
            <Route exact path="/login" name="Login Page" component={Login}/>
            <Route exact path="/register" name="Register Page" component={Register}/>
            <Route exact path="/404" name="Page 404" component={Page404}/>
            <Route exact path="/500" name="Page 500" component={Page500}/>
            <Route exact path="/client" name="Cliente" component={ClientFull} />
            { !this.state.loading &&
                <PrivateRoute path="/" name="Home" employee={this.state.employee} component={Full}/> 
            }
          </Switch>
        </HashRouter>
        <NotificationContainer/>
      </div>
    )
  }

}  

ReactDOM.render((
  <App />
), document.getElementById('root'));
